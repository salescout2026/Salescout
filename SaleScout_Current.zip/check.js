
  const STORAGE_KEY = 'salescout_family_manual_v2'; // keep v2 key so your saved sales stay after updating
  const LEGACY_KEYS = ['salescout_family_manual_v1'];
  let sales = [];
  let filter = 'all';
  let map, markersLayer, mapRenderTimer = null;
  let mapUnlocked = true;
  const $ = id => document.getElementById(id);
  function todayISO(){ const d=new Date(); d.setMinutes(d.getMinutes()-d.getTimezoneOffset()); return d.toISOString().slice(0,10); }
  function uid(){ return 's_' + Math.random().toString(36).slice(2) + Date.now().toString(36); }
  function normalizeSale(s, i){ return { id:s.id||uid(), title:s.title||'Yard sale', address:s.address||'', date:s.date||'', time:s.time||'', notes:s.notes||'', include:s.include!==false, visited:!!s.visited, order:Number.isFinite(Number(s.order))?Number(s.order):i, lat:s.lat||null, lon:s.lon||null, geocodedAddress:s.geocodedAddress||'', geocodeVersion:Number(s.geocodeVersion)||0 }; }
  function load(){
    try{ sales = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null'); }catch(e){ sales=null; }
    if(!Array.isArray(sales)){
      for(const key of LEGACY_KEYS){ try{ const old=JSON.parse(localStorage.getItem(key)||'null'); if(Array.isArray(old)){ sales=old; break; } }catch(e){} }
    }
    if(!Array.isArray(sales)) sales=[];
    sales=sales.map(normalizeSale);
    saveOnly();
  }
  function saveOnly(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(sales)); }
  function save(){ saveOnly(); renderAll(); }
  function sortSales(list=sales){ return [...list].sort((a,b)=>((a.date||'9999-99-99')+' '+(a.time||'99:99')+' '+String(a.order)).localeCompare((b.date||'9999-99-99')+' '+(b.time||'99:99')+' '+String(b.order))); }
  function routeSales(){ return [...sales].filter(s=>s.include!==false && !s.visited && s.address.trim()).sort((a,b)=>Number(a.order)-Number(b.order)); }
  function inThisWeek(dateStr){ if(!dateStr) return false; const d=new Date(dateStr+'T12:00:00'); const now=new Date(); const day=now.getDay(); const start=new Date(now); start.setDate(now.getDate()-day); start.setHours(0,0,0,0); const end=new Date(start); end.setDate(start.getDate()+7); return d>=start && d<end; }
  function filtered(){ let list=sortSales(); if(filter==='today') list=list.filter(s=>s.date===todayISO()); if(filter==='week') list=list.filter(s=>inThisWeek(s.date)); return list; }
  function escapeHtml(str){ return String(str||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
  function dateLabel(s){ let parts=[]; if(s.date) parts.push(s.date); if(s.time) parts.push(s.time); return parts.join(' at ') || 'No time set'; }



  function cleanPostText(text){
    return String(text||'').replace(/\r/g,'\n').replace(/[ \t]+/g,' ').replace(/\n{3,}/g,'\n\n').trim();
  }
  function isoFromParts(year, month, day){
    const d = new Date(year, month-1, day, 12, 0, 0);
    if(isNaN(d.getTime())) return '';
    const now = new Date();
    // If no year was obvious and the date is far in the past, use next year.
    if(d < new Date(now.getFullYear(), now.getMonth(), now.getDate()-7) && year === now.getFullYear()) d.setFullYear(year+1);
    d.setMinutes(d.getMinutes()-d.getTimezoneOffset());
    return d.toISOString().slice(0,10);
  }
  function nextWeekdayISO(dayIndex){
    const d = new Date();
    let diff = (dayIndex - d.getDay() + 7) % 7;
    if(diff === 0) diff = 0;
    d.setDate(d.getDate()+diff);
    d.setHours(12,0,0,0);
    d.setMinutes(d.getMinutes()-d.getTimezoneOffset());
    return d.toISOString().slice(0,10);
  }
  function parsePostDate(text){
    const t = ' ' + text.toLowerCase() + ' ';
    if(/\btoday\b/.test(t)) return {iso:todayISO(), label:'today'};
    if(/\btomorrow\b/.test(t)){
      const d=new Date(); d.setDate(d.getDate()+1); d.setHours(12,0,0,0); d.setMinutes(d.getMinutes()-d.getTimezoneOffset());
      return {iso:d.toISOString().slice(0,10), label:'tomorrow'};
    }
    const monthNames = {jan:1,january:1,feb:2,february:2,mar:3,march:3,apr:4,april:4,may:5,jun:6,june:6,jul:7,july:7,aug:8,august:8,sep:9,sept:9,september:9,oct:10,october:10,nov:11,november:11,dec:12,december:12};
    let m = text.match(/\b(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t|tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\.?\s+(\d{1,2})(?:st|nd|rd|th)?(?:,?\s*(20\d{2}|\d{2}))?\b/i);
    if(m){
      let y = m[3] ? Number(m[3]) : new Date().getFullYear(); if(y<100) y+=2000;
      return {iso:isoFromParts(y, monthNames[m[1].toLowerCase().replace('.','')], Number(m[2])), label:m[0]};
    }
    m = text.match(/\b(\d{1,2})[\/\-.](\d{1,2})(?:[\/\-.](20\d{2}|\d{2}))?\b/);
    if(m){
      let y = m[3] ? Number(m[3]) : new Date().getFullYear(); if(y<100) y+=2000;
      return {iso:isoFromParts(y, Number(m[1]), Number(m[2])), label:m[0]};
    }
    const days = [['sunday',0],['sun',0],['monday',1],['mon',1],['tuesday',2],['tues',2],['tue',2],['wednesday',3],['wed',3],['thursday',4],['thurs',4],['thu',4],['friday',5],['fri',5],['saturday',6],['sat',6]];
    for(const [name, idx] of days){ if(new RegExp('\\b'+name+'\\b','i').test(text)) return {iso:nextWeekdayISO(idx), label:name}; }
    return {iso:'', label:''};
  }
  function timeTo24(hour, minute, ampm, endAmpm){
    hour = Number(hour); minute = minute ? Number(minute) : 0;
    let ap = (ampm||'').toLowerCase().replace(/\./g,'');
    const end = (endAmpm||'').toLowerCase().replace(/\./g,'');
    if(!ap && end === 'pm' && hour >= 7 && hour <= 11) ap = 'am';
    if(!ap && end === 'am' && hour <= 11) ap = 'am';
    if(ap === 'pm' && hour < 12) hour += 12;
    if(ap === 'am' && hour === 12) hour = 0;
    if(!ap && hour >= 1 && hour <= 6) hour += 12; // most sale posts with 1-6 mean afternoon unless AM is written
    if(hour < 0 || hour > 23) return '';
    return String(hour).padStart(2,'0') + ':' + String(minute).padStart(2,'0');
  }
  function parsePostTime(text){
    const re = /\b(\d{1,2})(?::(\d{2}))?\s*(a\.?m\.?|p\.?m\.?)?\s*(?:-|–|—|to|until|til|through)\s*(\d{1,2})(?::(\d{2}))?\s*(a\.?m\.?|p\.?m\.?)\b/i;
    let m = text.match(re);
    if(m) return {time:timeTo24(m[1],m[2],m[3],m[6]), label:m[0]};
    m = text.match(/\b(?:starts?\s*(?:at)?|from|time:?|open:?|sale:?|hours:?)\s*(\d{1,2})(?::(\d{2}))?\s*(a\.?m\.?|p\.?m\.?)\b/i) || text.match(/\b(\d{1,2})(?::(\d{2}))?\s*(a\.?m\.?|p\.?m\.?)\b/i);
    if(m) return {time:timeTo24(m[1],m[2],m[3],''), label:m[0]};
    return {time:'', label:''};
  }
  const LOCAL_CITY_RE = /\b(Gladwin|Beaverton|Clare|Harrison|Midland|Mount Pleasant|Mt\.? Pleasant|West Branch|Coleman|Farwell|Sanford|Auburn|Pinconning|Roscommon|Prudenville|Houghton Lake|Standish|Bay City|Rose City|St\. Charles)\b/i;
  const STATE_RE = /\b(MI|Michigan)\b/i;
  const STREET_RE = /\b(street|st\.?|road|rd\.?|avenue|ave\.?|drive|dr\.?|lane|ln\.?|court|ct\.?|circle|cir\.?|boulevard|blvd\.?|trail|trl\.?|place|pl\.?|way|highway|hwy\.?|terrace|ter\.?|parkway|pkwy\.?|loop|path|alley)\b/i;
  const ROUTE_RE = /\b(?:m|us|i)[-\s]?\d{1,3}\b/i;
  const ITEM_RE = /\b(tools?|clothes|clothing|furniture|dresser|couch|sofa|table|chairs?|toys?|kids?|baby|toddler|women'?s?|men'?s?|shoes?|household|decor|reef|tank|fish|misc|books?|kitchen|antiques?|crafts?|collectibles?|garage items?|priced|each|obo|firm|free|lot of|lots of|everything must go|washer|dryer|mower|bike|bikes|games?|movies?|jewelry|purses?|bags?)\b/i;
  function homePlace(){ return (($('homeInput') && $('homeInput').value) || localStorage.getItem('salescout_home') || 'Gladwin, MI').trim() || 'Gladwin, MI'; }
  function stripAddressLabel(line){ return String(line||'').replace(/^(?:address|addy|location|where|located\s+at|located|place|pickup|pick up)\s*[:\-–—]?\s*/i,'').trim(); }
  function hasHouseNumber(s){ return /(^|\D)\d{1,6}\b/.test(s); }
  function hasStreetAddress(s){ return hasHouseNumber(s) && (STREET_RE.test(s) || ROUTE_RE.test(s)); }
  function isItemishLine(line){
    const s = String(line||'');
    if(!s) return false;
    const hasAddressWords = STREET_RE.test(s) || ROUTE_RE.test(s) || LOCAL_CITY_RE.test(s) || STATE_RE.test(s);
    if((/[$•;]/.test(s) || s.split(',').length >= 3) && ITEM_RE.test(s) && !hasStreetAddress(s)) return true;
    if(ITEM_RE.test(s) && !hasAddressWords) return true;
    if(/\b\d+\s*(?:piece|pc|inch|in\.?|gal|gallon|size|month|months|year|years|yr|yrs|t|xl|lbs?)\b/i.test(s) && !hasStreetAddress(s)) return true;
    return false;
  }
  function extractStrictStreetAddress(raw){
    let s = String(raw||'').replace(/^[📍🗺️🏠➡️\s]+/u,'').trim();
    s = stripAddressLabel(s);
    // Facebook posts often run the time right into the address: "2645 lakeshore dr.1 -6 pm".
    // Add a space after a street suffix period before numbers so the address extractor can stop cleanly.
    s = s.replace(/\b(st|rd|dr|ave|ln|ct|cir|blvd|trl|pl|hwy)\.(?=\d)/ig, '$1. ');
    const streetSuffix = '(?:street|st\\.?|road|rd\\.?|avenue|ave\\.?|drive|dr\\.?|lane|ln\\.?|court|ct\\.?|circle|cir\\.?|boulevard|blvd\\.?|trail|trl\\.?|place|pl\\.?|way|highway|hwy\\.?|terrace|ter\\.?|parkway|pkwy\\.?|loop|path|alley)';
    const cityNames = '(?:Gladwin|Beaverton|Clare|Harrison|Midland|Mount Pleasant|Mt\\.? Pleasant|West Branch|Coleman|Farwell|Sanford|Auburn|Pinconning|Roscommon|Prudenville|Houghton Lake|Standish|Bay City|Rose City|St\\.? Charles)';
    const re = new RegExp("(?:^|\\b)(\\d{1,6}\\s+(?:[A-Za-z0-9.#'’&-]+\\s+){0,7}"+streetSuffix+"\\b\\.?)(?:\\s*(?:,|-)\\s*|\\s+)?("+cityNames+")?(?:\\s*,?\\s*(MI|Michigan))?", 'i');
    const m = s.match(re);
    if(!m) return '';
    let out = (m[1]||'').trim().replace(/[\s,.;:]+$/,'');
    if(m[2]) out += ', ' + m[2].replace(/Mt\.?/i,'Mount').trim();
    if(m[3]) out += ', MI';
    return out.replace(/\s{2,}/g,' ');
  }
  function cleanAddressCandidate(raw){
    let s = String(raw||'').replace(/^[📍🗺️🏠➡️\s]+/u,'').trim();
    s = stripAddressLabel(s);
    s = s.replace(/\b(st|rd|dr|ave|ln|ct|cir|blvd|trl|pl|hwy)\.(?=\d)/ig, '$1. ');
    const strict = extractStrictStreetAddress(s);
    // If a line contains extra sale text before/after the real address, keep only the address.
    if(strict) return strict;
    s = s.replace(/\s+(?:no early birds|no early sales|please message|message me|pm me|cash only|venmo|paypal)\b.*$/i,'');
    s = s.replace(/\s+(?:sale starts?|starts?|hours?|open)\s*[:\-]?\s*\d{1,2}.*$/i,'');
    s = s.replace(/\b\d{1,2}\s*(?:-|to|–|—)\s*\d{1,2}\s*(?:am|pm)\b.*$/i,'');
    s = s.replace(/[\s.]+$/,'').replace(/\s{2,}/g,' ');
    return s;
  }
  function scoreAddressCandidate(line, labelled=false){
    const s = cleanAddressCandidate(line);
    if(!s || s.length < 3 || s.length > 120) return -100;
    let score = labelled ? 35 : 0;
    if(hasStreetAddress(s)) score += 75;
    else if(hasHouseNumber(s) && labelled) score += 35;
    if(LOCAL_CITY_RE.test(s)) score += 15;
    if(STATE_RE.test(s)) score += 20;
    if(/^\d{1,6}\b/.test(s)) score += 8;
    if(!hasStreetAddress(s) && LOCAL_CITY_RE.test(s) && (STATE_RE.test(s)||labelled)) score += 20;
    if(isItemishLine(s) && !(labelled && hasStreetAddress(s))) score -= 75;
    if(/^[$•-]/.test(s)) score -= 40;
    if(/\b(?:for sale|iso|looking for|wanted)\b/i.test(s) && !labelled) score -= 30;
    return score;
  }
  function finishAddress(addr){
    let a = cleanAddressCandidate(addr);
    if(!a) return '';
    // If the post only says a street address, assume the search-center city so Google does not choose another town/state.
    if(hasStreetAddress(a) && !LOCAL_CITY_RE.test(a) && !STATE_RE.test(a)) a += ', ' + homePlace();
    else if(hasStreetAddress(a) && LOCAL_CITY_RE.test(a) && !STATE_RE.test(a)) a += ', MI';
    else if(!hasStreetAddress(a) && LOCAL_CITY_RE.test(a) && !STATE_RE.test(a)) a += ', MI';
    return a;
  }
  function looksLikeAddress(line){ return scoreAddressCandidate(line, false) >= 70; }
  function parsePostAddress(text){
    const lines = cleanPostText(text).split('\n').map(l=>l.trim()).filter(Boolean);
    const candidates = [];
    function add(raw, labelled=false, why=''){
      const cleaned = cleanAddressCandidate(raw);
      if(!cleaned) return;
      const score = scoreAddressCandidate(cleaned, labelled);
      if(score > 0) candidates.push({raw:cleaned, score, labelled, why});
    }
    for(let i=0;i<lines.length;i++){
      const line = lines[i];
      if(/^(?:address|addy|location|where|located\s+at|located|place|pickup|pick up)\s*[:\-–—]?\s*$/i.test(line) && lines[i+1]) add(lines[i+1], true, 'label-next-line');
      if(/^(?:address|addy|location|where|located\s+at|located|place|pickup|pick up)\s*[:\-–—]\s+/i.test(line)) add(line, true, 'label');
      const inline = line.match(/\b(?:address|addy|location|where|located\s+at|located|pickup|pick up)\s*[:\-–—]?\s+(.{3,110})$/i);
      if(inline) add(inline[1], true, 'inline-label');
      const atStreet = line.match(/\b(?:at|@)\s+(\d{1,6}\s+[^\n]{2,95})/i);
      if(atStreet) add(atStreet[1], false, 'at-street');
      if(hasStreetAddress(line) && !isItemishLine(line)) add(line, false, 'street-line');
    }
    candidates.sort((a,b)=>b.score-a.score);
    const best = candidates[0];
    if(best && best.score >= 70) return {address:finishAddress(best.raw), confidence:best.score>=95?'high':'medium', warning:best.score>=95?'':'Possible address found — double-check it before saving.'};
    const city = cleanPostText(text).match(LOCAL_CITY_RE);
    if(city) return {address:'', city:city[0].replace(/Mt\.?/i,'Mount') + ', MI', confidence:'city-only', warning:'I only found the city. I left the address blank so it does not route to the wrong place.'};
    return {address:'', city:'', confidence:'none', warning:'I did not find a safe address, so I left the address blank instead of guessing.'};
  }
  function parsePostTitle(text){
    const lines = cleanPostText(text).split('\n').map(l=>l.trim()).filter(Boolean);
    const saleLine = lines.find(l=>/\b(garage|yard|moving|estate|rummage|barn|tag|multi[ -]?family|sale)\b/i.test(l) && l.length <= 90 && !looksLikeAddress(l));
    if(saleLine) return saleLine.replace(/^(title|event)\s*[:\-]\s*/i,'').trim();
    const first = lines.find(l=>l.length >= 4 && l.length <= 70 && !looksLikeAddress(l) && !/^\d/.test(l) && !/^(date|time|when|where|address|addy|location)\s*[:\-]/i.test(l) && !isItemishLine(l));
    return first || 'Facebook yard sale';
  }
  function parseSaleFromText(text){
    const post = cleanOcrText(cleanPostText(text));
    const date = parsePostDate(post);
    const time = parsePostTime(post);
    const addr = parsePostAddress(post);
    const title = parsePostTitle(post);
    const found = [];
    const warnings = [];
    if(title) found.push('title');
    if(addr.address) found.push('address');
    else warnings.push(addr.warning || 'No safe address found.');
    if(date.iso) found.push('date');
    if(time.time) found.push('start time');
    if(addr.warning && addr.address) warnings.push(addr.warning);
    const noteLines = [];
    if(addr.city && !addr.address) noteLines.push('City found but not used as route address: '+addr.city);
    if(date.label) noteLines.push('Post date text: '+date.label);
    if(time.label) noteLines.push('Post time text: '+time.label);
    noteLines.push('Original listing text:');
    noteLines.push(post);
    return {
      title: title || 'Yard sale',
      address: addr.address || '',
      date: date.iso || '',
      time: time.time || '',
      notes: noteLines.join('\n'),
      include: true,
      visited: false,
      _found: found,
      _warnings: warnings,
      _raw: post
    };
  }
  function fillFormFromParsed(parsed){
    const found = parsed._found || [];
    const warnings = parsed._warnings || [];
    if(parsed.title) $('saleTitle').value = parsed.title;
    if(parsed.address) $('saleAddress').value = parsed.address;
    else $('saleAddress').value = '';
    if(parsed.date) $('saleDate').value = parsed.date;
    if(parsed.time) $('saleTime').value = parsed.time;
    $('saleNotes').value = parsed.notes || '';
    let msg = found.length ? ('Filled: '+found.join(', ')+'.') : 'I could not confidently fill the fields.';
    if(warnings.length) msg += ' ' + warnings.join(' ');
    msg += ' Always check the address before saving.';
    $('parseStatus').textContent = msg;
    if(!parsed.address) $('saleAddress').focus();
  }
  function parseFacebookPost(text){
    const post = cleanOcrText(cleanPostText(text));
    if(!post){ alert('Paste the post text first.'); return; }
    const chunks = extractSaleChunks(post);
    if(chunks.length > 1){
      $('parseStatus').textContent = 'I found '+chunks.length+' possible listings. Tap Import all found to add them as separate sales, or Break down text again after deleting extra text.';
      const first = parseSaleFromText(chunks[0]);
      fillFormFromParsed(first);
      return;
    }
    fillFormFromParsed(parseSaleFromText(post));
  }

  function cleanOcrText(raw){
    let text = String(raw||'')
      .replace(/\r/g,'\n')
      .replace(/[“”]/g,'"')
      .replace(/[‘’]/g,"'")
      .replace(/\bM[Il1]\b/g,'MI')
      .replace(/\bGiadwin\b/gi,'Gladwin')
      .replace(/\bCiare\b/gi,'Clare')
      .replace(/\bBeaverton\b/gi,'Beaverton')
      .replace(/\bMiddie[ -]?town\b/gi,'Midland')
      .replace(/[ \t]+/g,' ')
      .replace(/\n[ \t]+/g,'\n')
      .replace(/[ \t]+\n/g,'\n');
    const junk = /^(?:like|comment|share|send|all reactions|view more comments|write a comment|see less|see more|reply|author|admin|sponsored|follow|join group|most relevant|top comments|facebook|notifications?|messenger|home|watch|marketplace)$/i;
    const lines = text.split('\n').map(l=>l.trim()).filter(l=>l && !junk.test(l));
    return lines.join('\n').replace(/\n{3,}/g,'\n\n').trim();
  }
  function likelyAddressLineIndex(line){
    const labelled = /^(?:address|addy|location|where|located\s+at|located|place|pickup|pick up)\s*[:\-–—]?/i.test(line);
    return scoreAddressCandidate(line, labelled) >= (labelled ? 45 : 70);
  }
  function likelySaleChunk(chunk){
    const c = cleanOcrText(chunk);
    if(c.length < 12) return false;
    if(parsePostAddress(c).address) return true;
    return /\b(garage|yard|moving|estate|rummage|barn|tag|multi[ -]?family|sale)\b/i.test(c) && (parsePostDate(c).iso || parsePostTime(c).time);
  }
  function extractSaleChunks(text){
    const t = cleanOcrText(text);
    if(!t) return [];
    const hard = t.split(/\n\s*(?:-{3,}|={3,}|_{3,}|\*{3,}|•{3,})\s*\n/g).map(cleanOcrText).filter(likelySaleChunk);
    if(hard.length > 1) return hard;
    const lines = t.split('\n').map(l=>l.trim()).filter(Boolean);
    let anchors = [];
    for(let i=0;i<lines.length;i++){
      if(likelyAddressLineIndex(lines[i])) anchors.push(i);
      else if(/^(?:address|addy|location|where|located|pickup|pick up)\s*[:\-–—]?\s*$/i.test(lines[i]) && lines[i+1]) anchors.push(i+1);
    }
    anchors = anchors.filter((idx,pos)=>pos===0 || idx-anchors[pos-1] > 2);
    if(anchors.length > 1){
      const chunks=[];
      for(let a=0;a<anchors.length;a++){
        let start = a===0 ? 0 : Math.floor((anchors[a-1]+anchors[a])/2)+1;
        let end = a===anchors.length-1 ? lines.length-1 : Math.floor((anchors[a]+anchors[a+1])/2);
        // Pull a nearby title/date line above the address when possible.
        while(start > 0 && anchors[a]-start < 5 && !likelyAddressLineIndex(lines[start-1]) && !/^\s*$/.test(lines[start-1])) start--;
        const chunk = cleanOcrText(lines.slice(start,end+1).join('\n'));
        if(likelySaleChunk(chunk)) chunks.push(chunk);
      }
      if(chunks.length > 1) return chunks;
    }
    const saleStarts=[];
    for(let i=0;i<lines.length;i++){
      if(/\b(garage|yard|moving|estate|rummage|barn|tag|multi[ -]?family|sale)\b/i.test(lines[i]) && !looksLikeAddress(lines[i]) && !isItemishLine(lines[i])) saleStarts.push(i);
    }
    if(saleStarts.length > 1){
      const chunks=[];
      for(let i=0;i<saleStarts.length;i++){
        const start=saleStarts[i];
        const end=i+1<saleStarts.length ? saleStarts[i+1]-1 : lines.length-1;
        const chunk=cleanOcrText(lines.slice(start,end+1).join('\n'));
        if(likelySaleChunk(chunk)) chunks.push(chunk);
      }
      if(chunks.length > 1) return chunks;
    }
    return [t];
  }
  function addressKey(addr){
    return String(addr||'')
      .toLowerCase()
      .replace(/(street)/g,'st')
      .replace(/(avenue)/g,'ave')
      .replace(/(road)/g,'rd')
      .replace(/(drive)/g,'dr')
      .replace(/(lane)/g,'ln')
      .replace(/(michigan)/g,'mi')
      .replace(/[^a-z0-9]+/g,' ')
      .trim();
  }
  function dedupeParsedSales(parsed){
    const seen = new Set();
    const existing = new Set(sales.map(s=>addressKey(s.address)).filter(Boolean));
    const out = [];
    parsed.forEach(p=>{
      if(!p || !p.address) return;
      const key = addressKey(p.address);
      if(!key) return;
      if(seen.has(key) || existing.has(key)) return;
      seen.add(key);
      out.push(p);
    });
    return out;
  }
  function importSalesFromText(text, fromPhoto=false){
    const cleaned = cleanOcrText(text);
    if(!cleaned){ alert(fromPhoto ? 'No text was read from that photo.' : 'Paste or read some listing text first.'); return false; }
    const chunks = extractSaleChunks(cleaned);
    const parsed = chunks.map(parseSaleFromText);
    const withAddress = dedupeParsedSales(parsed);
    if(withAddress.length <= 1){
      fillFormFromParsed(withAddress[0] || parsed[0] || parseSaleFromText(cleaned));
      $('parseStatus').textContent += ' I only found one new safe sale/address, so I filled the form instead of importing a batch.';
      return false;
    }
    const skipped = Math.max(0, parsed.length - withAddress.length);
    const msg = 'I found '+withAddress.length+' new sales with safe addresses.' + (skipped>0 ? ' Some duplicates or possible listings without safe addresses will be skipped.' : '') + ' Add these to your list?';
    if(!confirm(msg)){
      $('parseStatus').textContent = 'Found '+withAddress.length+' importable sales. Tap Import all found when ready, or edit the text first.';
      return false;
    }
    const startOrder = nextOrder();
    withAddress.forEach((p,i)=>{
      sales.push(normalizeSale({
        id: uid(),
        title: p.title || 'Yard sale',
        address: p.address,
        date: p.date || '',
        time: p.time || '',
        notes: p.notes || '',
        include: true,
        visited: false,
        order: startOrder + i,
        geocodeVersion: 0
      }, startOrder+i));
    });
    save();
    closeModal();
    alert('Added '+withAddress.length+' sales.' + (skipped>0 ? ' Skipped duplicates/unsafe listings.' : ''));
    return true;
  }

  function loadImageFromFile(file){
    return new Promise((resolve,reject)=>{
      const img = new Image();
      img.onload = () => { URL.revokeObjectURL(img.src); resolve(img); };
      img.onerror = reject;
      img.src = URL.createObjectURL(file);
    });
  }
  function canvasToBlob(canvas){
    return new Promise(resolve=>{
      canvas.toBlob(blob=>resolve(blob || canvas.toDataURL('image/png')), 'image/png');
    });
  }
  async function makeOcrBlob(img, crop){
    const srcW = crop ? crop.w : img.naturalWidth;
    const srcH = crop ? crop.h : img.naturalHeight;
    const maxDim = Math.max(srcW, srcH);
    let scale = maxDim < 1200 ? 2 : (maxDim < 1900 ? 1.5 : 1.15);
    if(maxDim * scale > 2800) scale = 2800 / maxDim;
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(srcW * scale));
    canvas.height = Math.max(1, Math.round(srcH * scale));
    const ctx = canvas.getContext('2d', {willReadFrequently:true});
    ctx.fillStyle = '#fff';
    ctx.fillRect(0,0,canvas.width,canvas.height);
    ctx.imageSmoothingEnabled = true;
    ctx.drawImage(img, crop ? crop.x : 0, crop ? crop.y : 0, srcW, srcH, 0, 0, canvas.width, canvas.height);
    const data = ctx.getImageData(0,0,canvas.width,canvas.height);
    let total=0;
    for(let i=0;i<data.data.length;i+=4){ total += 0.299*data.data[i] + 0.587*data.data[i+1] + 0.114*data.data[i+2]; }
    const avg = total / (data.data.length/4);
    const invert = avg < 120;
    for(let i=0;i<data.data.length;i+=4){
      let lum = 0.299*data.data[i] + 0.587*data.data[i+1] + 0.114*data.data[i+2];
      if(invert) lum = 255 - lum;
      let v = (lum - 128) * 1.75 + 128;
      if(v > 218) v = 255;
      else if(v < 72) v = 0;
      else v = Math.max(0, Math.min(255, Math.round(v)));
      data.data[i]=data.data[i+1]=data.data[i+2]=v;
      data.data[i+3]=255;
    }
    ctx.putImageData(data,0,0);
    return canvasToBlob(canvas);
  }
  async function buildOcrInputs(file){
    const img = await loadImageFromFile(file);
    const w = img.naturalWidth, h = img.naturalHeight;
    const inputs = [];
    const pushCrop = async (label, crop) => {
      inputs.push({label, image: await makeOcrBlob(img, crop)});
    };
    if(w > h * 1.12){
      // Newspaper / flyer style: listings are often in columns.
      const mid = Math.floor(w/2);
      await pushCrop('left column', {x:0,y:0,w:mid,h});
      await pushCrop('right column', {x:mid,y:0,w:w-mid,h});
      if(w > h * 1.75){
        const q1 = Math.floor(w/4), q2 = Math.floor(w/2), q3 = Math.floor(3*w/4);
        await pushCrop('column 1', {x:0,y:0,w:q1,h});
        await pushCrop('column 2', {x:q1,y:0,w:q2-q1,h});
        await pushCrop('column 3', {x:q2,y:0,w:q3-q2,h});
        await pushCrop('column 4', {x:q3,y:0,w:w-q3,h});
      }
      return inputs;
    }
    if(h > w * 1.18){
      // Facebook screenshot style: one sale post above another.
      // Use overlapping top/middle/bottom crops so a post near a cut line still gets read.
      const third = Math.floor(h/3);
      const overlap = Math.floor(h * 0.08);
      await pushCrop('top post area', {x:0,y:0,w,h:Math.min(h, third + overlap)});
      await pushCrop('middle post area', {x:0,y:Math.max(0, third - overlap),w,h:Math.min(h - Math.max(0, third - overlap), third + overlap*2)});
      await pushCrop('bottom post area', {x:0,y:Math.max(0, 2*third - overlap),w,h:h - Math.max(0, 2*third - overlap)});
      return inputs;
    }
    return [{label:'photo', image:await makeOcrBlob(img,null)}];
  }
  async function parsePhotoPost(file){
    if(!file) return;
    $('parseStatus').textContent = 'Preparing photo for text reading...';
    if(!window.Tesseract){
      $('parseStatus').textContent = 'Photo reading could not load. Check internet, or paste the text manually.';
      return;
    }
    try{
      const inputs = await buildOcrInputs(file);
      const pieces = [];
      for(let i=0;i<inputs.length;i++){
        const part = inputs[i];
        $('parseStatus').textContent = 'Reading '+part.label+'... this can take a minute.';
        const result = await Tesseract.recognize(part.image, 'eng', {
          logger: m => {
            if(!m || !m.status) return;
            const pct = typeof m.progress === 'number' ? ' ' + Math.round(m.progress * 100) + '%' : '';
            $('parseStatus').textContent = 'Reading '+part.label+': ' + m.status + pct;
          },
          tessedit_pageseg_mode: '6',
          preserve_interword_spaces: '1'
        });
        const text = cleanOcrText(result && result.data && result.data.text ? result.data.text : '');
        if(text) pieces.push(text);
      }
      const text = cleanOcrText(pieces.join('\n\n---\n\n'));
      if(!text){
        $('parseStatus').textContent = 'I could not read text from that photo. Try cropping closer, taking a brighter screenshot, or paste the post text.';
        return;
      }
      $('postPaste').value = text;
      const chunks = extractSaleChunks(text);
      const importable = dedupeParsedSales(chunks.map(parseSaleFromText)).length;
      if(importable > 1){
        $('parseStatus').textContent = 'Photo text found '+importable+' new sales with safe addresses. Use Import all found to add them, or edit the text first.';
        importSalesFromText(text, true);
        return;
      }
      parseFacebookPost(text);
      $('parseStatus').textContent += ' Text was pulled from the photo; double-check every field. Crop closer if the address looks wrong.';
    }catch(e){
      $('parseStatus').textContent = 'Could not read that photo. Try a clearer/cropped image, screenshot, or paste the post text.';
    }finally{
      $('postImageInput').value = '';
    }
  }



  function setMapInteraction(on){
    mapUnlocked = !!on;
    const wrap = $('mapWrap');
    const btn = $('mapLockBtn');
    if(wrap) wrap.classList.toggle('unlocked', mapUnlocked);
    if(btn){
      btn.textContent = mapUnlocked ? 'Lock map' : 'Move map';
      btn.classList.toggle('unlocked', mapUnlocked);
    }
    if(!map) return;
    const action = mapUnlocked ? 'enable' : 'disable';
    try{ map.dragging[action](); }catch(e){}
    try{ map.touchZoom[action](); }catch(e){}
    try{ map.doubleClickZoom[action](); }catch(e){}
    try{ map.boxZoom[action](); }catch(e){}
    try{ map.keyboard[action](); }catch(e){}
  }
  function toggleMapInteraction(){ setMapInteraction(!mapUnlocked); }

  function initMap(){
    try{
      if(!window.L) throw new Error('Leaflet missing');
      map = L.map('map',{ zoomControl:true, dragging:true, touchZoom:true, doubleClickZoom:true, scrollWheelZoom:false, boxZoom:true, keyboard:true }).setView([44.0295,-84.4864],9);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19, attribution:'&copy; OpenStreetMap'}).addTo(map);
      markersLayer = L.layerGroup().addTo(map);
      setMapInteraction(true);
      setTimeout(()=>map.invalidateSize(),250);
      scheduleMapRender();
    }catch(e){ $('map').innerHTML='<div class="empty">Map could not load, but the list and Google Maps routing still work.</div>'; }
  }
  function degreesToRad(x){ return x * Math.PI / 180; }
  function milesFromGladwin(lat, lon){
    const lat1=44.0295, lon1=-84.4864;
    const R=3958.8, dLat=degreesToRad(lat-lat1), dLon=degreesToRad(lon-lon1);
    const a=Math.sin(dLat/2)**2 + Math.cos(degreesToRad(lat1))*Math.cos(degreesToRad(lat))*Math.sin(dLon/2)**2;
    return 2*R*Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  }
  function addressForSearch(addr){ return finishAddress(addr); }
  async function geocodeSale(s){
    if(!s.address.trim()) return s;
    const searchAddress = addressForSearch(s.address);
    if(s.lat && s.lon && s.geocodedAddress===searchAddress && s.geocodeVersion===7) return s;
    try{
      const base='https://nominatim.openstreetmap.org/search?format=json&limit=5&countrycodes=us&viewbox=-86.2,45.4,-82.8,43.0&q=';
      const res=await fetch(base + encodeURIComponent(searchAddress));
      const data=await res.json();
      let choices=(data||[]).filter(x=>/Michigan|, MI,| MI /i.test(x.display_name||''));
      if(!choices.length) choices=data||[];
      choices=choices.map(x=>({...x, _miles:milesFromGladwin(parseFloat(x.lat), parseFloat(x.lon))})).sort((a,b)=>a._miles-b._miles);
      const best=choices[0];
      if(best){ s.lat=parseFloat(best.lat); s.lon=parseFloat(best.lon); s.geocodedAddress=searchAddress; s.geocodeVersion=7; saveOnly(); }
    }catch(e){}
    return s;
  }
  async function geocodeHome(){
    const q=$('homeInput').value.trim() || 'Gladwin, MI';
    $('centerStatus').textContent='Finding '+q+'...';
    try{
      const res=await fetch('https://nominatim.openstreetmap.org/search?format=json&limit=1&q='+encodeURIComponent(q));
      const data=await res.json();
      if(data && data[0] && map){ map.setView([parseFloat(data[0].lat),parseFloat(data[0].lon)],10); $('centerStatus').textContent='Centered on '+q; localStorage.setItem('salescout_home',q); }
      else $('centerStatus').textContent='Could not find that place.';
    }catch(e){ $('centerStatus').textContent='Could not use map search right now.'; }
  }
  function scheduleMapRender(){ clearTimeout(mapRenderTimer); mapRenderTimer=setTimeout(renderMap,120); }
  async function renderMap(){
    if(!map || !markersLayer) return;
    markersLayer.clearLayers();
    const bounds=[];
    for(const s of sales){
      await geocodeSale(s);
      if(s.lat && s.lon){ const marker=L.marker([s.lat,s.lon]).bindPopup('<b>'+escapeHtml(s.title||'Sale')+'</b><br>'+escapeHtml(s.address)+'<br>'+escapeHtml(dateLabel(s))); markersLayer.addLayer(marker); bounds.push([s.lat,s.lon]); }
    }
    if(bounds.length) map.fitBounds(bounds,{padding:[32,32],maxZoom:13});
    else { const home=localStorage.getItem('salescout_home')||$('homeInput').value||'Gladwin, MI'; if(home.toLowerCase().includes('gladwin')) map.setView([44.0295,-84.4864],9); }
    setTimeout(()=>map.invalidateSize(),50);
  }

  function renderList(){
    const list=filtered();
    const statText=sales.length+' saved sale'+(sales.length===1?'':'s')+' • '+routeSales().length+' in route';
    if($('stats')) $('stats').textContent=statText;
    if($('dashStats')) $('dashStats').textContent=statText;
    const box=$('salesList');
    if(!list.length){ box.innerHTML='<div class="card empty">No sales yet. Tap Add on the map screen.</div>'; return; }
    box.innerHTML=list.map(s=>`<div class="sale ${s.visited?'visited':''}"><div class="saleHead"><div><div class="saleTitle">${escapeHtml(s.title||'Untitled sale')} ${s.include===false?'<span class="badge">Not routed</span>':''}</div><div class="addr">${escapeHtml(s.address||'No address')}</div><div class="meta">${escapeHtml(dateLabel(s))}</div></div></div>${s.notes?`<div class="notes">${escapeHtml(s.notes)}</div>`:''}<div class="actions"><button class="small secondary" onclick="editSale('${s.id}')">Edit</button><button class="small secondary" onclick="openOneMap('${s.id}')">Map</button><button class="small secondary" onclick="toggleVisited('${s.id}')">${s.visited?'Unvisit':'Visited'}</button><button class="small secondary" onclick="toggleInclude('${s.id}')">${s.include===false?'Add to route':'Remove from route'}</button><button class="small danger" onclick="removeSale('${s.id}')">Delete</button></div></div>`).join('');
  }
  function renderRoute(){
    const rs=routeSales(); const box=$('routeStops'); const warn=$('routeWarn'); warn.style.display='none'; warn.textContent='';
    if(!rs.length){ box.innerHTML='<div class="empty">No route stops yet. Add sales and leave them included.</div>'; return; }
    if(rs.length>10){ warn.style.display='block'; warn.textContent='Google Maps can be picky with large routes, so the Open route button will send the first 10 stops. Split the rest into another route.'; }
    box.innerHTML=rs.map((s,i)=>`<div class="routeStop"><div><b>${i+1}. ${escapeHtml(s.title||'Sale')}</b><small>${escapeHtml(s.address||'')}</small></div><div><button class="small secondary" onclick="moveRoute('${s.id}',-1)">↑</button><button class="small secondary" onclick="moveRoute('${s.id}',1)">↓</button></div></div>`).join('');
  }
  function renderAll(){ renderList(); renderRoute(); scheduleMapRender(); }

  function openModal(s=null){
    document.body.classList.add('modal-open');
    $('saleModal').classList.add('show'); $('saleModal').setAttribute('aria-hidden','false');
    $('modalTitle').textContent=s?'Edit sale':'Add sale'; $('saleId').value=s?.id||''; $('saleTitle').value=s?.title||''; $('saleAddress').value=s?.address||''; $('saleDate').value=s?.date||todayISO(); $('saleTime').value=s?.time||''; $('saleNotes').value=s?.notes||''; $('saleInclude').checked=s?.include!==false; $('deleteSaleBtn').style.display=s?'inline-block':'none'; $('postPaste').value=''; $('parseStatus').textContent='Paste post text or upload a screenshot/photo. The app will use only sale-looking text and ignore Facebook buttons/photo clutter.';
    setTimeout(()=>$(s?'saleTitle':'postPaste').focus(),150);
  }
  function closeModal(){ document.body.classList.remove('modal-open'); $('saleModal').classList.remove('show'); $('saleModal').setAttribute('aria-hidden','true'); }
  function editSale(id){ const s=sales.find(x=>x.id===id); if(s) openModal(s); }
  function nextOrder(){ return sales.reduce((max,s)=>Math.max(max,Number(s.order)||0),0)+1; }
  function removeSale(id){ if(!id){ alert('No saved sale selected to delete.'); return; } if(confirm('Delete this sale?')){ sales=sales.filter(s=>s.id!==id); save(); closeModal(); } }
  function toggleVisited(id){ const s=sales.find(x=>x.id===id); if(s){s.visited=!s.visited; save();} }
  function toggleInclude(id){ const s=sales.find(x=>x.id===id); if(s){s.include=s.include===false; save();} }
  function moveRoute(id,dir){
    const ordered=routeSales(); const idx=ordered.findIndex(s=>s.id===id); const other=ordered[idx+dir]; if(!other) return;
    const a=sales.find(s=>s.id===id), b=sales.find(s=>s.id===other.id); const tmp=a.order; a.order=b.order; b.order=tmp; save();
  }
  function buildMapsUrl(singleAddress){
    let addrs=[];
    if(singleAddress) addrs=[addressForSearch(singleAddress)]; else addrs=routeSales().slice(0,10).map(s=>addressForSearch(s.address.trim())).filter(Boolean);
    if(!addrs.length) return '';
    let url='https://www.google.com/maps/dir/?api=1&travelmode=driving';
    const origin=($('homeInput').value||'').trim(); if(origin && !singleAddress) url+='&origin='+encodeURIComponent(origin);
    const dest=addrs[addrs.length-1]; const waypoints=addrs.slice(0,-1);
    url+='&destination='+encodeURIComponent(dest);
    if(waypoints.length) url+='&waypoints='+encodeURIComponent(waypoints.join('|'));
    return url;
  }
  function openMaps(url){ if(!url){ alert('Add at least one sale with an address first.'); return; } if(window.SaleScoutAndroid && window.SaleScoutAndroid.openMaps){ window.SaleScoutAndroid.openMaps(url); } else { window.open(url,'_blank'); } }
  function openOneMap(id){ const s=sales.find(x=>x.id===id); if(s) openMaps(buildMapsUrl(s.address)); }



  // v13: stricter photo/screenshot OCR. The old version OCRed the whole screenshot,
  // including pictures, buttons, profile names, and headers. This version detects light
  // text bands first, then filters OCR down to sale-looking text before parsing.
  function weirdCharRatio(s){
    s = String(s||'');
    if(!s) return 1;
    const allowed = s.match(/[A-Za-z0-9\s.,:;!?$#&'"()\-/–—@]/g) || [];
    return 1 - (allowed.length / s.length);
  }
  function mostlyLettersOrNumbers(s){
    s = String(s||'');
    const good = s.match(/[A-Za-z0-9]/g) || [];
    return good.length / Math.max(1, s.length);
  }
  function isFacebookUiLine(line){
    const l = String(line||'').trim();
    if(!l) return true;
    if(/^[-_=•*]+$/.test(l)) return true;
    if(/^(?:like|comment|share|send|home|watch|marketplace|notifications?|messenger|search|write a comment|view more comments|see more|see less|reply|all reactions|most relevant|top comments|admin|author|sponsored|follow|join group)$/i.test(l)) return true;
    if(/\b(?:like|comment|share)\b\s+\b(?:like|comment|share)\b/i.test(l)) return true;
    if(/^\s*[<←].{0,8}(gladwin|garage|yard|sale|group)/i.test(l)) return true;
    if(/gladwin\s+garage\s+and\s+yar/i.test(l)) return true;
    if(/garage\s+and\s+yard\s+sales?\s+group/i.test(l)) return true;
    if(/^(?:may|jun|june|jul|july|aug|august|sep|sept|oct|nov|dec|jan|feb|mar|apr)\s+\d{1,2}\s*[·•]?(?:\s*(?:public|friends|group))?$/i.test(l)) return true;
    return false;
  }
  function isOcrGarbageLine(line){
    const l = String(line||'').trim();
    if(!l) return true;
    if(l.length < 2) return true;
    if(/(?:QQ|NQF|¢|€|¬|©|®|¥|§|\|\/\/|\^|`|~)/.test(l)) return true;
    if((l.match(/[<>={}\[\]_]/g)||[]).length >= 3) return true;
    if(weirdCharRatio(l) > 0.22) return true;
    if(l.length > 18 && mostlyLettersOrNumbers(l) < 0.45) return true;
    // Many OCR artifacts from photos look like scattered short words and symbols.
    const words = l.split(/\s+/).filter(Boolean);
    if(words.length >= 5){
      const short = words.filter(w=>/^[A-Za-z]{1,2}$/.test(w)).length;
      if(short / words.length > 0.48 && !/\b(?:am|pm|mi)\b/i.test(l)) return true;
    }
    return false;
  }
  function isProbablyMetaNameLine(line){
    const l = String(line||'').trim();
    if(!l || l.length > 70) return false;
    if(/\b(?:sale|garage|yard|moving|estate|rummage|address|location|today|tomorrow|fri|sat|sun|mon|tue|wed|thu|\d{1,6}\s+\w+)\b/i.test(l)) return false;
    // Facebook author names are often two or three capitalized words.
    if(/^([A-Z][a-z]+\s+){1,4}[A-Z][a-z]+$/.test(l)) return true;
    if(/^[A-Z][A-Za-z'.-]+\s+[A-Z][A-Za-z'.-]+\s+(?:May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|Jan|Feb|Mar|Apr)\s+\d{1,2}/.test(l)) return true;
    return false;
  }
  function normalizeOcrListingLine(line){
    return String(line||'')
      .replace(/\r/g,' ')
      .replace(/[“”]/g,'"')
      .replace(/[‘’]/g,"'")
      .replace(/\b[Mm][Il1]\b/g,'MI')
      .replace(/\bGiadwin\b/gi,'Gladwin')
      .replace(/\bCiare\b/gi,'Clare')
      .replace(/\b([a-z]+)\.(?=\d)/gi,'$1. ')
      .replace(/\s+/g,' ')
      .trim();
  }
  function lineHasUsefulSaleSignal(line){
    const l = normalizeOcrListingLine(line);
    if(!l) return false;
    if(hasStreetAddress(l) || extractStrictStreetAddress(l)) return true;
    if(/\b(?:garage|yard|moving|estate|rummage|barn|tag|multi[ -]?family|sale|free sale)\b/i.test(l)) return true;
    if(/\b(?:today|tomorrow|fri(?:day)?|sat(?:urday)?|sun(?:day)?|mon(?:day)?|tue(?:sday)?|wed(?:nesday)?|thu(?:rsday)?|may|june?|july?|aug(?:ust)?|sept?|oct|nov|dec|jan|feb|mar|apr)\b/i.test(l) && /\d/.test(l)) return true;
    if(/\b\d{1,2}\s*(?:-|to|–|—)\s*\d{1,2}\s*(?:am|pm)?\b/i.test(l)) return true;
    if(ITEM_RE.test(l) && l.length < 120) return true;
    return false;
  }
  function cleanOcrText(raw){
    let text = String(raw||'')
      .replace(/\r/g,'\n')
      .replace(/[“”]/g,'"')
      .replace(/[‘’]/g,"'")
      .replace(/\bM[Il1]\b/g,'MI')
      .replace(/\bGiadwin\b/gi,'Gladwin')
      .replace(/\bCiare\b/gi,'Clare')
      .replace(/\bMiddie[ -]?town\b/gi,'Midland')
      .replace(/[ \t]+/g,' ')
      .replace(/\n[ \t]+/g,'\n')
      .replace(/[ \t]+\n/g,'\n');
    const lines = text.split('\n')
      .map(normalizeOcrListingLine)
      .filter(l=>l && !isFacebookUiLine(l) && !isOcrGarbageLine(l));
    return lines.join('\n').replace(/\n{3,}/g,'\n\n').trim();
  }
  function extractUsefulSaleTextFromOcr(raw){
    const lines = String(raw||'').split(/\n+/)
      .map(normalizeOcrListingLine)
      .filter(l=>l && !isFacebookUiLine(l) && !isOcrGarbageLine(l) && !isProbablyMetaNameLine(l));
    if(!lines.length) return '';
    const useful = [];
    for(let i=0;i<lines.length;i++){
      const l = lines[i];
      if(lineHasUsefulSaleSignal(l)) useful.push({i,l});
    }
    if(!useful.length) return '';
    // Keep sale text around useful lines, but do not keep the whole OCR dump.
    const keep = new Set();
    useful.forEach(({i})=>{
      for(let j=Math.max(0,i-1); j<=Math.min(lines.length-1,i+2); j++){
        const line = lines[j];
        if(isProbablyMetaNameLine(line) || isFacebookUiLine(line) || isOcrGarbageLine(line)) continue;
        // Keep nearby item text only if it is short and normal-looking.
        if(j!==i && !lineHasUsefulSaleSignal(line) && line.length > 100) continue;
        keep.add(j);
      }
    });
    const out = [...keep].sort((a,b)=>a-b).map(i=>lines[i]);
    return out.join('\n').replace(/\n{3,}/g,'\n\n').trim();
  }
  function realisticStreetAddress(addr){
    const a = String(addr||'').trim();
    if(!a || isOcrGarbageLine(a)) return false;
    const m = a.match(/^\s*(\d{1,6})\s+(.+?)\s+(street|st\.?|road|rd\.?|avenue|ave\.?|drive|dr\.?|lane|ln\.?|court|ct\.?|circle|cir\.?|boulevard|blvd\.?|trail|trl\.?|place|pl\.?|way|highway|hwy\.?|terrace|ter\.?|parkway|pkwy\.?|loop|path|alley)\b/i);
    if(!m) return ROUTE_RE.test(a) && /\b(?:Gladwin|Beaverton|Clare|Harrison|Midland|Mount Pleasant|West Branch|MI|Michigan)\b/i.test(a);
    const num = Number(m[1]);
    if(num < 10) return false; // avoid OCR junk like "3 REE ER A ST" becoming a route.
    const streetName = m[2].trim();
    const tokens = streetName.split(/\s+/).filter(Boolean);
    if(tokens.length > 7) return false;
    if(tokens.filter(t=>/^[A-Za-z]$/.test(t)).length > 1) return false;
    if(/(?:REE\s+ER|NQF|QQ|^[A-Z]\s+[A-Z])/i.test(streetName)) return false;
    return true;
  }
  function parsePostAddress(text){
    const lines = cleanPostText(text).split('\n').map(l=>l.trim()).filter(Boolean);
    const candidates = [];
    function add(raw, labelled=false, why=''){
      const cleaned = cleanAddressCandidate(raw);
      if(!cleaned || !realisticStreetAddress(cleaned)) return;
      const score = scoreAddressCandidate(cleaned, labelled);
      if(score > 0) candidates.push({raw:cleaned, score, labelled, why});
    }
    for(let i=0;i<lines.length;i++){
      const line = lines[i];
      if(isFacebookUiLine(line) || isOcrGarbageLine(line)) continue;
      if(/^(?:address|addy|location|where|located\s+at|located|place|pickup|pick up)\s*[:\-–—]?\s*$/i.test(line) && lines[i+1]) add(lines[i+1], true, 'label-next-line');
      if(/^(?:address|addy|location|where|located\s+at|located|place|pickup|pick up)\s*[:\-–—]\s+/i.test(line)) add(line, true, 'label');
      const inline = line.match(/\b(?:address|addy|location|where|located\s+at|located|pickup|pick up)\s*[:\-–—]?\s+(.{3,110})$/i);
      if(inline) add(inline[1], true, 'inline-label');
      const atStreet = line.match(/\b(?:at|@)\s+(\d{1,6}\s+[^\n]{2,95})/i);
      if(atStreet) add(atStreet[1], false, 'at-street');
      // This handles full sentences: "Yard Sale today 2645 lakeshore dr.1 -6 pm..."
      const strict = extractStrictStreetAddress(line);
      if(strict) add(strict, false, 'street-inside-line');
    }
    candidates.sort((a,b)=>b.score-a.score);
    const best = candidates[0];
    if(best && best.score >= 70) return {address:finishAddress(best.raw), confidence:best.score>=95?'high':'medium', warning:best.score>=95?'':'Possible address found — double-check it before saving.'};
    const city = cleanPostText(text).match(LOCAL_CITY_RE);
    if(city) return {address:'', city:city[0].replace(/Mt\.?/i,'Mount') + ', MI', confidence:'city-only', warning:'I only found the city. I left the address blank so it does not route to the wrong place.'};
    return {address:'', city:'', confidence:'none', warning:'I did not find a safe address, so I left the address blank instead of guessing.'};
  }
  function parsePostTitle(text){
    const lines = cleanPostText(text).split('\n').map(l=>l.trim()).filter(Boolean).filter(l=>!isFacebookUiLine(l) && !isOcrGarbageLine(l) && !isProbablyMetaNameLine(l));
    for(const l of lines){
      const m = l.match(/\b((?:large\s+|huge\s+|multi[ -]?family\s+|neighborhood\s+|church\s+|barn\s+)?(?:garage|yard|moving|estate|rummage|tag)\s+sale)\b/i);
      if(m) return m[1].replace(/\s+/g,' ').replace(/\b\w/g,c=>c.toUpperCase());
    }
    return 'Yard sale';
  }
  function likelySaleChunk(chunk){
    const c = extractUsefulSaleTextFromOcr(cleanOcrText(chunk));
    if(c.length < 8) return false;
    const hasSale = /\b(garage|yard|moving|estate|rummage|barn|tag|multi[ -]?family|sale)\b/i.test(c);
    const hasAddr = !!parsePostAddress(c).address;
    return (hasSale && (hasAddr || parsePostDate(c).iso || parsePostTime(c).time)) || (hasAddr && (parsePostTime(c).time || parsePostDate(c).iso));
  }
  function extractSaleChunks(text){
    const cleaned = cleanOcrText(text);
    if(!cleaned) return [];
    // If OCR was joined with explicit separators from image crops, keep those blocks separate.
    const hardParts = cleaned.split(/\n\s*(?:---SALESCOUT-CROP---|-{3,}|={3,}|_{3,}|\*{3,}|•{3,})\s*\n/g)
      .map(extractUsefulSaleTextFromOcr)
      .filter(likelySaleChunk);
    if(hardParts.length > 1) return hardParts;
    const lines = cleaned.split('\n').map(l=>l.trim()).filter(Boolean);
    const starts = [];
    for(let i=0;i<lines.length;i++){
      const l = lines[i];
      if(isFacebookUiLine(l) || isOcrGarbageLine(l) || isProbablyMetaNameLine(l)) continue;
      if(/\b(large\s+)?(garage|yard|moving|estate|rummage|barn|tag|multi[ -]?family)\s+sale\b/i.test(l) || parsePostAddress(l).address) starts.push(i);
    }
    const uniqueStarts = starts.filter((x,i)=>i===0 || x-starts[i-1] > 2);
    if(uniqueStarts.length > 1){
      const chunks=[];
      for(let i=0;i<uniqueStarts.length;i++){
        const start=uniqueStarts[i];
        const end=i+1<uniqueStarts.length ? uniqueStarts[i+1]-1 : lines.length-1;
        const chunk=extractUsefulSaleTextFromOcr(lines.slice(start,end+1).join('\n'));
        if(likelySaleChunk(chunk)) chunks.push(chunk);
      }
      if(chunks.length > 1) return chunks;
    }
    return [extractUsefulSaleTextFromOcr(cleaned) || cleaned].filter(Boolean);
  }
  function isSafeParsedSale(p){
    if(!p || !p.address) return false;
    if(!realisticStreetAddress(p.address)) return false;
    const raw = cleanOcrText(p._raw || p.notes || '');
    if(isOcrGarbageLine(p.title || '')) return false;
    if(raw && weirdCharRatio(raw) > 0.16) return false;
    return true;
  }
  function importSalesFromText(text, fromPhoto=false){
    const cleaned = cleanOcrText(text);
    if(!cleaned){ alert(fromPhoto ? 'No sale text was read from that photo.' : 'Paste or read some listing text first.'); return false; }
    const chunks = extractSaleChunks(cleaned);
    const parsed = chunks.map(parseSaleFromText).filter(isSafeParsedSale);
    const withAddress = dedupeParsedSales(parsed);
    if(withAddress.length <= 1){
      const one = withAddress[0] || parseSaleFromText(chunks[0] || cleaned);
      fillFormFromParsed(one);
      $('parseStatus').textContent += ' I only found one safe sale/address, so I filled the form instead of importing a batch.';
      return false;
    }
    withAddress.forEach(p=>{
      sales.push({id:uid(), title:p.title||'Yard sale', address:p.address, date:p.date||'', time:p.time||'', notes:p.notes||'', include:true, visited:false, order:nextOrder(), lat:null, lon:null, geocodedAddress:'', geocodeVersion:0});
    });
    save();
    closeModal();
    alert('Imported '+withAddress.length+' sales. I skipped anything without a safe address.');
    return true;
  }
  function canvasFromImage(img){
    const canvas = document.createElement('canvas');
    canvas.width = img.naturalWidth;
    canvas.height = img.naturalHeight;
    const ctx = canvas.getContext('2d', {willReadFrequently:true});
    ctx.drawImage(img,0,0);
    return {canvas, ctx};
  }
  function detectLightTextBands(img){
    const {canvas, ctx} = canvasFromImage(img);
    const w=canvas.width, h=canvas.height;
    const data = ctx.getImageData(0,0,w,h).data;
    const stepY = Math.max(2, Math.floor(h/520));
    const stepX = Math.max(4, Math.floor(w/120));
    const rows=[];
    for(let y=0;y<h;y+=stepY){
      let light=0, total=0;
      for(let x=Math.floor(w*0.04); x<Math.floor(w*0.96); x+=stepX){
        const i=(y*w+x)*4;
        const r=data[i], g=data[i+1], b=data[i+2];
        const lum=0.299*r+0.587*g+0.114*b;
        const neutral=(Math.max(r,g,b)-Math.min(r,g,b))<48;
        if(lum>224 && neutral) light++;
        total++;
      }
      rows.push({y, lightRatio:light/Math.max(1,total)});
    }
    const bands=[];
    let inBand=false, start=0, last=0;
    for(const row of rows){
      const isLight=row.lightRatio>0.50;
      if(isLight && !inBand){ inBand=true; start=row.y; }
      if(isLight) last=row.y;
      if(!isLight && inBand){
        if(last-start > 28) bands.push({y:Math.max(0,start-8), h:Math.min(h, last+stepY+8)-Math.max(0,start-8)});
        inBand=false;
      }
    }
    if(inBand && last-start > 28) bands.push({y:Math.max(0,start-8), h:Math.min(h, last+stepY+8)-Math.max(0,start-8)});
    // Merge close bands, because author/date and post text may be separated by tiny gutters.
    const merged=[];
    for(const b of bands){
      const prev=merged[merged.length-1];
      if(prev && b.y - (prev.y+prev.h) < 34){ prev.h = Math.max(prev.y+prev.h, b.y+b.h)-prev.y; }
      else merged.push({...b});
    }
    return merged.filter(b=>b.h>=42 && b.h<=Math.min(420, h*0.42));
  }
  async function buildOcrInputs(file){
    const img = await loadImageFromFile(file);
    const w = img.naturalWidth, h = img.naturalHeight;
    const inputs = [];
    const pushCrop = async (label, crop) => inputs.push({label, image: await makeOcrBlob(img, crop)});
    if(h > w * 1.08){
      const bands = detectLightTextBands(img);
      // Use only light text bands for Facebook-style screenshots, not the photo area.
      for(let i=0;i<Math.min(bands.length,8);i++){
        const b = bands[i];
        await pushCrop('text area '+(i+1), {x:0, y:b.y, w, h:b.h});
      }
      if(inputs.length) return inputs;
      // Fallback: top/middle/bottom strips, but only shallow strips to avoid the big photos.
      const third=Math.floor(h/3);
      await pushCrop('top text strip', {x:0,y:0,w,h:Math.min(h, third)});
      await pushCrop('middle text strip', {x:0,y:third,w,h:third});
      await pushCrop('bottom text strip', {x:0,y:third*2,w,h:h-third*2});
      return inputs;
    }
    if(w > h * 1.12){
      const mid = Math.floor(w/2);
      await pushCrop('left column', {x:0,y:0,w:mid,h});
      await pushCrop('right column', {x:mid,y:0,w:w-mid,h});
      return inputs;
    }
    return [{label:'photo', image:await makeOcrBlob(img,null)}];
  }
  async function parsePhotoPost(file){
    if(!file) return;
    $('parseStatus').textContent = 'Preparing screenshot/photo. I will ignore buttons, headers, and photo areas when possible...';
    if(!window.Tesseract){
      $('parseStatus').textContent = 'Photo reading could not load. Check internet, or paste the text manually.';
      return;
    }
    try{
      const inputs = await buildOcrInputs(file);
      const usefulPieces = [];
      for(let i=0;i<inputs.length;i++){
        const part = inputs[i];
        $('parseStatus').textContent = 'Reading '+part.label+'... this can take a minute.';
        const result = await Tesseract.recognize(part.image, 'eng', {
          logger: m => {
            if(!m || !m.status) return;
            const pct = typeof m.progress === 'number' ? ' ' + Math.round(m.progress * 100) + '%' : '';
            $('parseStatus').textContent = 'Reading '+part.label+': ' + m.status + pct;
          },
          tessedit_pageseg_mode: '6',
          preserve_interword_spaces: '1'
        });
        const raw = result && result.data && result.data.text ? result.data.text : '';
        const useful = extractUsefulSaleTextFromOcr(raw);
        if(useful && likelySaleChunk(useful)) usefulPieces.push(useful);
      }
      const unique = [];
      const seen = new Set();
      usefulPieces.forEach(t=>{
        const key = t.toLowerCase().replace(/[^a-z0-9]+/g,' ').slice(0,160);
        if(key && !seen.has(key)){ seen.add(key); unique.push(t); }
      });
      const text = unique.join('\n\n---SALESCOUT-CROP---\n\n').trim();
      if(!text){
        $('postPaste').value = '';
        $('parseStatus').textContent = 'I could not find clean sale text in that screenshot. Crop closer to just the post text, or copy/paste the post text.';
        return;
      }
      $('postPaste').value = text;
      const chunks = extractSaleChunks(text);
      const safeCount = dedupeParsedSales(chunks.map(parseSaleFromText).filter(isSafeParsedSale)).length;
      if(safeCount > 1){
        $('parseStatus').textContent = 'I found '+safeCount+' safe sale listings. Review the text, then tap Import all found.';
        return;
      }
      fillFormFromParsed(parseSaleFromText(chunks[0] || text));
      $('parseStatus').textContent += ' I ignored Facebook buttons/headers/photo text as much as possible. Still double-check the address.';
    }catch(e){
      $('parseStatus').textContent = 'Could not read that photo. Try a clearer/cropped screenshot, or paste the post text.';
    }finally{
      $('postImageInput').value = '';
    }
  }

  $('openAddBtn').onclick=()=>openModal(); $('cancelSaleBtn').onclick=closeModal; $('parsePostBtn').onclick=()=>parseFacebookPost($('postPaste').value); $('importAllBtn').onclick=()=>importSalesFromText($('postPaste').value,false); $('photoPostBtn').onclick=()=>$('postImageInput').click(); $('postImageInput').addEventListener('change',e=>parsePhotoPost(e.target.files && e.target.files[0])); $('clearPostBtn').onclick=()=>{ $('postPaste').value=''; $('parseStatus').textContent='Paste post text or upload a screenshot/photo. The app will use only sale-looking text and ignore Facebook buttons/photo clutter.'; $('postPaste').focus(); }; $('saleModal').addEventListener('click',e=>{ if(e.target.id==='saleModal') closeModal(); });
  $('saveSaleBtn').onclick=()=>{
    const id=$('saleId').value||uid(); const addr=$('saleAddress').value.trim();
    if(!addr){ alert('Type an address first so Google Maps can route to it.'); $('saleAddress').focus(); return; }
    let existing=sales.find(s=>s.id===id);
    if(!existing){ existing={id, order:nextOrder()}; sales.push(existing); }
    const oldAddr=existing.address||'';
    existing.title=$('saleTitle').value.trim()||'Yard sale'; existing.address=addr; existing.date=$('saleDate').value; existing.time=$('saleTime').value; existing.notes=$('saleNotes').value.trim(); existing.include=$('saleInclude').checked; existing.visited=!!existing.visited;
    if(oldAddr!==addr){ existing.lat=null; existing.lon=null; existing.geocodedAddress=''; }
    save(); closeModal();
  };
  $('deleteSaleBtn').onclick=()=>removeSale($('saleId').value);
  $('centerBtn').onclick=geocodeHome; if($('mapLockBtn')) $('mapLockBtn').onclick=toggleMapInteraction; $('homeInput').value=localStorage.getItem('salescout_home')||'Gladwin, MI'; $('homeInput').addEventListener('change',()=>localStorage.setItem('salescout_home',$('homeInput').value.trim()));
  function updateScreenMode(){ document.body.classList.toggle('map-screen', $('mapScreen').classList.contains('active')); }
  document.querySelectorAll('[data-screen]').forEach(btn=>btn.onclick=()=>{ document.querySelectorAll('.screen').forEach(s=>s.classList.remove('active')); document.querySelectorAll('.tabs button').forEach(b=>b.classList.remove('active')); $(btn.dataset.screen).classList.add('active'); btn.classList.add('active'); updateScreenMode(); if(btn.dataset.screen==='mapScreen' && map) setTimeout(()=>map.invalidateSize(),220); });
  document.querySelectorAll('[data-filter]').forEach(btn=>btn.onclick=()=>{ filter=btn.dataset.filter; renderList(); });
  $('clearVisitedBtn').onclick=()=>{ if(confirm('Delete all visited sales?')){ sales=sales.filter(s=>!s.visited); save(); } };
  $('openRouteBtn').onclick=()=>openMaps(buildMapsUrl()); $('copyRouteBtn').onclick=()=>{ const box=$('routeLinkBox'); box.style.display='block'; box.textContent=buildMapsUrl()||'No route yet.'; };
  $('exportBtn').onclick=()=>{ $('backupText').value=JSON.stringify({version:13, exported:new Date().toISOString(), sales:sales.map(normalizeSale)}, null, 2); $('backupText').focus(); $('backupText').select(); };
  $('importBtn').onclick=()=>{ try{ const data=JSON.parse($('backupText').value); if(Array.isArray(data.sales)){ if(confirm('Replace your current list with this backup?')){ sales=data.sales.map(normalizeSale); save(); alert('Imported.'); } } else alert('That backup text does not look right.'); }catch(e){ alert('Could not read backup text.'); } };
  window.editSale=editSale; window.removeSale=removeSale; window.toggleVisited=toggleVisited; window.toggleInclude=toggleInclude; window.moveRoute=moveRoute; window.openOneMap=openOneMap;
  updateScreenMode(); load(); initMap(); renderAll();
  