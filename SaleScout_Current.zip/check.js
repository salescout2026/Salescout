<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover" />
  <title>SaleScout</title>
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
  <style>
    :root{
      --green:#2d804e; --green-dark:#1f6b3e; --bg:#f6faf6; --card:#fff; --text:#142018;
      --muted:#647067; --line:#dfe8e0; --danger:#b3261e; --shadow:0 10px 24px rgba(0,0,0,.08);
      --bottom:84px;
    }
    *{box-sizing:border-box;-webkit-tap-highlight-color:transparent}
    html,body{margin:0;min-height:100%;font-family:system-ui,-apple-system,Segoe UI,Roboto,Arial,sans-serif;background:var(--bg);color:var(--text);overflow-x:hidden}
    body{padding-top:env(safe-area-inset-top);padding-bottom:env(safe-area-inset-bottom)}
    body.map-screen{height:100dvh;display:flex;flex-direction:column;overflow:hidden}
    header{position:sticky;top:0;z-index:50;background:var(--green);color:#fff;padding:9px 12px 10px;box-shadow:var(--shadow);flex:0 0 auto}
    body.map-screen header{position:relative}
    .brand{display:flex;gap:10px;align-items:center}.logo{width:48px;height:48px;border-radius:14px;background:#fff;color:var(--green);display:grid;place-items:center;font-weight:900;font-size:19px;box-shadow:0 4px 12px rgba(0,0,0,.15);flex:0 0 auto}
    h1{font-size:28px;line-height:.95;margin:0;font-weight:900;letter-spacing:-1px}.tag{font-size:15px;opacity:.94;margin-top:5px}
    main{padding:12px 12px calc(var(--bottom) + 18px);max-width:760px;margin:0 auto;width:100%}
    body.map-screen main{flex:1 1 auto;min-height:0;overflow:hidden;padding:8px 10px calc(var(--bottom) + 6px);display:flex;flex-direction:column}
    .card{background:var(--card);border:1px solid var(--line);border-radius:18px;padding:14px;margin-bottom:12px;box-shadow:var(--shadow)}
    .row{display:flex;gap:10px;align-items:center}.row>*{min-width:0}.grow{flex:1}
    label{display:block;font-weight:850;margin:7px 0 5px;font-size:14px;color:#445048}
    input,textarea,select{width:100%;border:1px solid #ccd8ce;border-radius:13px;background:#fff;padding:12px;font-size:16px;color:var(--text);outline:none} textarea{min-height:86px;resize:vertical}
    input:focus,textarea:focus{border-color:var(--green);box-shadow:0 0 0 3px rgba(45,128,78,.14)}
    button{border:0;border-radius:14px;background:var(--green);color:white;padding:12px 14px;font-weight:900;font-size:16px;box-shadow:0 3px 10px rgba(45,128,78,.22)}
    button:active{transform:translateY(1px)} button.secondary{background:#e8f1e9;color:#173820;box-shadow:none;border:1px solid #cfe0d2} button.danger{background:#fff;color:var(--danger);border:1px solid #efc6c1;box-shadow:none} button.small{font-size:13px;padding:8px 10px;border-radius:11px}.wide{width:100%}
    .tabs{position:fixed;left:0;right:0;bottom:0;z-index:100;display:flex;gap:10px;padding:10px 12px calc(10px + env(safe-area-inset-bottom));background:rgba(45,128,78,.97);backdrop-filter:blur(8px);box-shadow:0 -8px 20px rgba(0,0,0,.12)}
    .tabs button{flex:1;background:rgba(255,255,255,.18);border:1px solid rgba(255,255,255,.35);box-shadow:none}.tabs button.active{background:#fff;color:var(--green)}
    .screen{display:none}.screen.active{display:block}.hint{color:var(--muted);font-size:14px;line-height:1.35}.empty{padding:26px 10px;text-align:center;color:var(--muted)}
    body.map-screen #mapScreen.active{display:flex;flex-direction:column;gap:8px;min-height:0;flex:1} body.map-screen #mapScreen .card{margin-bottom:0} .dashboard{padding:11px 12px}.dashStatsRow{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-top:8px}.dashStatsRow button{padding:11px 14px;white-space:nowrap}.mapCard{min-height:0}.compactNote{font-size:12px;color:var(--muted);margin-top:5px;display:none}
    .mapWrap{position:relative;height:min(390px,52vh);border-radius:16px;overflow:hidden;border:1px solid var(--line);background:#dfe9db;flex:0 0 auto} #map{height:100%;width:100%;overflow:hidden;background:#dfe9db;position:relative;z-index:1} body.map-screen .mapWrap{height:auto;flex:1;min-height:210px} body.map-screen #map{height:100%;min-height:0} body.map-screen .mapCard{flex:1;display:flex;flex-direction:column;padding:10px}.mapNote{font-size:12px;color:var(--muted);margin-top:7px} body.map-screen .mapNote{display:none}.mapLockBtn{position:absolute;right:10px;top:10px;z-index:5;border-radius:999px;background:#fff;color:var(--green);border:1px solid rgba(45,128,78,.35);box-shadow:0 4px 14px rgba(0,0,0,.18);font-size:13px;padding:8px 11px}.mapLockBtn.unlocked{background:#fff3f0;color:var(--danger);border-color:#efc6c1}.mapLockHint{position:absolute;left:10px;right:10px;bottom:10px;z-index:4;background:rgba(255,255,255,.92);border:1px solid rgba(45,128,78,.18);border-radius:12px;padding:7px 9px;font-size:12px;color:var(--muted);box-shadow:0 3px 10px rgba(0,0,0,.1);pointer-events:none}.mapWrap.unlocked .mapLockHint{display:none}
    .leaflet-pane,.leaflet-top,.leaflet-bottom{z-index:1!important}.leaflet-control{z-index:2!important}.leaflet-container{font-family:inherit}
    body.modal-open #map{pointer-events:none}
    .sale{border:1px solid var(--line);border-radius:15px;padding:12px;margin:10px 0;background:white}.saleHead{display:flex;gap:10px;justify-content:space-between}.saleTitle{font-size:18px;font-weight:900}.addr{color:#23527a;font-weight:750;margin-top:3px}.meta{font-size:13px;color:var(--muted);margin-top:4px}.notes{white-space:pre-wrap;margin-top:8px;font-size:14px}.actions{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}.badge{display:inline-block;font-size:12px;font-weight:900;padding:4px 8px;border-radius:999px;background:#eaf3eb;color:#1c673b;margin-left:4px}.visited .saleTitle,.visited .addr,.visited .notes{opacity:.55;text-decoration:line-through}.checkline{display:flex;align-items:center;gap:9px;margin-top:11px;font-size:15px}.checkline input{width:20px;height:20px}
    .topTools{display:flex;gap:8px;flex-wrap:wrap;margin-bottom:10px}.stats{font-size:14px;color:var(--muted);font-weight:750}.routeBox{background:#eef7ef;border:1px solid #d2e7d5;border-radius:14px;padding:12px;margin:10px 0}.routeStop{display:flex;gap:8px;align-items:center;justify-content:space-between;padding:9px 0;border-bottom:1px solid #d8eadb}.routeStop:last-child{border-bottom:0}.routeStop b{font-size:14px}.routeStop small{display:block;color:var(--muted);overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:230px}.warn{background:#fff7e6;border:1px solid #f0d69b;color:#664500;border-radius:12px;padding:10px;margin-top:10px;font-size:14px}
    .modal{position:fixed;inset:0;z-index:20000;background:rgba(0,0,0,.54);display:none;align-items:flex-end}.modal.show{display:flex}.sheet{position:relative;z-index:20001;background:#fff;width:100%;max-width:760px;margin:0 auto;border-radius:24px 24px 0 0;padding:16px 14px calc(20px + env(safe-area-inset-bottom));max-height:calc(100dvh - 18px);overflow:auto;box-shadow:0 -8px 30px rgba(0,0,0,.22)}.sheet h2{margin:0 0 8px}.split{display:grid;grid-template-columns:1fr 1fr;gap:10px}.formActions{position:sticky;bottom:0;background:linear-gradient(rgba(255,255,255,.85),#fff 30%);padding-top:10px;margin-top:8px}.smallText{font-size:12px;color:var(--muted);margin-top:4px}.linkbox{word-break:break-word;background:#f4f8f4;border:1px solid var(--line);padding:10px;border-radius:12px;margin-top:10px;display:none}

    .parseBox{background:#f2f8f3;border:1px solid #d3e6d6;border-radius:16px;padding:12px;margin:8px 0 12px}
    .parseBox textarea{min-height:105px;background:#fbfffb}
    .parseStatus{font-size:13px;color:#285b36;font-weight:750;margin-top:8px;line-height:1.35}.hiddenFile{position:absolute!important;left:-10000px!important;top:auto!important;width:1px!important;height:1px!important;opacity:.01!important;overflow:hidden!important}.photoHint{font-size:12px;color:var(--muted);line-height:1.3;margin-top:6px}
    .fakeFileBtn{display:inline-flex;align-items:center;justify-content:center;border:0;border-radius:14px;background:#e8f1e9;color:#173820;padding:12px 14px;font-weight:900;font-size:16px;box-shadow:none;border:1px solid #cfe0d2;min-height:46px;cursor:pointer;user-select:none}
    .fakeFileBtn:active{transform:translateY(1px)}
    .multiPreview{margin-top:10px;background:#fff;border:1px solid var(--line);border-radius:14px;padding:10px}
    .previewTabs{display:flex;gap:6px;overflow-x:auto;padding-bottom:4px;margin-bottom:8px}
    .previewTabs button{padding:8px 10px;border-radius:999px;border:1px solid #d3e6d6;background:#eef7f0;font-size:13px;font-weight:800;white-space:nowrap}
    .previewTabs button.active{background:var(--green);color:#fff;border-color:var(--green)}
    .previewCard{font-size:13px;line-height:1.35;color:#243429}
    .previewCard b{color:#12351f}
    .previewWarn{background:#fff3cd;color:#684b00;border-radius:10px;padding:7px 8px;margin:6px 0;font-weight:750}
    .previewActions{display:flex;gap:8px;flex-wrap:wrap;margin-top:8px}
    .previewActions button{font-size:13px;padding:8px 10px}
    .divider{height:1px;background:var(--line);margin:12px 0}
    @media(max-height:760px){header{padding:7px 10px 8px}.logo{width:42px;height:42px;border-radius:12px}h1{font-size:25px}.tag{font-size:13px}.dashboard{padding:9px 10px}.card{border-radius:16px}.hint{font-size:13px}input{padding:10px}body.map-screen #map{min-height:180px}}
    @media(min-width:700px){.modal{align-items:center}.sheet{border-radius:24px;max-width:620px}.tabs{left:50%;transform:translateX(-50%);max-width:760px;border-radius:22px 22px 0 0}.routeStop small{max-width:480px}}

    /* First-time tutorial */
    .tutorialHelpBtn{position:fixed;right:12px;top:calc(10px + env(safe-area-inset-top));z-index:130;width:42px;height:42px;border-radius:999px;background:rgba(255,255,255,.96);color:var(--green);border:1px solid rgba(255,255,255,.75);box-shadow:0 4px 14px rgba(0,0,0,.20);display:grid;place-items:center;font-size:22px;font-weight:950;padding:0}
    .tutorialOverlay{position:fixed;inset:0;z-index:30000;background:rgba(7,23,13,.70);display:none;align-items:flex-end;padding:12px;padding-bottom:calc(12px + env(safe-area-inset-bottom))}
    .tutorialOverlay.show{display:flex}
    .tutorialCard{width:100%;max-width:620px;margin:0 auto;background:#fff;border-radius:24px;padding:18px 16px 16px;box-shadow:0 18px 50px rgba(0,0,0,.28);border:1px solid rgba(255,255,255,.8)}
    .tutorialTop{display:flex;align-items:center;gap:12px;margin-bottom:10px}.tutorialIcon{width:50px;height:50px;border-radius:14px;background:var(--green);color:#fff;display:grid;place-items:center;font-weight:950;font-size:22px;flex:0 0 auto}.tutorialKicker{font-size:12px;letter-spacing:.08em;text-transform:uppercase;color:var(--green);font-weight:950}.tutorialTitle{font-size:23px;font-weight:950;line-height:1.05;margin-top:2px}.tutorialText{font-size:16px;line-height:1.38;color:#334139;margin:10px 0 14px}.tutorialText ul{padding-left:20px;margin:8px 0}.tutorialText li{margin:5px 0}.tutorialProgress{display:flex;align-items:center;gap:6px;margin:6px 0 14px}.tutorialDot{height:8px;width:8px;border-radius:999px;background:#d8e6da}.tutorialDot.active{width:26px;background:var(--green)}.tutorialActions{display:flex;gap:9px;flex-wrap:wrap}.tutorialActions button{flex:1;min-width:92px}.tutorialClose{position:absolute;opacity:0;pointer-events:none}
    @media(min-width:700px){.tutorialOverlay{align-items:center}.tutorialCard{border-radius:24px}}

  </style>
</head>
<body class="map-screen">

  <button id="tutorialHelpBtn" class="tutorialHelpBtn" title="Show help" aria-label="Show help">?</button>
  <div id="tutorialOverlay" class="tutorialOverlay" aria-hidden="true">
    <div class="tutorialCard" role="dialog" aria-modal="true" aria-labelledby="tutorialTitle">
      <div class="tutorialTop">
        <div class="tutorialIcon">SS</div>
        <div>
          <div class="tutorialKicker" id="tutorialStepLabel">Quick start</div>
          <div class="tutorialTitle" id="tutorialTitle">Welcome to SaleScout</div>
        </div>
      </div>
      <div class="tutorialText" id="tutorialText"></div>
      <div class="tutorialProgress" id="tutorialProgress"></div>
      <div class="tutorialActions">
        <button class="secondary" id="tutorialSkipBtn" type="button">Skip</button>
        <button class="secondary" id="tutorialBackBtn" type="button">Back</button>
        <button id="tutorialNextBtn" type="button">Next</button>
      </div>
    </div>
  </div>

  <header><div class="brand"><div class="logo">SS</div><div><h1>SaleScout</h1><div class="tag">Family yard-sale planner</div></div></div></header>
  <main>
    <section id="mapScreen" class="screen active">
      <div class="card dashboard">
        <div class="row"><div class="grow"><label>Start from</label><input id="homeInput" value="Gladwin, MI" autocomplete="street-address" /></div><button id="centerBtn" title="Center map">Map</button></div>
        <div class="dashStatsRow"><div><div class="stats" id="dashStats">0 saved sales • 0 in route</div><div class="compactNote" id="centerStatus">Manual family mode.</div></div><button id="openAddBtn">+ Add sale</button></div>
      </div>
      <div class="card mapCard"><div class="mapWrap unlocked" id="mapWrap"><div id="map"></div></div><div class="mapNote">Pins use OpenStreetMap. If exact pinning fails, SaleScout shows an approximate pin and Google Maps still routes by address.</div></div>
    </section>

    <section id="listScreen" class="screen">
      <div class="card">
        <div class="topTools"><button class="secondary small" data-filter="all">All</button><button class="secondary small" data-filter="today">Today</button><button class="secondary small" data-filter="week">This week</button><button class="secondary small" id="clearVisitedBtn">Clear visited</button></div>
        <div class="stats" id="stats"></div>
      </div>
      <div id="salesList"></div>
    </section>

    <section id="routeScreen" class="screen">
      <div class="card"><h2 style="margin-top:0">Route</h2><div class="hint">Included sales that are not marked visited will be sent to Google Maps. Use ↑/↓ to change the order.</div><div class="routeBox" id="routeStops"></div><div id="routeWarn" class="warn" style="display:none"></div><button id="openRouteBtn" class="wide">Open route in Google Maps</button><button class="secondary wide" id="copyRouteBtn" style="margin-top:8px">Show route link</button><div id="routeLinkBox" class="linkbox"></div></div>
      <div class="card"><h3 style="margin-top:0">Backup / share</h3><div class="hint">Copy the day’s list to another phone. This is manual, not automatic sync.</div><div class="actions"><button class="secondary" id="exportBtn">Show backup text</button><button class="secondary" id="importBtn">Import backup text</button></div><textarea id="backupText" placeholder="Backup text appears here, or paste backup text here to import." style="margin-top:10px"></textarea></div>
    </section>
  </main>

  <nav class="tabs"><button class="active" data-screen="mapScreen">Map</button><button data-screen="listScreen">List</button><button data-screen="routeScreen">Route</button></nav>

  <div id="saleModal" class="modal" aria-hidden="true">
    <div class="sheet">
      <h2 id="modalTitle">Add sale</h2>
      <input type="hidden" id="saleId">
      <div class="parseBox">
        <label>Post text or photo</label>
        <textarea id="postPaste" placeholder=""></textarea>
        <input class="hiddenFile" id="postImageInput" type="file" accept="image/*" multiple>
        <div class="actions">
          <button class="secondary" id="parsePostBtn" type="button">Break down text</button>
          <label class="fakeFileBtn" id="photoPostBtn" for="postImageInput" role="button" tabindex="0">Upload photo(s)</label>
          <button class="secondary" id="clearPostBtn" type="button">Clear</button>
        </div>
        <div class="photoHint">For Facebook screenshots, crop close to the post text when you can. The app now ignores buttons, headers, and photo areas as much as possible.</div>
        <div id="parseStatus" class="parseStatus">Paste post text or upload a screenshot/photo. The app will use only sale-looking text and ignore Facebook buttons/photo clutter.</div>
        <div id="multiPreview" class="multiPreview" style="display:none"></div>
      </div>
      <div class="divider"></div>
      <label>Sale name</label>
      <input id="saleTitle" placeholder="Example: Church rummage sale">
      <label>Address</label>
      <input id="saleAddress" placeholder="123 Main St, Gladwin, MI" autocomplete="street-address">
      <div class="smallText">The address is what Google Maps uses for routing. Check this field after parsing text or a photo.</div>
      <div class="split">
        <div><label>Date</label><input id="saleDate" type="date"></div>
        <div><label>Start time</label><input id="saleTime" type="time"></div>
      </div>
      <label>Notes / what to look for</label>
      <textarea id="saleNotes" placeholder="Tools, kids clothes, reef tank stuff, furniture..."></textarea>
      <div class="checkline"><input id="saleInclude" type="checkbox" checked><span>Include in route</span></div>
      <div class="actions formActions">
        <button id="saveSaleBtn">Save sale</button>
        <button id="saveAllFoundBtn" class="secondary" type="button" style="display:none">Save all found</button>
        <button class="secondary" id="cancelSaleBtn">Cancel</button>
        <button class="danger" id="deleteSaleBtn" style="display:none">Delete</button>
      </div>
    </div>
  </div>

  <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/tesseract.min.js"></script>
  <script>
  const STORAGE_KEY = 'salescout_family_manual_v2'; // keep v2 key so your saved sales stay after updating
  const LEGACY_KEYS = ['salescout_family_manual_v1'];
  let sales = [];
  let filter = 'all';
  let map, markersLayer, mapRenderTimer = null;
  let mapUnlocked = true;
  const $ = id => document.getElementById(id);
  function todayISO(){ const d=new Date(); d.setMinutes(d.getMinutes()-d.getTimezoneOffset()); return d.toISOString().slice(0,10); }
  function uid(){ return 's_' + Math.random().toString(36).slice(2) + Date.now().toString(36); }
  function normalizeSale(s, i){ return { id:s.id||uid(), title:s.title||'Yard sale', address:s.address||'', date:s.date||'', time:s.time||'', notes:s.notes||'', include:s.include!==false, visited:!!s.visited, order:Number.isFinite(Number(s.order))?Number(s.order):i, lat:s.lat||null, lon:s.lon||null, geocodedAddress:s.geocodedAddress||'', geocodeVersion:Number(s.geocodeVersion)||0 }; }
  function load(){
    try{ sales = JSON.parse(localStorage.getItem(STORAGE_KEY) || 'null'); }catch(e){ sales=null; }
    if(!Array.isArray(sales)){
      for(const key of LEGACY_KEYS){ try{ const old=JSON.parse(localStorage.getItem(key)||'null'); if(Array.isArray(old)){ sales=old; break; } }catch(e){} }
    }
    if(!Array.isArray(sales)) sales=[];
    sales=sales.map(normalizeSale);
    saveOnly();
  }
  function saveOnly(){ localStorage.setItem(STORAGE_KEY, JSON.stringify(sales)); }
  function save(){ saveOnly(); renderAll(); }
  function sortSales(list=sales){ return [...list].sort((a,b)=>((a.date||'9999-99-99')+' '+(a.time||'99:99')+' '+String(a.order)).localeCompare((b.date||'9999-99-99')+' '+(b.time||'99:99')+' '+String(b.order))); }
  function routeSales(){ return [...sales].filter(s=>s.include!==false && !s.visited && s.address.trim()).sort((a,b)=>Number(a.order)-Number(b.order)); }
  function inThisWeek(dateStr){ if(!dateStr) return false; const d=new Date(dateStr+'T12:00:00'); const now=new Date(); const day=now.getDay(); const start=new Date(now); start.setDate(now.getDate()-day); start.setHours(0,0,0,0); const end=new Date(start); end.setDate(start.getDate()+7); return d>=start && d<end; }
  function filtered(){ let list=sortSales(); if(filter==='today') list=list.filter(s=>s.date===todayISO()); if(filter==='week') list=list.filter(s=>inThisWeek(s.date)); return list; }
  function escapeHtml(str){ return String(str||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
  function dateLabel(s){ let parts=[]; if(s.date) parts.push(s.date); if(s.time) parts.push(s.time); return parts.join(' at ') || 'No time set'; }



  function cleanPostText(text){
    return String(text||'').replace(/\r/g,'\n').replace(/[ \t]+/g,' ').replace(/\n{3,}/g,'\n\n').trim();
  }
  function isoFromParts(year, month, day){
    const d = new Date(year, month-1, day, 12, 0, 0);
    if(isNaN(d.getTime())) return '';
    const now = new Date();
    // If no year was obvious and the date is far in the past, use next year.
    if(d < new Date(now.getFullYear(), now.getMonth(), now.getDate()-7) && year === now.getFullYear()) d.setFullYear(year+1);
    d.setMinutes(d.getMinutes()-d.getTimezoneOffset());
    return d.toISOString().slice(0,10);
  }
  function nextWeekdayISO(dayIndex){
    const d = new Date();
    let diff = (dayIndex - d.getDay() + 7) % 7;
    if(diff === 0) diff = 0;
    d.setDate(d.getDate()+diff);
    d.setHours(12,0,0,0);
    d.setMinutes(d.getMinutes()-d.getTimezoneOffset());
    return d.toISOString().slice(0,10);
  }
  function parsePostDate(text){
    const t = ' ' + text.toLowerCase() + ' ';
    if(/\btoday\b/.test(t)) return {iso:todayISO(), label:'today'};
    if(/\btomorrow\b/.test(t)){
      const d=new Date(); d.setDate(d.getDate()+1); d.setHours(12,0,0,0); d.setMinutes(d.getMinutes()-d.getTimezoneOffset());
      return {iso:d.toISOString().slice(0,10), label:'tomorrow'};
    }
    const monthNames = {jan:1,january:1,feb:2,february:2,mar:3,march:3,apr:4,april:4,may:5,jun:6,june:6,jul:7,july:7,aug:8,august:8,sep:9,sept:9,september:9,oct:10,october:10,nov:11,november:11,dec:12,december:12};
    let m = text.match(/\b(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t|tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\.?\s+(\d{1,2})(?:st|nd|rd|th)?(?:,?\s*(20\d{2}|\d{2}))?\b/i);
    if(m){
      let y = m[3] ? Number(m[3]) : new Date().getFullYear(); if(y<100) y+=2000;
      return {iso:isoFromParts(y, monthNames[m[1].toLowerCase().replace('.','')], Number(m[2])), label:m[0]};
    }
    m = text.match(/\b(\d{1,2})[\/\-.](\d{1,2})(?:[\/\-.](20\d{2}|\d{2}))?\b/);
    if(m){
      let y = m[3] ? Number(m[3]) : new Date().getFullYear(); if(y<100) y+=2000;
      return {iso:isoFromParts(y, Number(m[1]), Number(m[2])), label:m[0]};
    }
    const days = [['sunday',0],['sun',0],['monday',1],['mon',1],['tuesday',2],['tues',2],['tue',2],['wednesday',3],['wed',3],['thursday',4],['thurs',4],['thu',4],['friday',5],['fri',5],['saturday',6],['sat',6]];
    for(const [name, idx] of days){ if(new RegExp('\\b'+name+'\\b','i').test(text)) return {iso:nextWeekdayISO(idx), label:name}; }
    return {iso:'', label:''};
  }
  function timeTo24(hour, minute, ampm, endAmpm){
    hour = Number(hour); minute = minute ? Number(minute) : 0;
    let ap = (ampm||'').toLowerCase().replace(/\./g,'');
    const end = (endAmpm||'').toLowerCase().replace(/\./g,'');
    if(!ap && end === 'pm' && hour >= 7 && hour <= 11) ap = 'am';
    if(!ap && end === 'am' && hour <= 11) ap = 'am';
    if(ap === 'pm' && hour < 12) hour += 12;
    if(ap === 'am' && hour === 12) hour = 0;
    if(!ap && hour >= 1 && hour <= 6) hour += 12; // most sale posts with 1-6 mean afternoon unless AM is written
    if(hour < 0 || hour > 23) return '';
    return String(hour).padStart(2,'0') + ':' + String(minute).padStart(2,'0');
  }
  function parsePostTime(text){
    const re = /\b(\d{1,2})(?::(\d{2}))?\s*(a\.?m\.?|p\.?m\.?)?\s*(?:-|–|—|to|until|til|through)\s*(\d{1,2})(?::(\d{2}))?\s*(a\.?m\.?|p\.?m\.?)\b/i;
    let m = text.match(re);
    if(m) return {time:timeTo24(m[1],m[2],m[3],m[6]), label:m[0]};
    m = text.match(/\b(?:starts?\s*(?:at)?|from|time:?|open:?|sale:?|hours:?)\s*(\d{1,2})(?::(\d{2}))?\s*(a\.?m\.?|p\.?m\.?)\b/i) || text.match(/\b(\d{1,2})(?::(\d{2}))?\s*(a\.?m\.?|p\.?m\.?)\b/i);
    if(m) return {time:timeTo24(m[1],m[2],m[3],''), label:m[0]};
    return {time:'', label:''};
  }
  const LOCAL_CITY_RE = /\b(Gladwin|Beaverton|Clare|Harrison|Midland|Mount Pleasant|Mt\.? Pleasant|West Branch|Coleman|Farwell|Sanford|Auburn|Pinconning|Roscommon|Prudenville|Houghton Lake|Standish|Bay City|Rose City|St\. Charles)\b/i;
  const STATE_RE = /\b(MI|Michigan)\b/i;
  const STREET_RE = /\b(street|st\.?|road|rd\.?|avenue|ave\.?|drive|dr\.?|lane|ln\.?|court|ct\.?|circle|cir\.?|boulevard|blvd\.?|trail|trl\.?|place|pl\.?|way|highway|hwy\.?|terrace|ter\.?|parkway|pkwy\.?|loop|path|alley)\b/i;
  const ROUTE_RE = /\b(?:m|us|i)[-\s]?\d{1,3}\b/i;
  const ITEM_RE = /\b(tools?|clothes|clothing|furniture|dresser|couch|sofa|table|chairs?|toys?|kids?|baby|toddler|women'?s?|men'?s?|shoes?|household|decor|reef|tank|fish|misc|books?|kitchen|antiques?|crafts?|collectibles?|garage items?|priced|each|obo|firm|free|lot of|lots of|everything must go|washer|dryer|mower|bike|bikes|games?|movies?|jewelry|purses?|bags?)\b/i;
  function homePlace(){ return (($('homeInput') && $('homeInput').value) || localStorage.getItem('salescout_home') || 'Gladwin, MI').trim() || 'Gladwin, MI'; }
  function stripAddressLabel(line){ return String(line||'').replace(/^(?:address|addy|location|where|located\s+at|located|place|pickup|pick up)\s*[:\-–—]?\s*/i,'').trim(); }
  function hasHouseNumber(s){ return /(^|\D)\d{1,6}\b/.test(s); }
  function hasStreetAddress(s){ return hasHouseNumber(s) && (STREET_RE.test(s) || ROUTE_RE.test(s)); }
  function isItemishLine(line){
    const s = String(line||'');
    if(!s) return false;
    const hasAddressWords = STREET_RE.test(s) || ROUTE_RE.test(s) || LOCAL_CITY_RE.test(s) || STATE_RE.test(s);
    if((/[$•;]/.test(s) || s.split(',').length >= 3) && ITEM_RE.test(s) && !hasStreetAddress(s)) return true;
    if(ITEM_RE.test(s) && !hasAddressWords) return true;
    if(/\b\d+\s*(?:piece|pc|inch|in\.?|gal|gallon|size|month|months|year|years|yr|yrs|t|xl|lbs?)\b/i.test(s) && !hasStreetAddress(s)) return true;
    return false;
  }
  function extractStrictStreetAddress(raw){
    let s = String(raw||'').replace(/^[📍🗺️🏠➡️\s]+/u,'').trim();
    s = stripAddressLabel(s);
    // Facebook posts often run the time right into the address: "2645 lakeshore dr.1 -6 pm".
    // Add a space after a street suffix period before numbers so the address extractor can stop cleanly.
    s = s.replace(/\b(st|rd|dr|ave|ln|ct|cir|blvd|trl|pl|hwy)\.(?=\d)/ig, '$1. ');
    const streetSuffix = '(?:street|st\\.?|road|rd\\.?|avenue|ave\\.?|drive|dr\\.?|lane|ln\\.?|court|ct\\.?|circle|cir\\.?|boulevard|blvd\\.?|trail|trl\\.?|place|pl\\.?|way|highway|hwy\\.?|terrace|ter\\.?|parkway|pkwy\\.?|loop|path|alley)';
    const cityNames = '(?:Gladwin|Beaverton|Clare|Harrison|Midland|Mount Pleasant|Mt\\.? Pleasant|West Branch|Coleman|Farwell|Sanford|Auburn|Pinconning|Roscommon|Prudenville|Houghton Lake|Standish|Bay City|Rose City|St\\.? Charles)';
    const re = new RegExp("(?:^|\\b)(\\d{1,6}\\s+(?:[A-Za-z0-9.#'’&-]+\\s+){0,7}"+streetSuffix+"\\b\\.?)(?:\\s*(?:,|-)\\s*|\\s+)?("+cityNames+")?(?:\\s*,?\\s*(MI|Michigan))?", 'i');
    const m = s.match(re);
    if(!m) return '';
    let out = (m[1]||'').trim().replace(/[\s,.;:]+$/,'');
    if(m[2]) out += ', ' + m[2].replace(/Mt\.?/i,'Mount').trim();
    if(m[3]) out += ', MI';
    return out.replace(/\s{2,}/g,' ');
  }
  function cleanAddressCandidate(raw){
    let s = String(raw||'').replace(/^[📍🗺️🏠➡️\s]+/u,'').trim();
    s = stripAddressLabel(s);
    s = s.replace(/\b(st|rd|dr|ave|ln|ct|cir|blvd|trl|pl|hwy)\.(?=\d)/ig, '$1. ');
    const strict = extractStrictStreetAddress(s);
    // If a line contains extra sale text before/after the real address, keep only the address.
    if(strict) return strict;
    s = s.replace(/\s+(?:no early birds|no early sales|please message|message me|pm me|cash only|venmo|paypal)\b.*$/i,'');
    s = s.replace(/\s+(?:sale starts?|starts?|hours?|open)\s*[:\-]?\s*\d{1,2}.*$/i,'');
    s = s.replace(/\b\d{1,2}\s*(?:-|to|–|—)\s*\d{1,2}\s*(?:am|pm)\b.*$/i,'');
    s = s.replace(/[\s.]+$/,'').replace(/\s{2,}/g,' ');
    return s;
  }
  function scoreAddressCandidate(line, labelled=false){
    const s = cleanAddressCandidate(line);
    if(!s || s.length < 3 || s.length > 120) return -100;
    let score = labelled ? 35 : 0;
    if(hasStreetAddress(s)) score += 75;
    else if(hasHouseNumber(s) && labelled) score += 35;
    if(LOCAL_CITY_RE.test(s)) score += 15;
    if(STATE_RE.test(s)) score += 20;
    if(/^\d{1,6}\b/.test(s)) score += 8;
    if(!hasStreetAddress(s) && LOCAL_CITY_RE.test(s) && (STATE_RE.test(s)||labelled)) score += 20;
    if(isItemishLine(s) && !(labelled && hasStreetAddress(s))) score -= 75;
    if(/^[$•-]/.test(s)) score -= 40;
    if(/\b(?:for sale|iso|looking for|wanted)\b/i.test(s) && !labelled) score -= 30;
    return score;
  }
  function finishAddress(addr){
    let a = cleanAddressCandidate(addr);
    if(!a) return '';
    // If the post only says a street address, assume the search-center city so Google does not choose another town/state.
    if(hasStreetAddress(a) && !LOCAL_CITY_RE.test(a) && !STATE_RE.test(a)) a += ', ' + homePlace();
    else if(hasStreetAddress(a) && LOCAL_CITY_RE.test(a) && !STATE_RE.test(a)) a += ', MI';
    else if(!hasStreetAddress(a) && LOCAL_CITY_RE.test(a) && !STATE_RE.test(a)) a += ', MI';
    return a;
  }
  function looksLikeAddress(line){ return scoreAddressCandidate(line, false) >= 70; }
  function realisticStreetAddress(addr){
    const a = normalizeStreetSuffix(String(addr||'').trim());
    if(!a || isOcrGarbageLine(a)) return false;
    const strict = extractStrictStreetAddress(a);
    const test = strict || a;
    const m = test.match(/^\s*(\d{1,6})\s+(.+?)\s+(street|st\.?|road|rd\.?|avenue|ave\.?|drive|dr\.?|lane|ln\.?|court|ct\.?|circle|cir\.?|boulevard|blvd\.?|trail|trl\.?|place|pl\.?|way|highway|hwy\.?|terrace|ter\.?|parkway|pkwy\.?|loop|path|alley)\b/i);
    if(!m) return ROUTE_RE.test(test) && /\b(?:Gladwin|Beaverton|Clare|Harrison|Midland|Mount Pleasant|West Branch|MI|Michigan)\b/i.test(test);
    const num = Number(m[1]);
    if(num < 10) return false;
    const streetName = m[2].trim();
    const streetNameNoDir = streetName.replace(/^(?:N|S|E|W|NE|NW|SE|SW)\s+/i,'');
    const tokens = streetNameNoDir.split(/\s+/).filter(Boolean);
    if(tokens.length > 7) return false;
    if(tokens.filter(t=>/^[A-Za-z]$/.test(t)).length > 1) return false;
    if(/(?:REE\s+ER|NQF|QQ|^[A-Z]\s+[A-Z])/i.test(streetNameNoDir)) return false;
    return true;
  }
  function parsePostTitle(text){
    const lines = cleanPostText(text).split('\n').map(l=>l.trim()).filter(Boolean).filter(l=>!isFacebookUiLine(l) && !isOcrGarbageLine(l) && !isProbablyMetaNameLine(l));
    for(const l of lines){
      const m = l.match(/\b((?:large\s+|huge\s+|multi[ -]?family\s+|neighborhood\s+|church\s+|barn\s+)?(?:garage|yard|moving|estate|rummage|tag)\s+sales?)\b/i);
      if(m) return m[1].replace(/\s+/g,' ').replace(/\b\w/g,c=>c.toUpperCase()).replace(/Sales$/,'Sale');
    }
    return 'Yard sale';
  }
  function parsePostAddress(text){
    const lines = cleanPostText(text).split('\n').map(l=>l.trim()).filter(Boolean);
    const candidates = [];
    function add(raw, labelled=false, why=''){
      const cleaned = cleanAddressCandidate(raw);
      if(!cleaned) return;
      const score = scoreAddressCandidate(cleaned, labelled);
      if(score > 0) candidates.push({raw:cleaned, score, labelled, why});
    }
    for(let i=0;i<lines.length;i++){
      const line = lines[i];
      if(/^(?:address|addy|location|where|located\s+at|located|place|pickup|pick up)\s*[:\-–—]?\s*$/i.test(line) && lines[i+1]) add(lines[i+1], true, 'label-next-line');
      if(/^(?:address|addy|location|where|located\s+at|located|place|pickup|pick up)\s*[:\-–—]\s+/i.test(line)) add(line, true, 'label');
      const inline = line.match(/\b(?:address|addy|location|where|located\s+at|located|pickup|pick up)\s*[:\-–—]?\s+(.{3,110})$/i);
      if(inline) add(inline[1], true, 'inline-label');
      const atStreet = line.match(/\b(?:at|@)\s+(\d{1,6}\s+[^\n]{2,95})/i);
      if(atStreet) add(atStreet[1], false, 'at-street');
      if(hasStreetAddress(line) && !isItemishLine(line)) add(line, false, 'street-line');
    }
    candidates.sort((a,b)=>b.score-a.score);
    const best = candidates[0];
    if(best && best.score >= 70) return {address:finishAddress(best.raw), confidence:best.score>=95?'high':'medium', warning:best.score>=95?'':'Possible address found — double-check it before saving.'};
    const city = cleanPostText(text).match(LOCAL_CITY_RE);
    if(city) return {address:'', city:city[0].replace(/Mt\.?/i,'Mount') + ', MI', confidence:'city-only', warning:'I only found the city. I left the address blank so it does not route to the wrong place.'};
    return {address:'', city:'', confidence:'none', warning:'I did not find a safe address, so I left the address blank instead of guessing.'};
  }
  function parsePostTitle(text){
    const lines = cleanPostText(text).split('\n').map(l=>l.trim()).filter(Boolean);
    const saleLine = lines.find(l=>/\b(garage|yard|moving|estate|rummage|barn|tag|multi[ -]?family|sale)\b/i.test(l) && l.length <= 90 && !looksLikeAddress(l));
    if(saleLine) return saleLine.replace(/^(title|event)\s*[:\-]\s*/i,'').trim();
    const first = lines.find(l=>l.length >= 4 && l.length <= 70 && !looksLikeAddress(l) && !/^\d/.test(l) && !/^(date|time|when|where|address|addy|location)\s*[:\-]/i.test(l) && !isItemishLine(l));
    return first || 'Facebook yard sale';
  }
  function parseSaleFromText(text){
    const post = cleanOcrText(cleanPostText(text));
    const date = parsePostDate(post);
    const time = parsePostTime(post);
    const addr = parsePostAddress(post);
    const title = parsePostTitle(post);
    const found = [];
    const warnings = [];
    if(title) found.push('title');
    if(addr.address) found.push('address');
    else warnings.push(addr.warning || 'No safe address found.');
    if(date.iso) found.push('date');
    if(time.time) found.push('start time');
    if(addr.warning && addr.address) warnings.push(addr.warning);
    const noteLines = [];
    if(addr.city && !addr.address) noteLines.push('City found but not used as route address: '+addr.city);
    if(date.label) noteLines.push('Post date text: '+date.label);
    if(time.label) noteLines.push('Post time text: '+time.label);
    noteLines.push('Original listing text:');
    noteLines.push(post);
    return {
      title: title || 'Yard sale',
      address: addr.address || '',
      date: date.iso || '',
      time: time.time || '',
      notes: noteLines.join('\n'),
      include: true,
      visited: false,
      _found: found,
      _warnings: warnings,
      _raw: post
    };
  }
  function fillFormFromParsed(parsed){
    const found = parsed._found || [];
    const warnings = parsed._warnings || [];
    if(parsed.title) $('saleTitle').value = parsed.title;
    if(parsed.address) $('saleAddress').value = parsed.address;
    else $('saleAddress').value = '';
    if(parsed.date) $('saleDate').value = parsed.date;
    if(parsed.time) $('saleTime').value = parsed.time;
    $('saleNotes').value = parsed.notes || '';
    let msg = found.length ? ('Filled: '+found.join(', ')+'.') : 'I could not confidently fill the fields.';
    if(warnings.length) msg += ' ' + warnings.join(' ');
    msg += ' Always check the address before saving.';
    $('parseStatus').textContent = msg;
    if(!parsed.address) $('saleAddress').focus();
  }
  function parseFacebookPost(text){
    const post = cleanOcrText(cleanPostText(text));
    if(!post){ alert('Paste the post text first.'); return; }
    const chunks = extractSaleChunks(post);
    if(chunks.length > 1){
      $('parseStatus').textContent = 'I found '+chunks.length+' possible listings. Tap Import all found to add them as separate sales, or Break down text again after deleting extra text.';
      const first = parseSaleFromText(chunks[0]);
      fillFormFromParsed(first);
      return;
    }
    fillFormFromParsed(parseSaleFromText(post));
  }

  function cleanOcrText(raw){
    let text = String(raw||'')
      .replace(/\r/g,'\n')
      .replace(/[“”]/g,'"')
      .replace(/[‘’]/g,"'")
      .replace(/\bM[Il1]\b/g,'MI')
      .replace(/\bGiadwin\b/gi,'Gladwin')
      .replace(/\bCiare\b/gi,'Clare')
      .replace(/\bBeaverton\b/gi,'Beaverton')
      .replace(/\bMiddie[ -]?town\b/gi,'Midland')
      .replace(/[ \t]+/g,' ')
      .replace(/\n[ \t]+/g,'\n')
      .replace(/[ \t]+\n/g,'\n');
    const junk = /^(?:like|comment|share|send|all reactions|view more comments|write a comment|see less|see more|reply|author|admin|sponsored|follow|join group|most relevant|top comments|facebook|notifications?|messenger|home|watch|marketplace)$/i;
    const lines = text.split('\n').map(l=>l.trim()).filter(l=>l && !junk.test(l));
    return lines.join('\n').replace(/\n{3,}/g,'\n\n').trim();
  }
  function likelyAddressLineIndex(line){
    const labelled = /^(?:address|addy|location|where|located\s+at|located|place|pickup|pick up)\s*[:\-–—]?/i.test(line);
    return scoreAddressCandidate(line, labelled) >= (labelled ? 45 : 70);
  }
  function likelySaleChunk(chunk){
    const c = cleanOcrText(chunk);
    if(c.length < 12) return false;
    if(parsePostAddress(c).address) return true;
    return /\b(garage|yard|moving|estate|rummage|barn|tag|multi[ -]?family|sale)\b/i.test(c) && (parsePostDate(c).iso || parsePostTime(c).time);
  }
  function extractSaleChunks(text){
    const t = cleanOcrText(text);
    if(!t) return [];
    const hard = t.split(/\n\s*(?:-{3,}|={3,}|_{3,}|\*{3,}|•{3,})\s*\n/g).map(cleanOcrText).filter(likelySaleChunk);
    if(hard.length > 1) return hard;
    const lines = t.split('\n').map(l=>l.trim()).filter(Boolean);
    let anchors = [];
    for(let i=0;i<lines.length;i++){
      if(likelyAddressLineIndex(lines[i])) anchors.push(i);
      else if(/^(?:address|addy|location|where|located|pickup|pick up)\s*[:\-–—]?\s*$/i.test(lines[i]) && lines[i+1]) anchors.push(i+1);
    }
    anchors = anchors.filter((idx,pos)=>pos===0 || idx-anchors[pos-1] > 2);
    if(anchors.length > 1){
      const chunks=[];
      for(let a=0;a<anchors.length;a++){
        let start = a===0 ? 0 : Math.floor((anchors[a-1]+anchors[a])/2)+1;
        let end = a===anchors.length-1 ? lines.length-1 : Math.floor((anchors[a]+anchors[a+1])/2);
        // Pull a nearby title/date line above the address when possible.
        while(start > 0 && anchors[a]-start < 5 && !likelyAddressLineIndex(lines[start-1]) && !/^\s*$/.test(lines[start-1])) start--;
        const chunk = cleanOcrText(lines.slice(start,end+1).join('\n'));
        if(likelySaleChunk(chunk)) chunks.push(chunk);
      }
      if(chunks.length > 1) return chunks;
    }
    const saleStarts=[];
    for(let i=0;i<lines.length;i++){
      if(/\b(garage|yard|moving|estate|rummage|barn|tag|multi[ -]?family|sale)\b/i.test(lines[i]) && !looksLikeAddress(lines[i]) && !isItemishLine(lines[i])) saleStarts.push(i);
    }
    if(saleStarts.length > 1){
      const chunks=[];
      for(let i=0;i<saleStarts.length;i++){
        const start=saleStarts[i];
        const end=i+1<saleStarts.length ? saleStarts[i+1]-1 : lines.length-1;
        const chunk=cleanOcrText(lines.slice(start,end+1).join('\n'));
        if(likelySaleChunk(chunk)) chunks.push(chunk);
      }
      if(chunks.length > 1) return chunks;
    }
    return [t];
  }
  function addressKey(addr){
    return String(addr||'')
      .toLowerCase()
      .replace(/(street)/g,'st')
      .replace(/(avenue)/g,'ave')
      .replace(/(road)/g,'rd')
      .replace(/(drive)/g,'dr')
      .replace(/(lane)/g,'ln')
      .replace(/(michigan)/g,'mi')
      .replace(/[^a-z0-9]+/g,' ')
      .trim();
  }
  function dedupeParsedSales(parsed){
    const seen = new Set();
    const existing = new Set(sales.map(s=>addressKey(s.address)).filter(Boolean));
    const out = [];
    parsed.forEach(p=>{
      if(!p || !p.address) return;
      const key = addressKey(p.address);
      if(!key) return;
      if(seen.has(key) || existing.has(key)) return;
      seen.add(key);
      out.push(p);
    });
    return out;
  }
  function importSalesFromText(text, fromPhoto=false){
    const cleaned = cleanOcrText(text);
    if(!cleaned){ alert(fromPhoto ? 'No text was read from that photo.' : 'Paste or read some listing text first.'); return false; }
    const chunks = extractSaleChunks(cleaned);
    const parsed = chunks.map(parseSaleFromText);
    const withAddress = dedupeParsedSales(parsed);
    if(withAddress.length <= 1){
      fillFormFromParsed(withAddress[0] || parsed[0] || parseSaleFromText(cleaned));
      $('parseStatus').textContent += ' I only found one new safe sale/address, so I filled the form instead of importing a batch.';
      return false;
    }
    const skipped = Math.max(0, parsed.length - withAddress.length);
    const msg = 'I found '+withAddress.length+' new sales with safe addresses.' + (skipped>0 ? ' Some duplicates or possible listings without safe addresses will be skipped.' : '') + ' Add these to your list?';
    if(!confirm(msg)){
      $('parseStatus').textContent = 'Found '+withAddress.length+' importable sales. Tap Import all found when ready, or edit the text first.';
      return false;
    }
    const startOrder = nextOrder();
    withAddress.forEach((p,i)=>{
      sales.push(normalizeSale({
        id: uid(),
        title: p.title || 'Yard sale',
        address: p.address,
        date: p.date || '',
        time: p.time || '',
        notes: p.notes || '',
        include: true,
        visited: false,
        order: startOrder + i,
        geocodeVersion: 0
      }, startOrder+i));
    });
    save();
    closeModal();
    alert('Added '+withAddress.length+' sales.' + (skipped>0 ? ' Skipped duplicates/unsafe listings.' : ''));
    return true;
  }

  function loadImageFromFile(file){
    return new Promise((resolve,reject)=>{
      const img = new Image();
      img.onload = () => { URL.revokeObjectURL(img.src); resolve(img); };
      img.onerror = reject;
      img.src = URL.createObjectURL(file);
    });
  }
  function canvasToBlob(canvas){
    return new Promise(resolve=>{
      canvas.toBlob(blob=>resolve(blob || canvas.toDataURL('image/png')), 'image/png');
    });
  }
  async function makeOcrBlob(img, crop){
    const srcW = crop ? crop.w : img.naturalWidth;
    const srcH = crop ? crop.h : img.naturalHeight;
    const maxDim = Math.max(srcW, srcH);
    let scale = maxDim < 1200 ? 2 : (maxDim < 1900 ? 1.5 : 1.15);
    if(maxDim * scale > 2800) scale = 2800 / maxDim;
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(srcW * scale));
    canvas.height = Math.max(1, Math.round(srcH * scale));
    const ctx = canvas.getContext('2d', {willReadFrequently:true});
    ctx.fillStyle = '#fff';
    ctx.fillRect(0,0,canvas.width,canvas.height);
    ctx.imageSmoothingEnabled = true;
    ctx.drawImage(img, crop ? crop.x : 0, crop ? crop.y : 0, srcW, srcH, 0, 0, canvas.width, canvas.height);
    const data = ctx.getImageData(0,0,canvas.width,canvas.height);
    let total=0;
    for(let i=0;i<data.data.length;i+=4){ total += 0.299*data.data[i] + 0.587*data.data[i+1] + 0.114*data.data[i+2]; }
    const avg = total / (data.data.length/4);
    const invert = avg < 120;
    for(let i=0;i<data.data.length;i+=4){
      let lum = 0.299*data.data[i] + 0.587*data.data[i+1] + 0.114*data.data[i+2];
      if(invert) lum = 255 - lum;
      let v = (lum - 128) * 1.75 + 128;
      if(v > 218) v = 255;
      else if(v < 72) v = 0;
      else v = Math.max(0, Math.min(255, Math.round(v)));
      data.data[i]=data.data[i+1]=data.data[i+2]=v;
      data.data[i+3]=255;
    }
    ctx.putImageData(data,0,0);
    return canvasToBlob(canvas);
  }
  async function buildOcrInputs(file){
    const img = await loadImageFromFile(file);
    const w = img.naturalWidth, h = img.naturalHeight;
    const inputs = [];
    const pushCrop = async (label, crop) => {
      inputs.push({label, image: await makeOcrBlob(img, crop)});
    };
    if(w > h * 1.12){
      // Newspaper / flyer style: listings are often in columns.
      const mid = Math.floor(w/2);
      await pushCrop('left column', {x:0,y:0,w:mid,h});
      await pushCrop('right column', {x:mid,y:0,w:w-mid,h});
      if(w > h * 1.75){
        const q1 = Math.floor(w/4), q2 = Math.floor(w/2), q3 = Math.floor(3*w/4);
        await pushCrop('column 1', {x:0,y:0,w:q1,h});
        await pushCrop('column 2', {x:q1,y:0,w:q2-q1,h});
        await pushCrop('column 3', {x:q2,y:0,w:q3-q2,h});
        await pushCrop('column 4', {x:q3,y:0,w:w-q3,h});
      }
      return inputs;
    }
    if(h > w * 1.18){
      // Facebook screenshot style: one sale post above another.
      // Use overlapping top/middle/bottom crops so a post near a cut line still gets read.
      const third = Math.floor(h/3);
      const overlap = Math.floor(h * 0.08);
      await pushCrop('top post area', {x:0,y:0,w,h:Math.min(h, third + overlap)});
      await pushCrop('middle post area', {x:0,y:Math.max(0, third - overlap),w,h:Math.min(h - Math.max(0, third - overlap), third + overlap*2)});
      await pushCrop('bottom post area', {x:0,y:Math.max(0, 2*third - overlap),w,h:h - Math.max(0, 2*third - overlap)});
      return inputs;
    }
    return [{label:'photo', image:await makeOcrBlob(img,null)}];
  }
  async function parsePhotoPost(file){
    if(!file) return;
    $('parseStatus').textContent = 'Preparing photo for text reading...';
    if(!window.Tesseract){
      $('parseStatus').textContent = 'Photo reading could not load. Check internet, or paste the text manually.';
      return;
    }
    try{
      const inputs = await buildOcrInputs(file);
      const pieces = [];
      for(let i=0;i<inputs.length;i++){
        const part = inputs[i];
        $('parseStatus').textContent = 'Reading '+part.label+'... this can take a minute.';
        const result = await Tesseract.recognize(part.image, 'eng', {
          logger: m => {
            if(!m || !m.status) return;
            const pct = typeof m.progress === 'number' ? ' ' + Math.round(m.progress * 100) + '%' : '';
            $('parseStatus').textContent = 'Reading '+part.label+': ' + m.status + pct;
          },
          tessedit_pageseg_mode: '6',
          preserve_interword_spaces: '1'
        });
        const text = cleanOcrText(result && result.data && result.data.text ? result.data.text : '');
        if(text) pieces.push(text);
      }
      const text = cleanOcrText(pieces.join('\n\n---\n\n'));
      if(!text){
        $('parseStatus').textContent = 'I could not read text from that photo. Try cropping closer, taking a brighter screenshot, or paste the post text.';
        return;
      }
      $('postPaste').value = text;
      const chunks = extractSaleChunks(text);
      const importable = dedupeParsedSales(chunks.map(parseSaleFromText)).length;
      if(importable > 1){
        $('parseStatus').textContent = 'Photo text found '+importable+' new sales with safe addresses. Use Import all found to add them, or edit the text first.';
        importSalesFromText(text, true);
        return;
      }
      parseFacebookPost(text);
      $('parseStatus').textContent += ' Text was pulled from the photo; double-check every field. Crop closer if the address looks wrong.';
    }catch(e){
      $('parseStatus').textContent = 'Could not read that photo. Try a clearer/cropped image, screenshot, or paste the post text.';
    }finally{
      $('postImageInput').value = '';
    }
  }



  function setMapInteraction(on){
    mapUnlocked = !!on;
    const wrap = $('mapWrap');
    const btn = $('mapLockBtn');
    if(wrap) wrap.classList.toggle('unlocked', mapUnlocked);
    if(btn){
      btn.textContent = mapUnlocked ? 'Lock map' : 'Move map';
      btn.classList.toggle('unlocked', mapUnlocked);
    }
    if(!map) return;
    const action = mapUnlocked ? 'enable' : 'disable';
    try{ map.dragging[action](); }catch(e){}
    try{ map.touchZoom[action](); }catch(e){}
    try{ map.doubleClickZoom[action](); }catch(e){}
    try{ map.boxZoom[action](); }catch(e){}
    try{ map.keyboard[action](); }catch(e){}
  }
  function toggleMapInteraction(){ setMapInteraction(!mapUnlocked); }

  function initMap(){
    try{
      if(!window.L) throw new Error('Leaflet missing');
      map = L.map('map',{ zoomControl:true, dragging:true, touchZoom:true, doubleClickZoom:true, scrollWheelZoom:false, boxZoom:true, keyboard:true }).setView([44.0295,-84.4864],9);
      L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{maxZoom:19, attribution:'&copy; OpenStreetMap'}).addTo(map);
      markersLayer = L.layerGroup().addTo(map);
      setMapInteraction(true);
      setTimeout(()=>map.invalidateSize(),250);
      scheduleMapRender();
    }catch(e){ $('map').innerHTML='<div class="empty">Map could not load, but the list and Google Maps routing still work.</div>'; }
  }
  function degreesToRad(x){ return x * Math.PI / 180; }
  function milesFromGladwin(lat, lon){
    const lat1=44.0295, lon1=-84.4864;
    const R=3958.8, dLat=degreesToRad(lat-lat1), dLon=degreesToRad(lon-lon1);
    const a=Math.sin(dLat/2)**2 + Math.cos(degreesToRad(lat1))*Math.cos(degreesToRad(lat))*Math.sin(dLon/2)**2;
    return 2*R*Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
  }
  function addressForSearch(addr){ return finishAddress(addr); }
  async function geocodeSale(s){
    if(!s.address.trim()) return s;
    const searchAddress = addressForSearch(s.address);
    if(s.lat && s.lon && s.geocodedAddress===searchAddress && s.geocodeVersion===7) return s;
    try{
      const base='https://nominatim.openstreetmap.org/search?format=json&limit=5&countrycodes=us&viewbox=-86.2,45.4,-82.8,43.0&q=';
      const res=await fetch(base + encodeURIComponent(searchAddress));
      const data=await res.json();
      let choices=(data||[]).filter(x=>/Michigan|, MI,| MI /i.test(x.display_name||''));
      if(!choices.length) choices=data||[];
      choices=choices.map(x=>({...x, _miles:milesFromGladwin(parseFloat(x.lat), parseFloat(x.lon))})).sort((a,b)=>a._miles-b._miles);
      const best=choices[0];
      if(best){ s.lat=parseFloat(best.lat); s.lon=parseFloat(best.lon); s.geocodedAddress=searchAddress; s.geocodeVersion=7; saveOnly(); }
    }catch(e){}
    return s;
  }
  async function geocodeHome(){
    const q=$('homeInput').value.trim() || 'Gladwin, MI';
    $('centerStatus').textContent='Finding '+q+'...';
    try{
      const res=await fetch('https://nominatim.openstreetmap.org/search?format=json&limit=1&q='+encodeURIComponent(q));
      const data=await res.json();
      if(data && data[0] && map){ map.setView([parseFloat(data[0].lat),parseFloat(data[0].lon)],10); $('centerStatus').textContent='Centered on '+q; localStorage.setItem('salescout_home',q); }
      else $('centerStatus').textContent='Could not find that place.';
    }catch(e){ $('centerStatus').textContent='Could not use map search right now.'; }
  }
  function scheduleMapRender(){ clearTimeout(mapRenderTimer); mapRenderTimer=setTimeout(renderMap,120); }
  async function renderMap(){
    if(!map || !markersLayer) return;
    markersLayer.clearLayers();
    const bounds=[];
    for(const s of sales){
      await geocodeSale(s);
      if(s.lat && s.lon){ const marker=L.marker([s.lat,s.lon]).bindPopup('<b>'+escapeHtml(s.title||'Sale')+'</b><br>'+escapeHtml(s.address)+'<br>'+escapeHtml(dateLabel(s))); markersLayer.addLayer(marker); bounds.push([s.lat,s.lon]); }
    }
    if(bounds.length) map.fitBounds(bounds,{padding:[32,32],maxZoom:13});
    else { const home=localStorage.getItem('salescout_home')||$('homeInput').value||'Gladwin, MI'; if(home.toLowerCase().includes('gladwin')) map.setView([44.0295,-84.4864],9); }
    setTimeout(()=>map.invalidateSize(),50);
  }

  function renderList(){
    const list=filtered();
    const statText=sales.length+' saved sale'+(sales.length===1?'':'s')+' • '+routeSales().length+' in route';
    if($('stats')) $('stats').textContent=statText;
    if($('dashStats')) $('dashStats').textContent=statText;
    const box=$('salesList');
    if(!list.length){ box.innerHTML='<div class="card empty">No sales yet. Tap Add on the map screen.</div>'; return; }
    box.innerHTML=list.map(s=>`<div class="sale ${s.visited?'visited':''}"><div class="saleHead"><div><div class="saleTitle">${escapeHtml(s.title||'Untitled sale')} ${s.include===false?'<span class="badge">Not routed</span>':''}</div><div class="addr">${escapeHtml(s.address||'No address')}</div><div class="meta">${escapeHtml(dateLabel(s))}</div></div></div>${s.notes?`<div class="notes">${escapeHtml(s.notes)}</div>`:''}<div class="actions"><button class="small secondary" onclick="editSale('${s.id}')">Edit</button><button class="small secondary" onclick="openOneMap('${s.id}')">Map</button><button class="small secondary" onclick="toggleVisited('${s.id}')">${s.visited?'Unvisit':'Visited'}</button><button class="small secondary" onclick="toggleInclude('${s.id}')">${s.include===false?'Add to route':'Remove from route'}</button><button class="small danger" onclick="removeSale('${s.id}')">Delete</button></div></div>`).join('');
  }
  function renderRoute(){
    const rs=routeSales(); const box=$('routeStops'); const warn=$('routeWarn'); warn.style.display='none'; warn.textContent='';
    if(!rs.length){ box.innerHTML='<div class="empty">No route stops yet. Add sales and leave them included.</div>'; return; }
    if(rs.length>10){ warn.style.display='block'; warn.textContent='Google Maps can be picky with large routes, so the Open route button will send the first 10 stops. Split the rest into another route.'; }
    box.innerHTML=rs.map((s,i)=>`<div class="routeStop"><div><b>${i+1}. ${escapeHtml(s.title||'Sale')}</b><small>${escapeHtml(s.address||'')}</small></div><div><button class="small secondary" onclick="moveRoute('${s.id}',-1)">↑</button><button class="small secondary" onclick="moveRoute('${s.id}',1)">↓</button></div></div>`).join('');
  }
  function renderAll(){ renderList(); renderRoute(); scheduleMapRender(); }

  function openModal(s=null){
    document.body.classList.add('modal-open');
    $('saleModal').classList.add('show'); $('saleModal').setAttribute('aria-hidden','false');
    $('modalTitle').textContent=s?'Edit sale':'Add sale'; $('saleId').value=s?.id||''; $('saleTitle').value=s?.title||''; $('saleAddress').value=s?.address||''; $('saleDate').value=s?.date||todayISO(); $('saleTime').value=s?.time||''; $('saleNotes').value=s?.notes||''; $('saleInclude').checked=s?.include!==false; $('deleteSaleBtn').style.display=s?'inline-block':'none'; $('postPaste').value=''; $('parseStatus').textContent='Paste post text or upload a screenshot/photo. The app will use only sale-looking text and ignore Facebook buttons/photo clutter.'; resetSalePreview();
    setTimeout(()=>$(s?'saleTitle':'postPaste').focus(),150);
  }
  function closeModal(){ document.body.classList.remove('modal-open'); $('saleModal').classList.remove('show'); $('saleModal').setAttribute('aria-hidden','true'); }
  function editSale(id){ const s=sales.find(x=>x.id===id); if(s) openModal(s); }
  function nextOrder(){ return sales.reduce((max,s)=>Math.max(max,Number(s.order)||0),0)+1; }
  function removeSale(id){ if(!id){ alert('No saved sale selected to delete.'); return; } if(confirm('Delete this sale?')){ sales=sales.filter(s=>s.id!==id); save(); closeModal(); } }
  function toggleVisited(id){ const s=sales.find(x=>x.id===id); if(s){s.visited=!s.visited; save();} }
  function toggleInclude(id){ const s=sales.find(x=>x.id===id); if(s){s.include=s.include===false; save();} }
  function moveRoute(id,dir){
    const ordered=routeSales(); const idx=ordered.findIndex(s=>s.id===id); const other=ordered[idx+dir]; if(!other) return;
    const a=sales.find(s=>s.id===id), b=sales.find(s=>s.id===other.id); const tmp=a.order; a.order=b.order; b.order=tmp; save();
  }
  function buildMapsUrl(singleAddress){
    let addrs=[];
    if(singleAddress) addrs=[addressForSearch(singleAddress)]; else addrs=routeSales().slice(0,10).map(s=>addressForSearch(s.address.trim())).filter(Boolean);
    if(!addrs.length) return '';
    // Do not send the app's search-center address as the route origin.
    // Leaving origin off lets Google Maps start directions from the user's current location.
    let url='https://www.google.com/maps/dir/?api=1&travelmode=driving';
    const dest=addrs[addrs.length-1]; const waypoints=addrs.slice(0,-1);
    url+='&destination='+encodeURIComponent(dest);
    if(waypoints.length) url+='&waypoints='+encodeURIComponent(waypoints.join('|'));
    return url;
  }
  function openMaps(url){ if(!url){ alert('Add at least one sale with an address first.'); return; } if(window.SaleScoutAndroid && window.SaleScoutAndroid.openMaps){ window.SaleScoutAndroid.openMaps(url); } else { window.open(url,'_blank'); } }
  function openOneMap(id){ const s=sales.find(x=>x.id===id); if(s) openMaps(buildMapsUrl(s.address)); }



  // v13: stricter photo/screenshot OCR. The old version OCRed the whole screenshot,
  // including pictures, buttons, profile names, and headers. This version detects light
  // text bands first, then filters OCR down to sale-looking text before parsing.
  function weirdCharRatio(s){
    s = String(s||'');
    if(!s) return 1;
    const allowed = s.match(/[A-Za-z0-9\s.,:;!?$#&'"()\-/–—@]/g) || [];
    return 1 - (allowed.length / s.length);
  }
  function mostlyLettersOrNumbers(s){
    s = String(s||'');
    const good = s.match(/[A-Za-z0-9]/g) || [];
    return good.length / Math.max(1, s.length);
  }
  function isFacebookUiLine(line){
    const l = String(line||'').trim();
    if(!l) return true;
    if(/^[-_=•*]+$/.test(l)) return true;
    if(/^(?:like|comment|share|send|home|watch|marketplace|notifications?|messenger|search|write a comment|view more comments|see more|see less|reply|all reactions|most relevant|top comments|admin|author|sponsored|follow|join group)$/i.test(l)) return true;
    if(/\b(?:like|comment|share)\b\s+\b(?:like|comment|share)\b/i.test(l)) return true;
    if(/^\s*[<←].{0,8}(gladwin|garage|yard|sale|group)/i.test(l)) return true;
    if(/gladwin\s+garage\s+and\s+yar/i.test(l)) return true;
    if(/garage\s+and\s+yard\s+sales?\s+group/i.test(l)) return true;
    if(/^(?:may|jun|june|jul|july|aug|august|sep|sept|oct|nov|dec|jan|feb|mar|apr)\s+\d{1,2}\s*[·•]?(?:\s*(?:public|friends|group))?$/i.test(l)) return true;
    return false;
  }
  function isOcrGarbageLine(line){
    const l = String(line||'').trim();
    if(!l) return true;
    if(l.length < 2) return true;
    if(/(?:QQ|NQF|¢|€|¬|©|®|¥|§|\|\/\/|\^|`|~)/.test(l)) return true;
    if((l.match(/[<>={}\[\]_]/g)||[]).length >= 3) return true;
    if(weirdCharRatio(l) > 0.22) return true;
    if(l.length > 18 && mostlyLettersOrNumbers(l) < 0.45) return true;
    // Many OCR artifacts from photos look like scattered short words and symbols.
    const words = l.split(/\s+/).filter(Boolean);
    if(words.length >= 5){
      const short = words.filter(w=>/^[A-Za-z]{1,2}$/.test(w)).length;
      if(short / words.length > 0.48 && !/\b(?:am|pm|mi)\b/i.test(l)) return true;
    }
    return false;
  }
  function isProbablyMetaNameLine(line){
    const l = String(line||'').trim();
    if(!l || l.length > 70) return false;
    if(/\b(?:sale|garage|yard|moving|estate|rummage|address|location|today|tomorrow|fri|sat|sun|mon|tue|wed|thu|\d{1,6}\s+\w+)\b/i.test(l)) return false;
    // Facebook author names are often two or three capitalized words.
    if(/^([A-Z][a-z]+\s+){1,4}[A-Z][a-z]+$/.test(l)) return true;
    if(/^[A-Z][A-Za-z'.-]+\s+[A-Z][A-Za-z'.-]+\s+(?:May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|Jan|Feb|Mar|Apr)\s+\d{1,2}/.test(l)) return true;
    return false;
  }
  function normalizeOcrListingLine(line){
    return String(line||'')
      .replace(/\r/g,' ')
      .replace(/[“”]/g,'"')
      .replace(/[‘’]/g,"'")
      .replace(/\b[Mm][Il1]\b/g,'MI')
      .replace(/\bGiadwin\b/gi,'Gladwin')
      .replace(/\bCiare\b/gi,'Clare')
      .replace(/\b([a-z]+)\.(?=\d)/gi,'$1. ')
      .replace(/\s+/g,' ')
      .trim();
  }
  function lineHasUsefulSaleSignal(line){
    const l = normalizeOcrListingLine(line);
    if(!l) return false;
    if(hasStreetAddress(l) || extractStrictStreetAddress(l)) return true;
    if(/\b(?:garage|yard|moving|estate|rummage|barn|tag|multi[ -]?family|sale|free sale)\b/i.test(l)) return true;
    if(/\b(?:today|tomorrow|fri(?:day)?|sat(?:urday)?|sun(?:day)?|mon(?:day)?|tue(?:sday)?|wed(?:nesday)?|thu(?:rsday)?|may|june?|july?|aug(?:ust)?|sept?|oct|nov|dec|jan|feb|mar|apr)\b/i.test(l) && /\d/.test(l)) return true;
    if(/\b\d{1,2}\s*(?:-|to|–|—)\s*\d{1,2}\s*(?:am|pm)?\b/i.test(l)) return true;
    if(ITEM_RE.test(l) && l.length < 120) return true;
    return false;
  }
  function cleanOcrText(raw){
    let text = String(raw||'')
      .replace(/\r/g,'\n')
      .replace(/[“”]/g,'"')
      .replace(/[‘’]/g,"'")
      .replace(/\bM[Il1]\b/g,'MI')
      .replace(/\bGiadwin\b/gi,'Gladwin')
      .replace(/\bCiare\b/gi,'Clare')
      .replace(/\bMiddie[ -]?town\b/gi,'Midland')
      .replace(/[ \t]+/g,' ')
      .replace(/\n[ \t]+/g,'\n')
      .replace(/[ \t]+\n/g,'\n');
    const lines = text.split('\n')
      .map(normalizeOcrListingLine)
      .filter(l=>l && !isFacebookUiLine(l) && !isOcrGarbageLine(l));
    return lines.join('\n').replace(/\n{3,}/g,'\n\n').trim();
  }
  function extractUsefulSaleTextFromOcr(raw){
    const lines = String(raw||'').split(/\n+/)
      .map(normalizeOcrListingLine)
      .filter(l=>l && !isFacebookUiLine(l) && !isOcrGarbageLine(l) && !isProbablyMetaNameLine(l));
    if(!lines.length) return '';
    const useful = [];
    for(let i=0;i<lines.length;i++){
      const l = lines[i];
      if(lineHasUsefulSaleSignal(l)) useful.push({i,l});
    }
    if(!useful.length) return '';
    // Keep sale text around useful lines, but do not keep the whole OCR dump.
    const keep = new Set();
    useful.forEach(({i})=>{
      for(let j=Math.max(0,i-1); j<=Math.min(lines.length-1,i+2); j++){
        const line = lines[j];
        if(isProbablyMetaNameLine(line) || isFacebookUiLine(line) || isOcrGarbageLine(line)) continue;
        // Keep nearby item text only if it is short and normal-looking.
        if(j!==i && !lineHasUsefulSaleSignal(line) && line.length > 100) continue;
        keep.add(j);
      }
    });
    const out = [...keep].sort((a,b)=>a-b).map(i=>lines[i]);
    return out.join('\n').replace(/\n{3,}/g,'\n\n').trim();
  }
  function realisticStreetAddress(addr){
    const a = String(addr||'').trim();
    if(!a || isOcrGarbageLine(a)) return false;
    const m = a.match(/^\s*(\d{1,6})\s+(.+?)\s+(street|st\.?|road|rd\.?|avenue|ave\.?|drive|dr\.?|lane|ln\.?|court|ct\.?|circle|cir\.?|boulevard|blvd\.?|trail|trl\.?|place|pl\.?|way|highway|hwy\.?|terrace|ter\.?|parkway|pkwy\.?|loop|path|alley)\b/i);
    if(!m) return ROUTE_RE.test(a) && /\b(?:Gladwin|Beaverton|Clare|Harrison|Midland|Mount Pleasant|West Branch|MI|Michigan)\b/i.test(a);
    const num = Number(m[1]);
    if(num < 10) return false; // avoid OCR junk like "3 REE ER A ST" becoming a route.
    const streetName = m[2].trim();
    const streetNameNoDir = streetName.replace(/^(?:N|S|E|W|NE|NW|SE|SW)\s+/i,'');
    const tokens = streetNameNoDir.split(/\s+/).filter(Boolean);
    if(tokens.length > 7) return false;
    if(tokens.filter(t=>/^[A-Za-z]$/.test(t)).length > 1) return false;
    if(/(?:REE\s+ER|NQF|QQ|^[A-Z]\s+[A-Z])/i.test(streetNameNoDir)) return false;
    return true;
  }
  function parsePostAddress(text){
    const lines = cleanPostText(text).split('\n').map(l=>l.trim()).filter(Boolean);
    const candidates = [];
    function add(raw, labelled=false, why=''){
      const cleaned = cleanAddressCandidate(raw);
      if(!cleaned || !realisticStreetAddress(cleaned)) return;
      const score = scoreAddressCandidate(cleaned, labelled);
      if(score > 0) candidates.push({raw:cleaned, score, labelled, why});
    }
    for(let i=0;i<lines.length;i++){
      const line = lines[i];
      if(isFacebookUiLine(line) || isOcrGarbageLine(line)) continue;
      if(/^(?:address|addy|location|where|located\s+at|located|place|pickup|pick up)\s*[:\-–—]?\s*$/i.test(line) && lines[i+1]) add(lines[i+1], true, 'label-next-line');
      if(/^(?:address|addy|location|where|located\s+at|located|place|pickup|pick up)\s*[:\-–—]\s+/i.test(line)) add(line, true, 'label');
      const inline = line.match(/\b(?:address|addy|location|where|located\s+at|located|pickup|pick up)\s*[:\-–—]?\s+(.{3,110})$/i);
      if(inline) add(inline[1], true, 'inline-label');
      const atStreet = line.match(/\b(?:at|@)\s+(\d{1,6}\s+[^\n]{2,95})/i);
      if(atStreet) add(atStreet[1], false, 'at-street');
      // This handles full sentences: "Yard Sale today 2645 lakeshore dr.1 -6 pm..."
      const strict = extractStrictStreetAddress(line);
      if(strict) add(strict, false, 'street-inside-line');
    }
    candidates.sort((a,b)=>b.score-a.score);
    const best = candidates[0];
    if(best && best.score >= 70) return {address:finishAddress(best.raw), confidence:best.score>=95?'high':'medium', warning:best.score>=95?'':'Possible address found — double-check it before saving.'};
    const city = cleanPostText(text).match(LOCAL_CITY_RE);
    if(city) return {address:'', city:city[0].replace(/Mt\.?/i,'Mount') + ', MI', confidence:'city-only', warning:'I only found the city. I left the address blank so it does not route to the wrong place.'};
    return {address:'', city:'', confidence:'none', warning:'I did not find a safe address, so I left the address blank instead of guessing.'};
  }
  function parsePostTitle(text){
    const lines = cleanPostText(text).split('\n').map(l=>l.trim()).filter(Boolean).filter(l=>!isFacebookUiLine(l) && !isOcrGarbageLine(l) && !isProbablyMetaNameLine(l));
    for(const l of lines){
      const m = l.match(/\b((?:large\s+|huge\s+|multi[ -]?family\s+|neighborhood\s+|church\s+|barn\s+)?(?:garage|yard|moving|estate|rummage|tag)\s+sale)\b/i);
      if(m) return m[1].replace(/\s+/g,' ').replace(/\b\w/g,c=>c.toUpperCase());
    }
    return 'Yard sale';
  }
  function likelySaleChunk(chunk){
    const c = extractUsefulSaleTextFromOcr(cleanOcrText(chunk));
    if(c.length < 8) return false;
    const hasSale = /\b(garage|yard|moving|estate|rummage|barn|tag|multi[ -]?family|sale)\b/i.test(c);
    const hasAddr = !!parsePostAddress(c).address;
    return (hasSale && (hasAddr || parsePostDate(c).iso || parsePostTime(c).time)) || (hasAddr && (parsePostTime(c).time || parsePostDate(c).iso));
  }
  function extractSaleChunks(text){
    const cleaned = cleanOcrText(text);
    if(!cleaned) return [];
    // If OCR was joined with explicit separators from image crops, keep those blocks separate.
    const hardParts = cleaned.split(/\n\s*(?:---SALESCOUT-CROP---|-{3,}|={3,}|_{3,}|\*{3,}|•{3,})\s*\n/g)
      .map(extractUsefulSaleTextFromOcr)
      .filter(likelySaleChunk);
    if(hardParts.length > 1) return hardParts;
    const lines = cleaned.split('\n').map(l=>l.trim()).filter(Boolean);
    const starts = [];
    for(let i=0;i<lines.length;i++){
      const l = lines[i];
      if(isFacebookUiLine(l) || isOcrGarbageLine(l) || isProbablyMetaNameLine(l)) continue;
      if(/\b(large\s+)?(garage|yard|moving|estate|rummage|barn|tag|multi[ -]?family)\s+sale\b/i.test(l) || parsePostAddress(l).address) starts.push(i);
    }
    const uniqueStarts = starts.filter((x,i)=>i===0 || x-starts[i-1] > 2);
    if(uniqueStarts.length > 1){
      const chunks=[];
      for(let i=0;i<uniqueStarts.length;i++){
        const start=uniqueStarts[i];
        const end=i+1<uniqueStarts.length ? uniqueStarts[i+1]-1 : lines.length-1;
        const chunk=extractUsefulSaleTextFromOcr(lines.slice(start,end+1).join('\n'));
        if(likelySaleChunk(chunk)) chunks.push(chunk);
      }
      if(chunks.length > 1) return chunks;
    }
    return [extractUsefulSaleTextFromOcr(cleaned) || cleaned].filter(Boolean);
  }
  function isSafeParsedSale(p){
    if(!p || !p.address) return false;
    if(!realisticStreetAddress(p.address)) return false;
    const raw = cleanOcrText(p._raw || p.notes || '');
    if(isOcrGarbageLine(p.title || '')) return false;
    if(raw && weirdCharRatio(raw) > 0.16) return false;
    return true;
  }
  function importSalesFromText(text, fromPhoto=false){
    const cleaned = cleanOcrText(text);
    if(!cleaned){ alert(fromPhoto ? 'No sale text was read from that photo.' : 'Paste or read some listing text first.'); return false; }
    const chunks = extractSaleChunks(cleaned);
    const parsed = chunks.map(parseSaleFromText).filter(isSafeParsedSale);
    const withAddress = dedupeParsedSales(parsed);
    if(withAddress.length <= 1){
      const one = withAddress[0] || parseSaleFromText(chunks[0] || cleaned);
      fillFormFromParsed(one);
      $('parseStatus').textContent += ' I only found one safe sale/address, so I filled the form instead of importing a batch.';
      return false;
    }
    withAddress.forEach(p=>{
      sales.push({id:uid(), title:p.title||'Yard sale', address:p.address, date:p.date||'', time:p.time||'', notes:p.notes||'', include:true, visited:false, order:nextOrder(), lat:null, lon:null, geocodedAddress:'', geocodeVersion:0});
    });
    save();
    closeModal();
    alert('Imported '+withAddress.length+' sales. I skipped anything without a safe address.');
    return true;
  }
  function canvasFromImage(img){
    const canvas = document.createElement('canvas');
    canvas.width = img.naturalWidth;
    canvas.height = img.naturalHeight;
    const ctx = canvas.getContext('2d', {willReadFrequently:true});
    ctx.drawImage(img,0,0);
    return {canvas, ctx};
  }
  function detectLightTextBands(img){
    const {canvas, ctx} = canvasFromImage(img);
    const w=canvas.width, h=canvas.height;
    const data = ctx.getImageData(0,0,w,h).data;
    const stepY = Math.max(2, Math.floor(h/520));
    const stepX = Math.max(4, Math.floor(w/120));
    const rows=[];
    for(let y=0;y<h;y+=stepY){
      let light=0, total=0;
      for(let x=Math.floor(w*0.04); x<Math.floor(w*0.96); x+=stepX){
        const i=(y*w+x)*4;
        const r=data[i], g=data[i+1], b=data[i+2];
        const lum=0.299*r+0.587*g+0.114*b;
        const neutral=(Math.max(r,g,b)-Math.min(r,g,b))<48;
        if(lum>224 && neutral) light++;
        total++;
      }
      rows.push({y, lightRatio:light/Math.max(1,total)});
    }
    const bands=[];
    let inBand=false, start=0, last=0;
    for(const row of rows){
      const isLight=row.lightRatio>0.50;
      if(isLight && !inBand){ inBand=true; start=row.y; }
      if(isLight) last=row.y;
      if(!isLight && inBand){
        if(last-start > 28) bands.push({y:Math.max(0,start-8), h:Math.min(h, last+stepY+8)-Math.max(0,start-8)});
        inBand=false;
      }
    }
    if(inBand && last-start > 28) bands.push({y:Math.max(0,start-8), h:Math.min(h, last+stepY+8)-Math.max(0,start-8)});
    // Merge close bands, because author/date and post text may be separated by tiny gutters.
    const merged=[];
    for(const b of bands){
      const prev=merged[merged.length-1];
      if(prev && b.y - (prev.y+prev.h) < 34){ prev.h = Math.max(prev.y+prev.h, b.y+b.h)-prev.y; }
      else merged.push({...b});
    }
    return merged.filter(b=>b.h>=42 && b.h<=Math.min(420, h*0.42));
  }
  async function buildOcrInputs(file){
    const img = await loadImageFromFile(file);
    const w = img.naturalWidth, h = img.naturalHeight;
    const inputs = [];
    const pushCrop = async (label, crop) => inputs.push({label, image: await makeOcrBlob(img, crop)});
    if(h > w * 1.08){
      const bands = detectLightTextBands(img);
      // Use only light text bands for Facebook-style screenshots, not the photo area.
      for(let i=0;i<Math.min(bands.length,8);i++){
        const b = bands[i];
        await pushCrop('text area '+(i+1), {x:0, y:b.y, w, h:b.h});
      }
      if(inputs.length) return inputs;
      // Fallback: top/middle/bottom strips, but only shallow strips to avoid the big photos.
      const third=Math.floor(h/3);
      await pushCrop('top text strip', {x:0,y:0,w,h:Math.min(h, third)});
      await pushCrop('middle text strip', {x:0,y:third,w,h:third});
      await pushCrop('bottom text strip', {x:0,y:third*2,w,h:h-third*2});
      return inputs;
    }
    if(w > h * 1.12){
      const mid = Math.floor(w/2);
      await pushCrop('left column', {x:0,y:0,w:mid,h});
      await pushCrop('right column', {x:mid,y:0,w:w-mid,h});
      return inputs;
    }
    return [{label:'photo', image:await makeOcrBlob(img,null)}];
  }
  async function parsePhotoPost(file){
    if(!file) return;
    $('parseStatus').textContent = 'Preparing screenshot/photo. I will ignore buttons, headers, and photo areas when possible...';
    if(!window.Tesseract){
      $('parseStatus').textContent = 'Photo reading could not load. Check internet, or paste the text manually.';
      return;
    }
    try{
      const inputs = await buildOcrInputs(file);
      const usefulPieces = [];
      for(let i=0;i<inputs.length;i++){
        const part = inputs[i];
        $('parseStatus').textContent = 'Reading '+part.label+'... this can take a minute.';
        const result = await Tesseract.recognize(part.image, 'eng', {
          logger: m => {
            if(!m || !m.status) return;
            const pct = typeof m.progress === 'number' ? ' ' + Math.round(m.progress * 100) + '%' : '';
            $('parseStatus').textContent = 'Reading '+part.label+': ' + m.status + pct;
          },
          tessedit_pageseg_mode: '6',
          preserve_interword_spaces: '1'
        });
        const raw = result && result.data && result.data.text ? result.data.text : '';
        const useful = extractUsefulSaleTextFromOcr(raw);
        if(useful && likelySaleChunk(useful)) usefulPieces.push(useful);
      }
      const unique = [];
      const seen = new Set();
      usefulPieces.forEach(t=>{
        const key = t.toLowerCase().replace(/[^a-z0-9]+/g,' ').slice(0,160);
        if(key && !seen.has(key)){ seen.add(key); unique.push(t); }
      });
      const text = unique.join('\n\n---SALESCOUT-CROP---\n\n').trim();
      if(!text){
        $('postPaste').value = '';
        $('parseStatus').textContent = 'I could not find clean sale text in that screenshot. Crop closer to just the post text, or copy/paste the post text.';
        return;
      }
      $('postPaste').value = text;
      const chunks = extractSaleChunks(text);
      const safeCount = dedupeParsedSales(chunks.map(parseSaleFromText).filter(isSafeParsedSale)).length;
      if(safeCount > 1){
        $('parseStatus').textContent = 'I found '+safeCount+' safe sale listings. Review the text, then tap Import all found.';
        return;
      }
      fillFormFromParsed(parseSaleFromText(chunks[0] || text));
      $('parseStatus').textContent += ' I ignored Facebook buttons/headers/photo text as much as possible. Still double-check the address.';
    }catch(e){
      $('parseStatus').textContent = 'Could not read that photo. Try a clearer/cropped screenshot, or paste the post text.';
    }finally{
      $('postImageInput').value = '';
    }
  }


  // v14 parser/preview override: treat OCR as draft text, preview multiple possible sales, and extract only street addresses.
  let salePreviewItems = [];
  let salePreviewIndex = 0;
  function compactText(s){ return String(s||'').replace(/\s+/g,' ').trim(); }
  function cleanListingForNotes(text){
    const lines = cleanOcrText(text).split('\n').map(l=>l.trim()).filter(Boolean)
      .filter(l=>!isFacebookUiLine(l) && !isOcrGarbageLine(l) && !isProbablyMetaNameLine(l));
    return lines.join('\n').trim();
  }
  function normalizeStreetSuffix(s){
    return String(s||'')
      .replace(/\bAue\b/gi,'Ave')
      .replace(/\bAvc\b/gi,'Ave')
      .replace(/\bRcl\b/gi,'Rd')
      .replace(/\bDrivc\b/gi,'Drive')
      .replace(/\bGiadwin\b/gi,'Gladwin')
      .replace(/\bCiare\b/gi,'Clare')
      .replace(/\bM[Il1]\b/g,'MI');
  }
  function extractStrictStreetAddress(raw){
    let s = normalizeStreetSuffix(String(raw||''))
      .replace(/^[📍🗺️🏠➡️\s]+/u,'')
      .replace(/[“”]/g,'"').replace(/[‘’]/g,"'")
      .replace(/\b(st|rd|dr|ave|ln|ct|cir|blvd|trl|pl|hwy|pkwy|ter)\.(?=\d)/ig, '$1. ')
      .replace(/\s+/g,' ')
      .trim();
    s = stripAddressLabel(s);
    const streetSuffix = '(?:street|st\\.?|road|rd\\.?|avenue|ave\\.?|drive|dr\\.?|lane|ln\\.?|court|ct\\.?|circle|cir\\.?|boulevard|blvd\\.?|trail|trl\\.?|place|pl\\.?|way|highway|hwy\\.?|terrace|ter\\.?|parkway|pkwy\\.?|loop|path|alley)';
    const cityNames = '(?:Gladwin|Beaverton|Clare|Harrison|Midland|Mount Pleasant|Mt\\.? Pleasant|West Branch|Coleman|Farwell|Sanford|Auburn|Pinconning|Roscommon|Prudenville|Houghton Lake|Standish|Bay City|Rose City|St\\.? Charles)';
    const re = new RegExp("(?:^|\\b)(\\d{1,6}\\s+(?:(?:N|S|E|W|NE|NW|SE|SW)\\s+)?(?:[A-Za-z0-9.#'’&-]+\\s+){0,6}"+streetSuffix+"\\b\\.?)(?:\\s*,?\\s*)?("+cityNames+")?(?:\\s*,?\\s*(MI|Michigan))?", 'i');
    const m = s.match(re);
    if(!m) return '';
    let out = (m[1]||'').trim().replace(/[\s,.;:]+$/,'');
    if(m[2]) out += ', ' + m[2].replace(/Mt\.?/i,'Mount').trim();
    if(m[3] && !/\bMI\b/i.test(out)) out += ', MI';
    return out.replace(/\s{2,}/g,' ');
  }
  function cleanAddressCandidate(raw){
    let s = normalizeStreetSuffix(String(raw||'')).replace(/^[📍🗺️🏠➡️\s]+/u,'').trim();
    s = stripAddressLabel(s);
    s = s.replace(/\b(st|rd|dr|ave|ln|ct|cir|blvd|trl|pl|hwy|pkwy|ter)\.(?=\d)/ig, '$1. ');
    const strict = extractStrictStreetAddress(s);
    if(strict) return strict;
    s = s.replace(/\s+(?:no early birds|no early sales|please message|message me|pm me|cash only|venmo|paypal)\b.*$/i,'');
    s = s.replace(/\s+(?:sale starts?|starts?|hours?|open)\s*[:\-]?\s*\d{1,2}.*$/i,'');
    s = s.replace(/\b\d{1,2}\s*(?:-|to|–|—)\s*\d{1,2}\s*(?:am|pm)\b.*$/i,'');
    s = s.replace(/[\s.]+$/,'').replace(/\s{2,}/g,' ');
    return s;
  }
  function parsePostAddress(text){
    const lines = cleanPostText(text).split('\n').map(l=>l.trim()).filter(Boolean);
    const candidates = [];
    function add(raw, labelled=false, why=''){
      const cleaned = cleanAddressCandidate(raw);
      if(!cleaned || !realisticStreetAddress(cleaned)) return;
      const score = scoreAddressCandidate(cleaned, labelled);
      if(score > 0) candidates.push({raw:cleaned, score, labelled, why});
    }
    for(let i=0;i<lines.length;i++){
      const line = normalizeStreetSuffix(lines[i]);
      if(isFacebookUiLine(line) || isOcrGarbageLine(line)) continue;
      if(/^(?:address|addy|location|where|located\s+at|located|place|pickup|pick up)\s*[:\-–—]?\s*$/i.test(line) && lines[i+1]) add(lines[i+1], true, 'label-next-line');
      if(/^(?:address|addy|location|where|located\s+at|located|place|pickup|pick up)\s*[:\-–—]\s+/i.test(line)) add(line, true, 'label');
      const inline = line.match(/\b(?:address|addy|location|where|located\s+at|located|pickup|pick up)\s*[:\-–—]?\s+(.{3,130})$/i);
      if(inline) add(inline[1], true, 'inline-label');
      const atStreet = line.match(/\b(?:at|@)\s+(\d{1,6}\s+[^\n]{2,110})/i);
      if(atStreet) add(atStreet[1], false, 'at-street');
      const strict = extractStrictStreetAddress(line);
      if(strict) add(strict, false, 'street-inside-line');
      // Also test the line with the next city line attached, in case OCR wrapped it.
      if(lines[i+1]){
        const paired = line + ' ' + lines[i+1];
        const strict2 = extractStrictStreetAddress(paired);
        if(strict2) add(strict2, false, 'street-wrap');
      }
    }
    candidates.sort((a,b)=>b.score-a.score);
    const best = candidates[0];
    if(best && best.score >= 70) return {address:finishAddress(best.raw), confidence:best.score>=95?'high':'medium', warning:best.score>=95?'':'Possible address found — double-check it before saving.'};
    const city = cleanPostText(text).match(LOCAL_CITY_RE);
    if(city) return {address:'', city:city[0].replace(/Mt\.?/i,'Mount') + ', MI', confidence:'city-only', warning:'I only found the city. I left the address blank so it does not route to the wrong place.'};
    return {address:'', city:'', confidence:'none', warning:'I did not find a safe address, so I left the address blank instead of guessing.'};
  }
  realisticStreetAddress = function(addr){
    const a = normalizeStreetSuffix(String(addr||'').trim());
    if(!a || isOcrGarbageLine(a)) return false;
    const strict = extractStrictStreetAddress(a);
    const test = strict || a;
    const m = test.match(/^\s*(\d{1,6})\s+(.+?)\s+(street|st\.?|road|rd\.?|avenue|ave\.?|drive|dr\.?|lane|ln\.?|court|ct\.?|circle|cir\.?|boulevard|blvd\.?|trail|trl\.?|place|pl\.?|way|highway|hwy\.?|terrace|ter\.?|parkway|pkwy\.?|loop|path|alley)\b/i);
    if(!m) return ROUTE_RE.test(test) && /\b(?:Gladwin|Beaverton|Clare|Harrison|Midland|Mount Pleasant|West Branch|MI|Michigan)\b/i.test(test);
    const num = Number(m[1]);
    if(num < 10) return false;
    const streetName = m[2].trim();
    const streetNameNoDir = streetName.replace(/^(?:N|S|E|W|NE|NW|SE|SW)\s+/i,'');
    const tokens = streetNameNoDir.split(/\s+/).filter(Boolean);
    if(tokens.length > 7) return false;
    if(tokens.filter(t=>/^[A-Za-z]$/.test(t)).length > 1) return false;
    if(/(?:REE\s+ER|NQF|QQ|^[A-Z]\s+[A-Z])/i.test(streetNameNoDir)) return false;
    return true;
  };
  parsePostTitle = function(text){
    const lines = cleanPostText(text).split('\n').map(l=>l.trim()).filter(Boolean).filter(l=>!isFacebookUiLine(l) && !isOcrGarbageLine(l) && !isProbablyMetaNameLine(l));
    for(const l of lines){
      const m = l.match(/\b((?:large\s+|huge\s+|multi[ -]?family\s+|neighborhood\s+|church\s+|barn\s+)?(?:garage|yard|moving|estate|rummage|tag)\s+sales?)\b/i);
      if(m) return m[1].replace(/\s+/g,' ').replace(/\b\w/g,c=>c.toUpperCase()).replace(/Sales$/,'Sale');
    }
    return 'Yard sale';
  };
  function splitIntoListingChunks(text){
    const cleaned = cleanOcrText(text);
    if(!cleaned) return [];
    // Keep explicit OCR crop breaks, but do not throw out chunks just because one has no address yet.
    let chunks = cleaned.split(/\n\s*(?:---SALESCOUT-CROP---|-{3,}|={3,}|_{3,}|\*{3,}|•{3,})\s*\n/g)
      .map(c=>cleanListingForNotes(c))
      .filter(c=>c && c.length > 8);
    if(chunks.length > 1) return chunks;
    const lines = cleaned.split('\n').map(l=>l.trim()).filter(Boolean)
      .filter(l=>!isFacebookUiLine(l) && !isOcrGarbageLine(l));
    const starts = [];
    for(let i=0;i<lines.length;i++){
      const l = lines[i];
      if(isProbablyMetaNameLine(l)) continue;
      if(/\b(?:large\s+|huge\s+|multi[ -]?family\s+|neighborhood\s+|church\s+|barn\s+)?(?:garage|yard|moving|estate|rummage|tag)\s+sale\b/i.test(l)) starts.push(i);
      else if(extractStrictStreetAddress(l)) starts.push(Math.max(0,i-3));
    }
    const unique = [...new Set(starts)].sort((a,b)=>a-b).filter((x,i,a)=>i===0 || x-a[i-1]>2);
    if(unique.length > 1){
      chunks = [];
      for(let i=0;i<unique.length;i++){
        const start = unique[i];
        const end = i+1<unique.length ? unique[i+1]-1 : lines.length-1;
        const chunk = cleanListingForNotes(lines.slice(start,end+1).join('\n'));
        if(chunk.length > 8) chunks.push(chunk);
      }
      if(chunks.length > 1) return chunks;
    }
    return [cleanListingForNotes(cleaned) || cleaned];
  }
  function parseSaleFromText(text){
    const post = cleanListingForNotes(text);
    const date = parsePostDate(post);
    const time = parsePostTime(post);
    const addr = parsePostAddress(post);
    const title = parsePostTitle(post);
    const found = [];
    const warnings = [];
    if(title) found.push('title');
    if(addr.address) found.push('address'); else warnings.push(addr.warning || 'No safe address found.');
    if(date.iso) found.push('date');
    if(time.time) found.push('start time');
    if(addr.warning && addr.address) warnings.push(addr.warning);
    const noteLines = [];
    if(addr.city && !addr.address) noteLines.push('City found but not used as route address: '+addr.city);
    if(date.label) noteLines.push('Post date text: '+date.label);
    if(time.label) noteLines.push('Post time text: '+time.label);
    noteLines.push('Original listing text:');
    noteLines.push(post);
    return {title:title || 'Yard sale', address:addr.address || '', date:date.iso || '', time:time.time || '', notes:noteLines.join('\n'), include:true, visited:false, _found:found, _warnings:warnings, _raw:post};
  }
  function previewSafeText(s){
    return String(s||'').replace(/[&<>]/g, c=>({ '&':'&amp;', '<':'&lt;', '>':'&gt;' }[c]));
  }
  function currentFormParsedSale(){
    return {
      title: $('saleTitle').value.trim() || 'Yard sale',
      address: $('saleAddress').value.trim(),
      date: $('saleDate').value || '',
      time: $('saleTime').value || '',
      notes: $('saleNotes').value.trim(),
      include: $('saleInclude').checked,
      visited:false,
      _found:[],
      _warnings:[],
      _raw: $('postPaste').value || ''
    };
  }
  function storeCurrentFormToPreview(){
    if(!salePreviewItems.length || salePreviewIndex < 0 || salePreviewIndex >= salePreviewItems.length) return;
    const existing = salePreviewItems[salePreviewIndex] || {};
    const edited = currentFormParsedSale();
    salePreviewItems[salePreviewIndex] = Object.assign({}, existing, edited, {_raw: existing._raw || edited._raw});
  }
  function updateSaveAllButton(){
    const btn = $('saveAllFoundBtn');
    if(!btn) return;
    const count = salePreviewItems.filter(isSafeParsedSale).length;
    if(salePreviewItems.length > 1 && count > 0){
      btn.style.display = 'inline-block';
      btn.textContent = count === salePreviewItems.length ? 'Save all found' : 'Save '+count+' with addresses';
    }else{
      btn.style.display = 'none';
      btn.textContent = 'Save all found';
    }
  }
  function resetSalePreview(){
    salePreviewItems = [];
    salePreviewIndex = 0;
    const box = $('multiPreview');
    if(box){ box.style.display = 'none'; box.innerHTML = ''; }
    updateSaveAllButton();
  }
  function showSalePreviewFromText(text, sourceLabel='text'){
    const chunks = splitIntoListingChunks(text);
    salePreviewItems = chunks.map(parseSaleFromText);
    salePreviewIndex = 0;
    renderSalePreview();
    if(salePreviewItems.length){ fillFormFromParsed(salePreviewItems[0]); }
    updateSaveAllButton();
    if(salePreviewItems.length > 1){
      const valid = salePreviewItems.filter(isSafeParsedSale).length;
      $('parseStatus').textContent = 'Found '+salePreviewItems.length+' possible listings from '+sourceLabel+'. Use the tabs to check each one. '+valid+' have safe addresses and can be saved all at once with the bottom Save all found button.';
    }
  }
  function renderSalePreview(){
    const box = $('multiPreview');
    if(!box) return;
    if(!salePreviewItems.length || salePreviewItems.length <= 1){ box.style.display='none'; box.innerHTML=''; updateSaveAllButton(); return; }
    box.style.display='block';
    const tabs = salePreviewItems.map((p,i)=>'<button type="button" class="'+(i===salePreviewIndex?'active':'')+'" onclick="selectSalePreview('+i+')">Sale '+(i+1)+(p.address?'':' ⚠')+'</button>').join('');
    const p = salePreviewItems[salePreviewIndex];
    const warn = p.address ? '' : '<div class="previewWarn">Needs an address before it can be saved or imported.</div>';
    box.innerHTML = '<div class="previewTabs">'+tabs+'</div><div class="previewCard">'+warn+
      '<div><b>Name:</b> '+previewSafeText(p.title || '')+'</div>'+
      '<div><b>Address:</b> '+previewSafeText(p.address || '(blank)')+'</div>'+
      '<div><b>Date/time:</b> '+previewSafeText((p.date||'')+' '+(p.time||''))+'</div>'+
      '<div class="previewActions"><button type="button" class="secondary" onclick="selectSalePreview('+salePreviewIndex+')">Load this tab into form</button></div></div>';
    updateSaveAllButton();
  }
  function selectSalePreview(i){
    storeCurrentFormToPreview();
    salePreviewIndex = Math.max(0, Math.min(Number(i)||0, salePreviewItems.length-1));
    renderSalePreview();
    if(salePreviewItems[salePreviewIndex]) fillFormFromParsed(salePreviewItems[salePreviewIndex]);
  }
  function importSalesFromPreview(){
    storeCurrentFormToPreview();
    const total = salePreviewItems.length;
    const withAddress = dedupeParsedSales(salePreviewItems.filter(isSafeParsedSale));
    if(!withAddress.length){ alert('None of the found sales has a safe address yet. Fix the address on a tab, then tap Save all found again.'); return false; }
    withAddress.forEach(p=>sales.push({id:uid(), title:p.title||'Yard sale', address:p.address, date:p.date||'', time:p.time||'', notes:p.notes||'', include:p.include!==false, visited:false, order:nextOrder(), lat:null, lon:null, geocodedAddress:'', geocodeVersion:0}));
    save();
    closeModal();
    const skipped = Math.max(0, total - withAddress.length);
    alert('Saved '+withAddress.length+' sale'+(withAddress.length===1?'':'s')+(skipped ? '. I skipped '+skipped+' tab'+(skipped===1?'':'s')+' without a safe address.' : '.'));
    return true;
  }
  function parseFacebookPost(text){
    const cleaned = cleanOcrText(text);
    if(!cleaned){ alert('Paste the post text first.'); return; }
    showSalePreviewFromText(cleaned, 'text');
    if(salePreviewItems.length <= 1) $('parseStatus').textContent += ' Review it, especially the address, before saving.';
  }
  function importSalesFromText(text, fromPhoto=false){
    if(salePreviewItems.length > 1) return importSalesFromPreview();
    const cleaned = cleanOcrText(text);
    if(!cleaned){ alert(fromPhoto ? 'No sale text was read from that photo.' : 'Paste or read some listing text first.'); return false; }
    showSalePreviewFromText(cleaned, fromPhoto?'photo':'text');
    if(salePreviewItems.length > 1) return importSalesFromPreview();
    if(salePreviewItems[0]) fillFormFromParsed(salePreviewItems[0]);
    return false;
  }
  async function parsePhotoPost(file){
    if(!file) return;
    $('parseStatus').textContent = 'Reading screenshot/photo. I will try to keep only the post text, not buttons or pictures...';
    if(!window.Tesseract){ $('parseStatus').textContent = 'Photo reading could not load. Check internet, or paste the text manually.'; return; }
    try{
      const inputs = await buildOcrInputs(file);
      const usefulPieces = [];
      for(let i=0;i<inputs.length;i++){
        const part = inputs[i];
        $('parseStatus').textContent = 'Reading '+part.label+'... this can take a minute.';
        const result = await Tesseract.recognize(part.image, 'eng', {
          logger: m=>{ if(!m||!m.status) return; const pct=typeof m.progress==='number' ? ' '+Math.round(m.progress*100)+'%' : ''; $('parseStatus').textContent='Reading '+part.label+': '+m.status+pct; },
          tessedit_pageseg_mode:'6', preserve_interword_spaces:'1'
        });
        const raw = result && result.data && result.data.text ? result.data.text : '';
        const useful = extractUsefulSaleTextFromOcr(raw);
        if(useful) usefulPieces.push(useful);
      }
      const text = usefulPieces.join('\n\n---SALESCOUT-CROP---\n\n').trim();
      if(!text){ $('postPaste').value=''; $('parseStatus').textContent='I could not find clean sale text in that screenshot. Crop closer to the written post text, or copy/paste the post text.'; return; }
      $('postPaste').value = text;
      showSalePreviewFromText(text, 'photo');
      if(salePreviewItems.length <= 1) $('parseStatus').textContent += ' I filled the form with the best match. Double-check the address.';
    }catch(e){
      $('parseStatus').textContent = 'Could not read that photo. Try a clearer/cropped screenshot, or paste the post text.';
    }finally{ $('postImageInput').value=''; }
  }
  window.selectSalePreview = selectSalePreview;
  window.importSalesFromPreview = importSalesFromPreview;



  // v15 OCR/address fix: keep full Facebook text areas, recognize suffixes like "Run", and preview multiple cleaned listings.
  function normalizeStreetSuffix(s){
    return String(s||'')
      .replace(/[“”]/g,'"').replace(/[‘’]/g,"'")
      .replace(/\bAue\b/gi,'Ave')
      .replace(/\bAvc\b/gi,'Ave')
      .replace(/\bAvo\b/gi,'Ave')
      .replace(/\bRcl\b/gi,'Rd')
      .replace(/\bRc\b/gi,'Rd')
      .replace(/\bR\.d\b/gi,'Rd')
      .replace(/\bDrivc\b/gi,'Drive')
      .replace(/\bPheasant\s+Ruin\b/gi,'Pheasant Run')
      .replace(/\bGiadwin\b/gi,'Gladwin')
      .replace(/\bGiadwln\b/gi,'Gladwin')
      .replace(/\bCiare\b/gi,'Clare')
      .replace(/\bM[Il1]\b/g,'MI');
  }
  function streetSuffixPattern(){
    return '(?:street|st\\.?|road|rd\\.?|avenue|ave\\.?|drive|dr\\.?|lane|ln\\.?|court|ct\\.?|circle|cir\\.?|boulevard|blvd\\.?|trail|trl\\.?|place|pl\\.?|way|highway|hwy\\.?|terrace|ter\\.?|parkway|pkwy\\.?|loop|path|alley|run|ridge|view|point|pt\\.?|creek|crossing|xing|pointe|knoll|hollow|hill|hills)';
  }
  function cityPattern(){
    return '(?:Gladwin|Beaverton|Clare|Harrison|Midland|Mount Pleasant|Mt\\.? Pleasant|West Branch|Coleman|Farwell|Sanford|Auburn|Pinconning|Roscommon|Prudenville|Houghton Lake|Standish|Bay City|Rose City|St\\.? Charles)';
  }
  function isFacebookUiLine(line){
    const l = String(line||'').trim();
    if(!l) return true;
    if(/^[-_=•*]+$/.test(l)) return true;
    if(/^(?:like|comment|share|send|home|watch|marketplace|notifications?|messenger|search|write a comment|view more comments|see more|see less|reply|all reactions|most relevant|top comments|admin|author|sponsored|follow|join group)$/i.test(l)) return true;
    if(/\b(?:like|comment|share)\b\s+\b(?:like|comment|share)\b/i.test(l)) return true;
    if(/^\s*[<←].{0,8}(gladwin|garage|yard|sale|group)/i.test(l)) return true;
    if(/gladwin\s+garage\s+and\s+yar/i.test(l)) return true;
    if(/garage\s+and\s+yard\s+sales?\s+group/i.test(l)) return true;
    // Facebook post-date metadata often OCRs like "May 21 - OQ" or "May 21 · Public". Do not treat that as the sale date.
    if(/^(?:may|jun|june|jul|july|aug|august|sep|sept|oct|nov|dec|jan|feb|mar|apr)\s+\d{1,2}\s*(?:[·•\-]\s*(?:public|friends|group|[Oo0Q]{1,3}|\S{1,5}))?$/i.test(l) && !/\b(?:garage|yard|sale|\d{1,2}\s*(?:am|pm)|\d{1,6}\s+\w+)/i.test(l)) return true;
    return false;
  }
  function hasStreetAddress(s){
    const txt = normalizeStreetSuffix(s);
    const suffix = new RegExp('\\b'+streetSuffixPattern()+'\\b','i');
    return /(^|\D)\d{1,6}\b/.test(txt) && (suffix.test(txt) || ROUTE_RE.test(txt));
  }
  function extractStrictStreetAddress(raw){
    let s = normalizeStreetSuffix(String(raw||''))
      .replace(/^[📍🗺️🏠➡️\s]+/u,'')
      .replace(/\b(st|rd|dr|ave|ln|ct|cir|blvd|trl|pl|hwy|pkwy|ter)\.(?=\d)/ig, '$1. ')
      .replace(/\s+/g,' ')
      .trim();
    s = stripAddressLabel(s);
    const streetSuffix = streetSuffixPattern();
    const cityNames = cityPattern();
    const re = new RegExp("(?:^|\\b)(\\d{1,6}\\s+(?:(?:N|S|E|W|NE|NW|SE|SW)\\s+)?(?:[A-Za-z0-9.#'’&-]+\\s+){0,6}"+streetSuffix+"\\b\\.?)(?:\\s*,?\\s*)?("+cityNames+")?(?:\\s*,?\\s*(MI|Michigan))?", 'i');
    const m = s.match(re);
    if(!m) return '';
    let out = (m[1]||'').trim().replace(/[\s,.;:]+$/,'');
    if(m[2]) out += ', ' + m[2].replace(/Mt\.?/i,'Mount').trim();
    if(m[3] && !/\bMI\b/i.test(out)) out += ', MI';
    return out.replace(/\s{2,}/g,' ');
  }
  function cleanAddressCandidate(raw){
    let s = normalizeStreetSuffix(String(raw||'')).replace(/^[📍🗺️🏠➡️\s]+/u,'').trim();
    s = stripAddressLabel(s);
    s = s.replace(/\b(st|rd|dr|ave|ln|ct|cir|blvd|trl|pl|hwy|pkwy|ter)\.(?=\d)/ig, '$1. ');
    const strict = extractStrictStreetAddress(s);
    if(strict) return strict;
    s = s.replace(/\s+(?:no early birds|no early sales|please message|message me|pm me|cash only|venmo|paypal)\b.*$/i,'');
    s = s.replace(/\s+(?:sale starts?|starts?|hours?|open)\s*[:\-]?\s*\d{1,2}.*$/i,'');
    s = s.replace(/\b\d{1,2}\s*(?:-|to|–|—)\s*\d{1,2}\s*(?:am|pm)\b.*$/i,'');
    s = s.replace(/[\s.]+$/,'').replace(/\s{2,}/g,' ');
    return s;
  }
  function scoreAddressCandidate(line, labelled=false){
    const s = cleanAddressCandidate(line);
    if(!s || s.length < 3 || s.length > 120) return -100;
    let score = labelled ? 35 : 0;
    if(hasStreetAddress(s)) score += 78;
    else if(hasHouseNumber(s) && labelled) score += 35;
    if(LOCAL_CITY_RE.test(s)) score += 16;
    if(STATE_RE.test(s)) score += 20;
    if(/^\d{1,6}\b/.test(s)) score += 8;
    if(!hasStreetAddress(s) && LOCAL_CITY_RE.test(s) && (STATE_RE.test(s)||labelled)) score += 20;
    if(isItemishLine(s) && !(labelled && hasStreetAddress(s))) score -= 75;
    if(/^[$•-]/.test(s)) score -= 40;
    if(/\b(?:for sale|iso|looking for|wanted)\b/i.test(s) && !labelled) score -= 30;
    return score;
  }
  function finishAddress(addr){
    let a = cleanAddressCandidate(addr);
    if(!a) return '';
    if(hasStreetAddress(a) && !LOCAL_CITY_RE.test(a) && !STATE_RE.test(a)) a += ', ' + homePlace();
    else if(hasStreetAddress(a) && LOCAL_CITY_RE.test(a) && !STATE_RE.test(a)) a += ', MI';
    else if(!hasStreetAddress(a) && LOCAL_CITY_RE.test(a) && !STATE_RE.test(a)) a += ', MI';
    return a;
  }
  realisticStreetAddress = function(addr){
    const a = normalizeStreetSuffix(String(addr||'').trim());
    if(!a || isOcrGarbageLine(a)) return false;
    const strict = extractStrictStreetAddress(a);
    const test = strict || a;
    const m = test.match(new RegExp('^\\s*(\\d{1,6})\\s+(.+?)\\s+'+streetSuffixPattern()+'\\b','i'));
    if(!m) return ROUTE_RE.test(test) && /\b(?:Gladwin|Beaverton|Clare|Harrison|Midland|Mount Pleasant|West Branch|MI|Michigan)\b/i.test(test);
    const num = Number(m[1]);
    if(num < 10) return false;
    const streetName = m[2].trim().replace(/^(?:N|S|E|W|NE|NW|SE|SW)\s+/i,'');
    const tokens = streetName.split(/\s+/).filter(Boolean);
    if(tokens.length > 7) return false;
    if(tokens.filter(t=>/^[A-Za-z]$/.test(t)).length > 1) return false;
    if(/(?:REE\s+ER|NQF|QQ|^[A-Z]\s+[A-Z])/i.test(streetName)) return false;
    return true;
  };
  function parsePostAddress(text){
    const lines = cleanPostText(text).split('\n').map(l=>l.trim()).filter(Boolean);
    const candidates = [];
    function add(raw, labelled=false, why=''){
      const cleaned = cleanAddressCandidate(raw);
      if(!cleaned || !realisticStreetAddress(cleaned)) return;
      const score = scoreAddressCandidate(cleaned, labelled);
      if(score > 0) candidates.push({raw:cleaned, score, labelled, why});
    }
    for(let i=0;i<lines.length;i++){
      const line = normalizeStreetSuffix(lines[i]);
      if(isFacebookUiLine(line) || isOcrGarbageLine(line)) continue;
      if(/^(?:address|addy|location|where|located\s+at|located|place|pickup|pick up)\s*[:\-–—]?\s*$/i.test(line) && lines[i+1]) add(lines[i+1], true, 'label-next-line');
      if(/^(?:address|addy|location|where|located\s+at|located|place|pickup|pick up)\s*[:\-–—]\s+/i.test(line)) add(line, true, 'label');
      const inline = line.match(/\b(?:address|addy|location|where|located\s+at|located|pickup|pick up)\s*[:\-–—]?\s+(.{3,130})$/i);
      if(inline) add(inline[1], true, 'inline-label');
      const atStreet = line.match(/\b(?:at|@)\s+(\d{1,6}\s+[^\n]{2,110})/i);
      if(atStreet) add(atStreet[1], false, 'at-street');
      const strict = extractStrictStreetAddress(line);
      if(strict) add(strict, false, 'street-inside-line');
      if(lines[i+1]){
        const paired = line + ' ' + normalizeStreetSuffix(lines[i+1]);
        const strict2 = extractStrictStreetAddress(paired);
        if(strict2) add(strict2, false, 'street-wrap');
      }
    }
    candidates.sort((a,b)=>b.score-a.score);
    const best = candidates[0];
    if(best && best.score >= 70) return {address:finishAddress(best.raw), confidence:best.score>=95?'high':'medium', warning:best.score>=95?'':'Possible address found — double-check it before saving.'};
    const city = cleanPostText(text).match(LOCAL_CITY_RE);
    if(city) return {address:'', city:city[0].replace(/Mt\.?/i,'Mount') + ', MI', confidence:'city-only', warning:'I only found the city. I left the address blank so it does not route to the wrong place.'};
    return {address:'', city:'', confidence:'none', warning:'I did not find a safe address, so I left the address blank instead of guessing.'};
  }
  function removeFbMetaDateLines(text){
    return String(text||'').split('\n').filter(l=>!isFacebookUiLine(l)).join('\n');
  }
  function parsePostDate(text){
    const source = removeFbMetaDateLines(cleanOcrText(text));
    const t = ' ' + source.toLowerCase() + ' ';
    if(/\btoday\b/.test(t)) return {iso:todayISO(), label:'today'};
    if(/\btomorrow\b/.test(t)){
      const d=new Date(); d.setDate(d.getDate()+1); d.setHours(12,0,0,0); d.setMinutes(d.getMinutes()-d.getTimezoneOffset());
      return {iso:d.toISOString().slice(0,10), label:'tomorrow'};
    }
    const monthNames = {jan:1,january:1,feb:2,february:2,mar:3,march:3,apr:4,april:4,may:5,jun:6,june:6,jul:7,july:7,aug:8,august:8,sep:9,sept:9,september:9,oct:10,october:10,nov:11,november:11,dec:12,december:12};
    let m = source.match(/\b(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t|tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\.?\s+(\d{1,2})(?:st|nd|rd|th)?\s*(?:-|–|—|to|through|thru)\s*(?:(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t|tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\.?\s*)?(\d{1,2})(?:st|nd|rd|th)?/i);
    if(m){
      let y = new Date().getFullYear();
      return {iso:isoFromParts(y, monthNames[m[1].toLowerCase().replace('.','')], Number(m[2])), label:m[0]};
    }
    m = source.match(/\b(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t|tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\.?\s+(\d{1,2})(?:st|nd|rd|th)?(?:,?\s*(20\d{2}|\d{2}))?\b/i);
    if(m){
      let y = m[3] ? Number(m[3]) : new Date().getFullYear(); if(y<100) y+=2000;
      return {iso:isoFromParts(y, monthNames[m[1].toLowerCase().replace('.','')], Number(m[2])), label:m[0]};
    }
    m = source.match(/\b(\d{1,2})[\/\-.](\d{1,2})(?:[\/\-.](20\d{2}|\d{2}))?\b/);
    if(m){
      let y = m[3] ? Number(m[3]) : new Date().getFullYear(); if(y<100) y+=2000;
      return {iso:isoFromParts(y, Number(m[1]), Number(m[2])), label:m[0]};
    }
    const days = [['sunday',0],['sun',0],['monday',1],['mon',1],['tuesday',2],['tues',2],['tue',2],['wednesday',3],['wed',3],['thursday',4],['thurs',4],['thu',4],['friday',5],['fri',5],['saturday',6],['sat',6]];
    for(const [name, idx] of days){ if(new RegExp('\\b'+name+'\\b','i').test(source)) return {iso:nextWeekdayISO(idx), label:name}; }
    return {iso:'', label:''};
  }
  function mergeOcrLines(text){
    const lines = String(text||'').split(/\n+/)
      .map(normalizeOcrListingLine)
      .filter(l=>l && l !== '---SALESCOUT-CROP---' && !/^SALESCOUT-CROP$/i.test(l) && !isFacebookUiLine(l) && !isOcrGarbageLine(l));
    const out=[];
    const seen=new Set();
    for(const l of lines){
      const key=l.toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
      if(!key) continue;
      // Do not dedupe tiny generic lines like dates too aggressively, but avoid repeated crop text.
      const sig=key.slice(0,120);
      if(seen.has(sig)) continue;
      seen.add(sig);
      out.push(l);
    }
    return out.join('\n');
  }
  function splitIntoListingChunks(text){
    const cleaned = mergeOcrLines(cleanOcrText(text));
    if(!cleaned) return [];
    const lines = cleaned.split('\n').map(l=>l.trim()).filter(Boolean)
      .filter(l=>!isFacebookUiLine(l) && !isOcrGarbageLine(l));
    const starts = [];
    for(let i=0;i<lines.length;i++){
      const l = lines[i];
      if(isProbablyMetaNameLine(l)) continue;
      if(/\b(?:large\s+|huge\s+|multi[ -]?family\s+|neighborhood\s+|church\s+|barn\s+)?(?:garage|yard|moving|estate|rummage|tag)\s+sales?\b/i.test(l)) starts.push(i);
      else if(extractStrictStreetAddress(l) && starts.length===0) starts.push(Math.max(0,i-3));
    }
    const unique = [...new Set(starts)].sort((a,b)=>a-b).filter((x,i,a)=>i===0 || x-a[i-1]>2);
    if(unique.length){
      const chunks=[];
      for(let i=0;i<unique.length;i++){
        const start=unique[i];
        const end=i+1<unique.length ? unique[i+1]-1 : lines.length-1;
        const chunk=cleanListingForNotes(lines.slice(start,end+1).join('\n'));
        if(chunk.length > 8) chunks.push(chunk);
      }
      if(chunks.length) return chunks;
    }
    return [cleanListingForNotes(cleaned) || cleaned];
  }
  async function buildOcrInputs(file){
    const img = await loadImageFromFile(file);
    const w = img.naturalWidth, h = img.naturalHeight;
    const inputs = [];
    const pushCrop = async (label, crop, psm='4') => inputs.push({label, image: await makeOcrBlob(img, crop), psm});
    if(h > w * 1.08){
      // Facebook-style vertical screenshot: read the whole content column and overlapping bands so addresses near Like/Share bars are not cut off.
      const top = Math.floor(h * 0.06);
      const bottom = Math.floor(h * 0.96);
      const usableH = bottom - top;
      await pushCrop('full Facebook text area', {x:0, y:top, w, h:usableH}, '4');
      await pushCrop('upper posts', {x:0, y:top, w, h:Math.floor(usableH*0.48)}, '4');
      await pushCrop('middle posts', {x:0, y:Math.floor(top+usableH*0.28), w, h:Math.floor(usableH*0.48)}, '4');
      await pushCrop('lower posts', {x:0, y:Math.floor(top+usableH*0.55), w, h:Math.floor(usableH*0.45)}, '4');
      return inputs;
    }
    if(w > h * 1.12){
      await pushCrop('full flyer/newspaper', {x:0,y:0,w,h}, '4');
      const mid = Math.floor(w/2);
      await pushCrop('left column', {x:0,y:0,w:mid,h}, '4');
      await pushCrop('right column', {x:mid,y:0,w:w-mid,h}, '4');
      return inputs;
    }
    return [{label:'photo', image:await makeOcrBlob(img,null), psm:'4'}];
  }
  async function parsePhotoPost(file){
    if(!file) return;
    $('parseStatus').textContent = 'Reading screenshot/photo. I will scan the full post text area and make review tabs for possible sales...';
    if(!window.Tesseract){ $('parseStatus').textContent = 'Photo reading could not load. Check internet, or paste the text manually.'; return; }
    try{
      const inputs = await buildOcrInputs(file);
      const usefulPieces = [];
      for(let i=0;i<inputs.length;i++){
        const part = inputs[i];
        $('parseStatus').textContent = 'Reading '+part.label+'... this can take a minute.';
        const result = await Tesseract.recognize(part.image, 'eng', {
          logger: m=>{ if(!m||!m.status) return; const pct=typeof m.progress==='number' ? ' '+Math.round(m.progress*100)+'%' : ''; $('parseStatus').textContent='Reading '+part.label+': '+m.status+pct; },
          tessedit_pageseg_mode: part.psm || '4', preserve_interword_spaces:'1'
        });
        const raw = result && result.data && result.data.text ? result.data.text : '';
        const useful = extractUsefulSaleTextFromOcr(raw);
        if(useful) usefulPieces.push(useful);
      }
      const text = mergeOcrLines(usefulPieces.join('\n')).trim();
      if(!text){ $('postPaste').value=''; $('parseStatus').textContent='I could not find clean sale text in that screenshot. Crop closer to the written post text, or copy/paste the post text.'; return; }
      $('postPaste').value = text;
      showSalePreviewFromText(text, 'photo');
      const valid = salePreviewItems.filter(isSafeParsedSale).length;
      if(salePreviewItems.length > 1) $('parseStatus').textContent = 'Found '+salePreviewItems.length+' possible listings from the photo. Use the Sale tabs to check each one. '+valid+' have safe addresses and can be saved with the bottom button.';
      else $('parseStatus').textContent += ' I filled the form with the best match. Double-check the address.';
    }catch(e){
      $('parseStatus').textContent = 'Could not read that photo. Try a clearer/cropped screenshot, or paste the post text.';
    }finally{ $('postImageInput').value=''; }
  }
  $('openAddBtn').onclick=()=>openModal(); $('cancelSaleBtn').onclick=closeModal; $('parsePostBtn').onclick=()=>parseFacebookPost($('postPaste').value); if($('importAllBtn')) $('importAllBtn').onclick=()=>importSalesFromText($('postPaste').value,false); $('saveAllFoundBtn').onclick=()=>importSalesFromPreview(); $('photoPostBtn').onclick=()=>$('postImageInput').click(); $('postImageInput').addEventListener('change',e=>parsePhotoPost(e.target.files && e.target.files[0])); $('clearPostBtn').onclick=()=>{ $('postPaste').value=''; resetSalePreview(); $('parseStatus').textContent='Paste post text or upload a screenshot/photo. The app will use only sale-looking text and ignore Facebook buttons/photo clutter.'; $('postPaste').focus(); }; $('saleModal').addEventListener('click',e=>{ if(e.target.id==='saleModal') closeModal(); });
  ['saleTitle','saleAddress','saleDate','saleTime','saleNotes','saleInclude'].forEach(id=>{ const el=$(id); if(el) el.addEventListener(id==='saleInclude'?'change':'input',()=>{ storeCurrentFormToPreview(); updateSaveAllButton(); }); });
  $('saveSaleBtn').onclick=()=>{
    storeCurrentFormToPreview();
    const id=$('saleId').value||uid(); const addr=$('saleAddress').value.trim();
    if(!addr){ alert('Type an address first so Google Maps can route to it.'); $('saleAddress').focus(); return; }
    let existing=sales.find(s=>s.id===id);
    if(!existing){ existing={id, order:nextOrder()}; sales.push(existing); }
    const oldAddr=existing.address||'';
    existing.title=$('saleTitle').value.trim()||'Yard sale'; existing.address=addr; existing.date=$('saleDate').value; existing.time=$('saleTime').value; existing.notes=$('saleNotes').value.trim(); existing.include=$('saleInclude').checked; existing.visited=!!existing.visited;
    if(oldAddr!==addr){ existing.lat=null; existing.lon=null; existing.geocodedAddress=''; }
    save(); closeModal();
  };
  $('deleteSaleBtn').onclick=()=>removeSale($('saleId').value);
  $('centerBtn').onclick=geocodeHome; if($('mapLockBtn')) $('mapLockBtn').onclick=toggleMapInteraction; $('homeInput').value=localStorage.getItem('salescout_home')||'Gladwin, MI'; $('homeInput').addEventListener('change',()=>localStorage.setItem('salescout_home',$('homeInput').value.trim()));
  function updateScreenMode(){ document.body.classList.toggle('map-screen', $('mapScreen').classList.contains('active')); }
  document.querySelectorAll('[data-screen]').forEach(btn=>btn.onclick=()=>{ document.querySelectorAll('.screen').forEach(s=>s.classList.remove('active')); document.querySelectorAll('.tabs button').forEach(b=>b.classList.remove('active')); $(btn.dataset.screen).classList.add('active'); btn.classList.add('active'); updateScreenMode(); if(btn.dataset.screen==='mapScreen' && map) setTimeout(()=>map.invalidateSize(),220); });
  document.querySelectorAll('[data-filter]').forEach(btn=>btn.onclick=()=>{ filter=btn.dataset.filter; renderList(); });
  $('clearVisitedBtn').onclick=()=>{ if(confirm('Delete all visited sales?')){ sales=sales.filter(s=>!s.visited); save(); } };
  $('openRouteBtn').onclick=()=>openMaps(buildMapsUrl()); $('copyRouteBtn').onclick=()=>{ const box=$('routeLinkBox'); box.style.display='block'; box.textContent=buildMapsUrl()||'No route yet.'; };
  $('exportBtn').onclick=()=>{ $('backupText').value=JSON.stringify({version:13, exported:new Date().toISOString(), sales:sales.map(normalizeSale)}, null, 2); $('backupText').focus(); $('backupText').select(); };
  $('importBtn').onclick=()=>{ try{ const data=JSON.parse($('backupText').value); if(Array.isArray(data.sales)){ if(confirm('Replace your current list with this backup?')){ sales=data.sales.map(normalizeSale); save(); alert('Imported.'); } } else alert('That backup text does not look right.'); }catch(e){ alert('Could not read backup text.'); } };
  window.editSale=editSale; window.removeSale=removeSale; window.toggleVisited=toggleVisited; window.toggleInclude=toggleInclude; window.moveRoute=moveRoute; window.openOneMap=openOneMap;

  // First-time guided tutorial.
  const TUTORIAL_KEY = 'salescout_tutorial_seen_v1';
  let tutorialIndex = 0;
  const tutorialSteps = [
    {
      title:'Welcome to SaleScout',
      body:'SaleScout is a simple family yard-sale planner. Save the sales you want, choose which ones belong in your route, then send the route to Google Maps.'
    },
    {
      title:'Start from an area',
      body:'Use <b>Start from</b> to center the map around a city or address. Google Maps directions will still start from the phone\'s current location when you open a route.'
    },
    {
      title:'Add a sale',
      body:'Tap <b>+ Add sale</b>. You can type a sale by hand, paste a Facebook post, or upload a screenshot/photo. Always check the address before saving.'
    },
    {
      title:'Paste or upload posts',
      body:'For Facebook posts, copying and pasting the text is usually best. Screenshots can work too, especially if you crop close to the written post text and avoid extra photos/buttons.'
    },
    {
      title:'Review multiple sales',
      body:'If SaleScout finds more than one possible sale, it shows <b>Sale 1</b>, <b>Sale 2</b>, and more. Tap each tab, fix anything wrong, then use <b>Save all found</b> to save the safe ones.'
    },
    {
      title:'Use the List tab',
      body:'The <b>List</b> tab lets you edit, delete, mark visited, or remove a sale from the route. Use filters like Today or This week when your list gets long.'
    },
    {
      title:'Open your route',
      body:'The <b>Route</b> tab shows the stops included in your trip. Move stops up or down, then tap <b>Open in Google Maps</b> for driving directions.'
    },
    {
      title:'You can see this again',
      body:'Tap the <b>?</b> button at the top any time to reopen this quick guide. Your saved sales stay on this phone unless you export/import a backup.'
    }
  ];
  function renderTutorialStep(){
    const step = tutorialSteps[tutorialIndex];
    if(!$('tutorialOverlay') || !step) return;
    $('tutorialStepLabel').textContent = 'Step ' + (tutorialIndex + 1) + ' of ' + tutorialSteps.length;
    $('tutorialTitle').textContent = step.title;
    $('tutorialText').innerHTML = step.body;
    $('tutorialProgress').innerHTML = tutorialSteps.map((_,i)=>'<span class="tutorialDot '+(i===tutorialIndex?'active':'')+'"></span>').join('');
    $('tutorialBackBtn').style.visibility = tutorialIndex === 0 ? 'hidden' : 'visible';
    $('tutorialNextBtn').textContent = tutorialIndex === tutorialSteps.length - 1 ? 'Done' : 'Next';
  }
  function showTutorial(force=false){
    if(!force && localStorage.getItem(TUTORIAL_KEY)==='1') return;
    tutorialIndex = 0;
    renderTutorialStep();
    document.body.classList.add('modal-open');
    $('tutorialOverlay').classList.add('show');
    $('tutorialOverlay').setAttribute('aria-hidden','false');
  }
  function closeTutorial(markSeen=true){
    if(markSeen) localStorage.setItem(TUTORIAL_KEY,'1');
    document.body.classList.remove('modal-open');
    $('tutorialOverlay').classList.remove('show');
    $('tutorialOverlay').setAttribute('aria-hidden','true');
  }
  function nextTutorial(){
    if(tutorialIndex >= tutorialSteps.length - 1){ closeTutorial(true); return; }
    tutorialIndex += 1; renderTutorialStep();
  }
  function prevTutorial(){ if(tutorialIndex > 0){ tutorialIndex -= 1; renderTutorialStep(); } }
  if($('tutorialHelpBtn')) $('tutorialHelpBtn').onclick=()=>showTutorial(true);
  if($('tutorialNextBtn')) $('tutorialNextBtn').onclick=nextTutorial;
  if($('tutorialBackBtn')) $('tutorialBackBtn').onclick=prevTutorial;
  if($('tutorialSkipBtn')) $('tutorialSkipBtn').onclick=()=>closeTutorial(true);


  // Map pin reliability fix: Google Maps can route addresses that OpenStreetMap/Nominatim
  // sometimes cannot pin exactly. Try multiple local search variants, then show an
  // approximate review pin instead of hiding the sale completely.
  const MAP_PIN_GEOCODE_VERSION = 17;
  function directionWord(d){
    const x=String(d||'').toUpperCase();
    return {N:'North',S:'South',E:'East',W:'West',NE:'Northeast',NW:'Northwest',SE:'Southeast',SW:'Southwest'}[x]||x;
  }
  function uniqueList(list){
    const seen=new Set(), out=[];
    list.forEach(v=>{ v=String(v||'').replace(/\s+/g,' ').trim(); if(v && !seen.has(v.toLowerCase())){ seen.add(v.toLowerCase()); out.push(v); } });
    return out;
  }
  function mapSearchCandidates(addr){
    const home = homePlace ? homePlace() : (localStorage.getItem('salescout_home')||'Gladwin, MI');
    const original = String(addr||'').trim();
    const finished = finishAddress ? finishAddress(original) : original;
    const arr = [finished, original];
    const base = finished || original;

    // Common OCR/user shorthand: 3804 w m61 -> 3804 W M-61, Gladwin, MI
    const hwy = base.match(/^\s*(\d{1,6})\s+((?:N|S|E|W|NE|NW|SE|SW)\s+)?(?:M|MI|US|U\.S\.|HWY|Highway|Route|State Route)[\s\-]*(\d{1,3})\b/i);
    if(hwy){
      const num=hwy[1], dir=(hwy[2]||'').trim().toUpperCase(), rt=hwy[3];
      const shortDir = dir ? dir + ' ' : '';
      const longDir = dir ? directionWord(dir) + ' ' : '';
      arr.push(`${num} ${shortDir}M-${rt}, ${home}`);
      arr.push(`${num} ${shortDir}M ${rt}, ${home}`);
      arr.push(`${num} ${longDir}Michigan ${rt}, ${home}`);
      arr.push(`${num} ${longDir}State Highway ${rt}, ${home}`);
      arr.push(`${num} ${shortDir}Highway ${rt}, ${home}`);
      arr.push(`${num} M-${rt}, ${home}`);
      arr.push(`${num} Michigan ${rt}, ${home}`);
    }

    // Common Gladwin alias problem: Bowery is often mapped as Avenue, not Street.
    const bowery = base.match(/^\s*(\d{1,6})\s+((?:N|S|E|W)\s+)?Bowery\s+(?:St\.?|Street|Ave\.?|Avenue)\b/i);
    if(bowery){
      const num=bowery[1], dir=(bowery[2]||'').trim();
      arr.push(`${num} ${dir ? dir + ' ' : ''}Bowery Avenue, ${home}`);
      arr.push(`${num} ${dir ? dir + ' ' : 'N '}Bowery Ave, ${home}`);
      arr.push(`${num} North Bowery Avenue, ${home}`);
    }

    // Try expanded suffixes too.
    const suffixVariants = [
      [/(\bSt\.?\b)/ig,'Street'], [/(\bAve\.?\b)/ig,'Avenue'], [/(\bRd\.?\b)/ig,'Road'],
      [/(\bDr\.?\b)/ig,'Drive'], [/(\bLn\.?\b)/ig,'Lane'], [/(\bCt\.?\b)/ig,'Court'],
      [/(\bHwy\.?\b)/ig,'Highway']
    ];
    suffixVariants.forEach(([re,rep])=>{ if(base && re.test(base)){ re.lastIndex=0; arr.push(base.replace(re,rep)); } });
    return uniqueList(arr).slice(0,12);
  }
  function approxPinForSale(s){
    const home = (localStorage.getItem('salescout_home') || $('homeInput')?.value || 'Gladwin, MI').toLowerCase();
    let baseLat=44.0295, baseLon=-84.4864;
    if(home.includes('beaverton')){ baseLat=43.8822; baseLon=-84.4847; }
    else if(home.includes('clare')){ baseLat=43.8195; baseLon=-84.7686; }
    else if(home.includes('harrison')){ baseLat=44.0192; baseLon=-84.7995; }
    else if(home.includes('midland')){ baseLat=43.6156; baseLon=-84.2472; }
    else if(home.includes('west branch')){ baseLat=44.2764; baseLon=-84.2386; }
    const key = String((s && (s.address||s.title||s.id)) || 'sale');
    let h=0; for(let i=0;i<key.length;i++){ h=(h*31 + key.charCodeAt(i))>>>0; }
    const angle=(h%360)*Math.PI/180;
    const radius=0.010 + ((h>>8)%9)*0.0025;
    return [baseLat + Math.sin(angle)*radius, baseLon + Math.cos(angle)*radius];
  }
  function scoreMapChoice(choice, query){
    const lat=parseFloat(choice.lat), lon=parseFloat(choice.lon);
    if(!Number.isFinite(lat) || !Number.isFinite(lon)) return -9999;
    let score = 100 - Math.min(100, milesFromGladwin(lat, lon));
    const name = String(choice.display_name||'');
    if(/Michigan|, MI,| MI /i.test(name)) score += 45;
    if(/Gladwin|Beaverton|Clare|Harrison|Midland|West Branch/i.test(name)) score += 20;
    const q = String(query||'').toLowerCase();
    const firstNum = q.match(/\b\d{2,6}\b/);
    if(firstNum && name.includes(firstNum[0])) score += 25;
    if(/\bM[-\s]?61\b|Michigan 61|Highway 61/i.test(q) && /(?:M[-\s]?61|Michigan 61|Highway 61|State Highway 61|M 61)/i.test(name)) score += 25;
    return score;
  }
  geocodeSale = async function(s){
    if(!s || !String(s.address||'').trim()) return s;
    const searchAddress = addressForSearch(s.address);
    if(s.lat && s.lon && s.geocodedAddress===searchAddress && s.geocodeVersion===MAP_PIN_GEOCODE_VERSION && !s.pinApprox) return s;
    let best=null, bestScore=-9999;
    try{
      const qs = mapSearchCandidates(s.address);
      for(const q of qs){
        const urls = [
          'https://nominatim.openstreetmap.org/search?format=json&limit=8&countrycodes=us&bounded=1&viewbox=-86.2,45.4,-82.8,43.0&q=' + encodeURIComponent(q),
          'https://nominatim.openstreetmap.org/search?format=json&limit=8&countrycodes=us&q=' + encodeURIComponent(q)
        ];
        for(const url of urls){
          const res = await fetch(url);
          const data = await res.json();
          for(const ch of (data||[])){
            const sc = scoreMapChoice(ch, q);
            if(sc > bestScore){ best=ch; bestScore=sc; }
          }
          if(best && bestScore >= 80) break;
        }
        if(best && bestScore >= 80) break;
      }
      if(best && bestScore >= 35){
        s.lat=parseFloat(best.lat); s.lon=parseFloat(best.lon); s.geocodedAddress=searchAddress; s.geocodeVersion=MAP_PIN_GEOCODE_VERSION; s.pinApprox=false; saveOnly(); return s;
      }
    }catch(e){}
    const p = approxPinForSale(s);
    s.lat=p[0]; s.lon=p[1]; s.geocodedAddress=searchAddress; s.geocodeVersion=MAP_PIN_GEOCODE_VERSION; s.pinApprox=true; saveOnly();
    return s;
  };
  renderMap = async function(){
    if(!map || !markersLayer) return;
    markersLayer.clearLayers();
    const bounds=[]; let exact=0, approx=0;
    for(const s of sales){
      await geocodeSale(s);
      if(s.lat && s.lon){
        const title = escapeHtml(s.title||'Sale');
        const addr = escapeHtml(s.address||'');
        const approxMsg = s.pinApprox ? '<br><b>Approximate pin.</b> Google Maps still routes using the address.' : '';
        const popup = '<b>'+title+'</b><br>'+addr+'<br>'+escapeHtml(dateLabel(s))+approxMsg;
        let marker;
        if(s.pinApprox && L.circleMarker){ marker=L.circleMarker([s.lat,s.lon],{radius:9,weight:3,opacity:1,fillOpacity:.65}).bindPopup(popup); approx++; }
        else { marker=L.marker([s.lat,s.lon]).bindPopup(popup); exact++; }
        markersLayer.addLayer(marker); bounds.push([s.lat,s.lon]);
      }
    }
    const note = document.querySelector('.mapNote');
    if(note){ note.textContent = approx ? (exact + ' exact pin' + (exact===1?'':'s') + ' • ' + approx + ' approximate pin' + (approx===1?'':'s') + '. Google Maps routing still uses the saved addresses.') : 'Pins use OpenStreetMap. Google Maps routing still works by address even if a pin is approximate.'; }
    if(bounds.length) map.fitBounds(bounds,{padding:[32,32],maxZoom:14});
    else { const home=localStorage.getItem('salescout_home')||$('homeInput').value||'Gladwin, MI'; if(home.toLowerCase().includes('gladwin')) map.setView([44.0295,-84.4864],9); }
    setTimeout(()=>map.invalidateSize(),50);
  };
  const oldNormalizeSaleForPins = normalizeSale;
  normalizeSale = function(s,i){ const out = oldNormalizeSaleForPins(s,i); out.pinApprox=!!s.pinApprox; return out; };


  // v1 launch smart OCR/date/address patch: better flyer image OCR, highway addresses, multiple photos, and weekday ranges.
  function saleScoutLocalISO(d){
    const x = new Date(d.getFullYear(), d.getMonth(), d.getDate(), 12,0,0,0);
    x.setMinutes(x.getMinutes() - x.getTimezoneOffset());
    return x.toISOString().slice(0,10);
  }
  function dayIndexFromWord(w){
    const k = String(w||'').toLowerCase().slice(0,3);
    return {sun:0,mon:1,tue:2,wed:3,thu:4,fri:5,sat:6}[k];
  }
  function resolveWeekdayRangeStartISO(startIdx, endIdx){
    const today = new Date(); today.setHours(12,0,0,0);
    const duration = (endIdx - startIdx + 7) % 7;
    let bestFuture = null, bestPast = null;
    for(let off=-7; off<=14; off++){
      const start = new Date(today); start.setDate(today.getDate()+off);
      if(start.getDay() !== startIdx) continue;
      const end = new Date(start); end.setDate(start.getDate()+duration);
      if(today >= start && today <= end) return saleScoutLocalISO(start);
      if(start >= today && (!bestFuture || start < bestFuture)) bestFuture = start;
      if(start < today && (!bestPast || start > bestPast)) bestPast = start;
    }
    return saleScoutLocalISO(bestFuture || bestPast || today);
  }
  function routeAddressFromText(raw){
    let s = normalizeStreetSuffix(String(raw||''))
      .replace(/[“”]/g,'"').replace(/[‘’]/g,"'")
      .replace(/\b[Gg]ladw[il]n\b/g,'Gladwin')
      .replace(/\b([NSEW])\s*[-–—]\s*(?=m[-\s]?\d)/ig,'$1 ')
      .replace(/\bw\s*[-–—]\s*m\s*61\b/ig,'W M-61')
      .replace(/\bwest\s+[-–—]?\s*m\s*61\b/ig,'W M-61')
      .replace(/\s+/g,' ')
      .trim();
    const cityNames = (typeof cityPattern === 'function') ? cityPattern() : '(?:Gladwin|Beaverton|Clare|Harrison|Midland|Mount Pleasant|Mt\\.? Pleasant|West Branch)';
    const re = new RegExp('(?:^|\\b)(\\d{1,6})\\s+(?:(N|S|E|W|NE|NW|SE|SW|North|South|East|West)\\s*)?(?:[-–—]?\\s*)?(M|US|I|Michigan|State Highway|Highway|Hwy)\\s*[-–—]?\\s*(\\d{1,3})\\b(?:\\s*,?\\s*)?('+cityNames+')?(?:\\s*,?\\s*(MI|Michigan))?', 'i');
    const m = s.match(re);
    if(!m) return '';
    const num = m[1];
    let dir = (m[2]||'').trim();
    const prefix = (m[3]||'M').trim();
    const rt = m[4];
    const city = (m[5]||'').replace(/Mt\.?/i,'Mount').trim();
    let d = '';
    if(/^north$/i.test(dir)) d='N'; else if(/^south$/i.test(dir)) d='S'; else if(/^east$/i.test(dir)) d='E'; else if(/^west$/i.test(dir)) d='W'; else d = dir.toUpperCase();
    let road = /^us$/i.test(prefix) ? 'US-'+rt : (/^i$/i.test(prefix) ? 'I-'+rt : 'M-'+rt);
    let out = num + ' ' + (d ? d + ' ' : '') + road;
    if(city) out += ', ' + city;
    if((city || m[6]) && !/\bMI\b/i.test(out)) out += ', MI';
    if(!city && !m[6]) out = finishAddress(out);
    return out.replace(/\s{2,}/g,' ').trim();
  }
  const prevExtractStrictStreetAddressSmart = extractStrictStreetAddress;
  extractStrictStreetAddress = function(raw){
    const route = routeAddressFromText(raw);
    if(route) return route;
    return prevExtractStrictStreetAddressSmart(raw);
  };
  const prevCleanAddressCandidateSmart = cleanAddressCandidate;
  cleanAddressCandidate = function(raw){
    const route = routeAddressFromText(raw);
    if(route) return route;
    return prevCleanAddressCandidateSmart(raw);
  };
  const prevRealisticStreetAddressSmart = realisticStreetAddress;
  realisticStreetAddress = function(addr){
    if(routeAddressFromText(addr)) return true;
    return prevRealisticStreetAddressSmart(addr);
  };
  parsePostAddress = function(text){
    const lines = cleanPostText(text).split('\n').map(l=>l.trim()).filter(Boolean);
    const candidates = [];
    function add(raw, labelled=false, why=''){
      const cleaned = cleanAddressCandidate(raw);
      if(!cleaned || !realisticStreetAddress(cleaned)) return;
      const score = scoreAddressCandidate(cleaned, labelled) + (routeAddressFromText(raw) ? 18 : 0);
      if(score > 0) candidates.push({raw:cleaned, score, labelled, why});
    }
    for(let i=0;i<lines.length;i++){
      const line = normalizeStreetSuffix(lines[i]);
      if(isFacebookUiLine(line) || isOcrGarbageLine(line)) continue;
      if(/^(?:address|addy|location|where|located\s+at|located|place|pickup|pick up)\s*[:\-–—]?$/i.test(line) && lines[i+1]) add(lines[i+1], true, 'label-next-line');
      if(/^(?:address|addy|location|where|located\s+at|located|place|pickup|pick up)\s*[:\-–—]\s+/i.test(line)) add(line, true, 'label');
      const inline = line.match(/\b(?:address|addy|location|where|located\s+at|located|pickup|pick up)\s*[:\-–—]?\s+(.{3,140})$/i);
      if(inline) add(inline[1], true, 'inline-label');
      const atStreet = line.match(/\b(?:at|@)\s+(\d{1,6}\s+[^\n]{2,130})/i);
      if(atStreet) add(atStreet[1], false, 'at-street');
      const strict = extractStrictStreetAddress(line);
      if(strict) add(strict, false, 'street-inside-line');
      for(let span=2; span<=4; span++){
        if(i+span-1 < lines.length){
          const windowText = lines.slice(i,i+span).join(' ');
          const strictWin = extractStrictStreetAddress(windowText);
          if(strictWin) add(strictWin, false, 'wrapped-'+span);
        }
      }
    }
    candidates.sort((a,b)=>b.score-a.score);
    const best = candidates[0];
    if(best && best.score >= 60) return {address:finishAddress(best.raw), confidence:best.score>=95?'high':'medium', warning:best.score>=95?'':'Possible address found — double-check it before saving.'};
    const city = cleanPostText(text).match(LOCAL_CITY_RE);
    if(city) return {address:'', city:city[0].replace(/Mt\.?/i,'Mount') + ', MI', confidence:'city-only', warning:'I only found the city. I left the address blank so it does not route to the wrong place.'};
    return {address:'', city:'', confidence:'none', warning:'I did not find a safe address, so I left the address blank instead of guessing.'};
  };
  parsePostDate = function(text){
    const source = removeFbMetaDateLines ? removeFbMetaDateLines(cleanOcrText(text)) : cleanOcrText(text);
    const t = ' ' + source.toLowerCase() + ' ';
    if(/\btoday\b/.test(t)) return {iso:todayISO(), label:'today'};
    if(/\btomorrow\b/.test(t)){
      const d=new Date(); d.setDate(d.getDate()+1); return {iso:saleScoutLocalISO(d), label:'tomorrow'};
    }
    const daysRe = '(sunday|sun|monday|mon|tuesday|tues|tue|wednesday|wed|thursday|thurs|thu|friday|fri|saturday|sat)';
    let dm = source.match(new RegExp('\\b'+daysRe+'\\b\\s*(?:-|–|—|to|through|thru|until|and)\\s*\\b'+daysRe+'\\b','i'));
    if(dm){
      const a = dayIndexFromWord(dm[1]); const b = dayIndexFromWord(dm[2]);
      if(a !== undefined && b !== undefined) return {iso:resolveWeekdayRangeStartISO(a,b), label:dm[0]};
    }
    if(/\bthis\s+weekend\b/i.test(source)) return {iso:resolveWeekdayRangeStartISO(6,0), label:'this weekend'};
    const monthNames = {jan:1,january:1,feb:2,february:2,mar:3,march:3,apr:4,april:4,may:5,jun:6,june:6,jul:7,july:7,aug:8,august:8,sep:9,sept:9,september:9,oct:10,october:10,nov:11,november:11,dec:12,december:12};
    let m = source.match(/\b(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t|tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\.?\s+(\d{1,2})(?:st|nd|rd|th)?\s*(?:-|–|—|to|through|thru)\s*(?:(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t|tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\.?\s*)?(\d{1,2})(?:st|nd|rd|th)?/i);
    if(m){ let y = new Date().getFullYear(); return {iso:isoFromParts(y, monthNames[m[1].toLowerCase().replace('.','')], Number(m[2])), label:m[0]}; }
    m = source.match(/\b(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t|tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\.?\s+(\d{1,2})(?:st|nd|rd|th)?(?:,?\s*(20\d{2}|\d{2}))?\b/i);
    if(m){ let y = m[3] ? Number(m[3]) : new Date().getFullYear(); if(y<100) y+=2000; return {iso:isoFromParts(y, monthNames[m[1].toLowerCase().replace('.','')], Number(m[2])), label:m[0]}; }
    m = source.match(/\b(\d{1,2})[\/\-.](\d{1,2})(?:[\/\-.](20\d{2}|\d{2}))?\b/);
    if(m){ let y = m[3] ? Number(m[3]) : new Date().getFullYear(); if(y<100) y+=2000; return {iso:isoFromParts(y, Number(m[1]), Number(m[2])), label:m[0]}; }
    const dayWords = [['sunday',0],['sun',0],['monday',1],['mon',1],['tuesday',2],['tues',2],['tue',2],['wednesday',3],['wed',3],['thursday',4],['thurs',4],['thu',4],['friday',5],['fri',5],['saturday',6],['sat',6]];
    for(const [name, idx] of dayWords){ if(new RegExp('\\b'+name+'\\b','i').test(source)) return {iso:nextWeekdayISO(idx), label:name}; }
    return {iso:'', label:''};
  };
  parsePostTitle = function(text){
    const lines = cleanPostText(text).split('\n').map(l=>l.trim()).filter(Boolean).filter(l=>!isFacebookUiLine(l) && !isOcrGarbageLine(l) && !isProbablyMetaNameLine(l));
    for(const l of lines){
      const m = l.match(/\b((?:large\s+|huge\s+|multi[ -]?family\s+|neighborhood\s+|church\s+|barn\s+)?(?:garage|yard|moving|estate|rummage|tag)\s+sales?)\b/i);
      if(m) return m[1].replace(/\s+/g,' ').replace(/\b\w/g,c=>c.toUpperCase()).replace(/Sales$/,'Sale');
    }
    return 'Yard sale';
  };
  lineHasUsefulSaleSignal = function(line){
    const l = normalizeOcrListingLine(line);
    if(!l) return false;
    if(hasStreetAddress(l) || extractStrictStreetAddress(l) || routeAddressFromText(l)) return true;
    if(/\b(?:garage|yard|moving|estate|rummage|barn|tag|multi[ -]?family|sale|rummage|bargains?)\b/i.test(l)) return true;
    if(/\b(?:today|tomorrow|fri(?:day)?|sat(?:urday)?|sun(?:day)?|mon(?:day)?|tue(?:sday)?|wed(?:nesday)?|thu(?:rsday)?|through|thru|weekend)\b/i.test(l)) return true;
    if(/\b\d{1,2}(?::\d{2})?\s*(?:am|pm)\b/i.test(l)) return true;
    if(/\b\d{1,2}\s*(?:-|to|–|—)\s*\d{1,2}\s*(?:am|pm)?\b/i.test(l)) return true;
    if(ITEM_RE.test(l) && l.length < 120) return true;
    return false;
  };
  extractUsefulSaleTextFromOcr = function(raw){
    const lines = String(raw||'').split(/\n+/)
      .map(normalizeOcrListingLine)
      .filter(l=>l && !isFacebookUiLine(l) && !isOcrGarbageLine(l) && !isProbablyMetaNameLine(l));
    if(!lines.length) return '';
    const useful = [];
    for(let i=0;i<lines.length;i++){
      const l = lines[i];
      if(lineHasUsefulSaleSignal(l)) useful.push({i,l});
    }
    if(!useful.length) return '';
    const keep = new Set();
    useful.forEach(({i})=>{
      for(let j=Math.max(0,i-3); j<=Math.min(lines.length-1,i+3); j++){
        const line = lines[j];
        if(isProbablyMetaNameLine(line) || isFacebookUiLine(line) || isOcrGarbageLine(line)) continue;
        if(j!==i && !lineHasUsefulSaleSignal(line) && line.length > 120) continue;
        keep.add(j);
      }
    });
    return [...keep].sort((a,b)=>a-b).map(i=>lines[i]).join('\n').replace(/\n{3,}/g,'\n\n').trim();
  };
  async function makeOcrBlobSmart(img, crop, mode='auto'){
    const srcW = crop ? crop.w : img.naturalWidth;
    const srcH = crop ? crop.h : img.naturalHeight;
    const maxDim = Math.max(srcW, srcH);
    let scale = maxDim < 1200 ? 2.4 : (maxDim < 1900 ? 1.7 : 1.2);
    if(maxDim * scale > 3200) scale = 3200 / maxDim;
    const canvas = document.createElement('canvas');
    canvas.width = Math.max(1, Math.round(srcW * scale));
    canvas.height = Math.max(1, Math.round(srcH * scale));
    const ctx = canvas.getContext('2d', {willReadFrequently:true});
    ctx.fillStyle = '#fff'; ctx.fillRect(0,0,canvas.width,canvas.height);
    ctx.imageSmoothingEnabled = true;
    ctx.drawImage(img, crop ? crop.x : 0, crop ? crop.y : 0, srcW, srcH, 0, 0, canvas.width, canvas.height);
    const data = ctx.getImageData(0,0,canvas.width,canvas.height);
    let total=0;
    for(let i=0;i<data.data.length;i+=4){ total += 0.299*data.data[i] + 0.587*data.data[i+1] + 0.114*data.data[i+2]; }
    const avg = total / (data.data.length/4);
    const invert = mode === 'invert' || (mode === 'auto' && avg < 150);
    for(let i=0;i<data.data.length;i+=4){
      let lum = 0.299*data.data[i] + 0.587*data.data[i+1] + 0.114*data.data[i+2];
      if(invert) lum = 255 - lum;
      let v = (lum - 128) * 2.15 + 128;
      v = v > 205 ? 255 : (v < 95 ? 0 : Math.max(0, Math.min(255, Math.round(v))));
      data.data[i]=data.data[i+1]=data.data[i+2]=v; data.data[i+3]=255;
    }
    ctx.putImageData(data,0,0);
    return canvasToBlob(canvas);
  }
  buildOcrInputs = async function(file){
    const img = await loadImageFromFile(file);
    const w = img.naturalWidth, h = img.naturalHeight;
    const inputs = [];
    const push = async (label, crop, psm='6', mode='auto') => inputs.push({label, image:await makeOcrBlobSmart(img,crop,mode), psm});
    await push('full image text', {x:0,y:0,w,h}, h>w*1.08 ? '6':'4', 'auto');
    await push('full image inverted text', {x:0,y:0,w,h}, h>w*1.08 ? '6':'4', 'invert');
    if(h > w * 1.08){
      const top = Math.floor(h*0.03), bottom = Math.floor(h*0.98), usableH = bottom - top;
      await push('center post/flyer text', {x:Math.floor(w*0.02), y:top, w:Math.floor(w*0.96), h:usableH}, '6', 'auto');
      await push('upper half text', {x:0, y:top, w, h:Math.floor(usableH*0.55)}, '6', 'auto');
      await push('lower half text', {x:0, y:Math.floor(top+usableH*0.42), w, h:Math.floor(usableH*0.56)}, '6', 'auto');
    }else if(w > h * 1.12){
      const mid = Math.floor(w/2);
      await push('left column', {x:0,y:0,w:mid,h}, '4', 'auto');
      await push('right column', {x:mid,y:0,w:w-mid,h}, '4', 'auto');
    }
    return inputs;
  };
  parsePhotoPost = async function(fileOrFiles){
    let files = [];
    const inputFiles = $('postImageInput') && $('postImageInput').files ? Array.from($('postImageInput').files) : [];
    if(inputFiles.length) files = inputFiles;
    else if(fileOrFiles){ files = fileOrFiles.length !== undefined && !fileOrFiles.name ? Array.from(fileOrFiles) : [fileOrFiles]; }
    files = files.filter(Boolean);
    if(!files.length) return;
    $('parseStatus').textContent = 'Reading '+files.length+' screenshot/photo'+(files.length===1?'':'s')+'. This can take a minute...';
    if(!window.Tesseract){ $('parseStatus').textContent = 'Photo reading could not load. Check internet, or paste the text manually.'; return; }
    try{
      const usefulPieces = [];
      for(let f=0; f<files.length; f++){
        const inputs = await buildOcrInputs(files[f]);
        for(let i=0;i<inputs.length;i++){
          const part = inputs[i];
          $('parseStatus').textContent = 'Reading photo '+(f+1)+'/'+files.length+' — '+part.label+'...';
          const result = await Tesseract.recognize(part.image, 'eng', {
            logger: m=>{ if(!m||!m.status) return; const pct=typeof m.progress==='number' ? ' '+Math.round(m.progress*100)+'%' : ''; $('parseStatus').textContent='Reading photo '+(f+1)+'/'+files.length+' — '+part.label+': '+m.status+pct; },
            tessedit_pageseg_mode: part.psm || '6',
            preserve_interword_spaces:'1'
          });
          const raw = result && result.data && result.data.text ? result.data.text : '';
          const useful = extractUsefulSaleTextFromOcr(raw);
          if(useful) usefulPieces.push(useful);
        }
      }
      const text = mergeOcrLines ? mergeOcrLines(usefulPieces.join('\n\n---SALESCOUT-CROP---\n\n')).trim() : usefulPieces.join('\n\n---SALESCOUT-CROP---\n\n').trim();
      if(!text){ $('postPaste').value=''; $('parseStatus').textContent='I could not find clean sale text in that screenshot. Try cropping closer to the written sale text, or copy/paste the post text.'; return; }
      $('postPaste').value = text;
      showSalePreviewFromText(text, files.length>1 ? 'photos' : 'photo');
      const valid = salePreviewItems.filter(isSafeParsedSale).length;
      if(salePreviewItems.length > 1) $('parseStatus').textContent = 'Found '+salePreviewItems.length+' possible listing'+(salePreviewItems.length===1?'':'s')+'. Check the tabs. '+valid+' have safe addresses and can be saved.';
      else $('parseStatus').textContent += ' I filled the form with the best match. Double-check the address and date.';
    }catch(e){
      $('parseStatus').textContent = 'Could not read that photo. Try a clearer/cropped screenshot, or paste the post text.';
    }finally{ if($('postImageInput')) $('postImageInput').value=''; }
  };
  if($('postImageInput')){ $('postImageInput').setAttribute('multiple','multiple'); }
  if($('photoPostBtn')){
    $('photoPostBtn').textContent = 'Upload photo(s)';
    $('photoPostBtn').onclick = (e)=>{
      $('parseStatus').textContent = 'Choose one or more screenshots/photos to read...';
      // If this is a real button in an older build, open the picker. If it is the label version,
      // the label's for=postImageInput opens the picker more reliably in Android WebView/Safari.
      if($('photoPostBtn').tagName && $('photoPostBtn').tagName.toLowerCase()==='button') $('postImageInput').click();
    };
    $('photoPostBtn').onkeydown = (e)=>{ if(e.key==='Enter' || e.key===' '){ e.preventDefault(); $('postImageInput').click(); } };
  }



  // v16 sale-sign OCR helper: do not change the normal screenshot flow, but add extra crops and fuzzy cleanup for handwritten yard-sale signs.
  function saleScoutVisualDigitGuess(token){
    const map = {A:'2',Z:'2',S:'5',T:'7',Y:'7',F:'8',B:'8',O:'0',Q:'0',D:'0',I:'1',L:'1',G:'6'};
    let raw = String(token||'').toUpperCase().replace(/[^A-Z0-9]/g,'');
    if(!raw || raw.length < 2 || raw.length > 7) return '';
    let out = '';
    for(const ch of raw){
      if(/[0-9]/.test(ch)) out += ch;
      else if(map[ch]) out += map[ch];
    }
    out = out.replace(/^0+/, '');
    if(out.length >= 3 && out.length <= 5) return out;
    return '';
  }
  function saleScoutFuzzySuffixToRoad(word){
    const w = String(word||'').toLowerCase().replace(/[^a-z]/g,'');
    if(/^(rd|road|r|ro|rc|rcl|ru|ku|ke|kz|mz|fu|fed|fey|seis|rel|ket|rua)$/.test(w)) return 'Rd';
    return word || '';
  }
  function saleScoutRepairHandwrittenAddressLine(line){
    let l = normalizeStreetSuffix(String(line||''))
      .replace(/[“”]/g,'"').replace(/[‘’]/g,"'")
      .replace(/\s+/g,' ')
      .trim();
    if(!l) return '';
    const exact = extractStrictStreetAddress(l);
    if(exact) return finishAddress(exact);

    // Handwritten digits on neon signs often OCR as letters. Example: "AS 7F Weber Ru" => "2578 Weber Rd".
    let m = l.match(/\b([A-Z0-9$?]{1,5}(?:\s+[A-Z0-9$?]{1,3})?)\s+(Weber|Webcr|Wcber|Ueber|Wehber|Webber)\s+(Rd|Road|R[docl]?|Ru|Ku|Ke|Kz|Mz|Fu|Fed|Fey|Seis)?\b/i);
    if(m){
      const num = saleScoutVisualDigitGuess(m[1]);
      if(num && num.length >= 4){
        return finishAddress(num + ' Weber Rd');
      }
    }

    // Generic handwritten/fuzzy street suffix repair, kept conservative so item descriptions do not become addresses.
    m = l.match(/\b([A-Z0-9$?]{2,6}(?:\s+[A-Z0-9$?]{1,3})?)\s+([A-Za-z][A-Za-z'’.-]{2,}(?:\s+[A-Za-z][A-Za-z'’.-]{2,}){0,2})\s+(Rd|Road|R[docl]?|Ru|Ku|Ke|Kz|Mz|Fu|Fed|Fey|Seis)\b/i);
    if(m){
      const num = saleScoutVisualDigitGuess(m[1]);
      const street = m[2].replace(/\b(?:sale|yard|garage|fri|sat|sun)\b/ig,'').trim();
      const suffix = saleScoutFuzzySuffixToRoad(m[3]);
      if(num && num.length >= 4 && street.length >= 3 && !ITEM_RE.test(street)){
        return finishAddress(num + ' ' + street + ' ' + suffix);
      }
    }
    return '';
  }
  function saleScoutAddSignHints(text){
    const source = String(text||'');
    const hints = [];
    const lines = source.split(/\n+/).map(l=>l.trim()).filter(Boolean);
    for(const line of lines){
      const repaired = saleScoutRepairHandwrittenAddressLine(line);
      if(repaired && !source.toLowerCase().includes(repaired.toLowerCase())) hints.push(repaired);
    }
    const all = source.replace(/\n/g,' ');
    const repairedAll = saleScoutRepairHandwrittenAddressLine(all);
    if(repairedAll && !source.toLowerCase().includes(repairedAll.toLowerCase())) hints.push(repairedAll);

    // Sign shorthand like "Friday/Sat./Sun. 9-5" should still be understood.
    if(/\bfrid?ay\b|\bfri\b/i.test(source) && /\bsat/i.test(source) && /\bsun/i.test(source)) hints.push('Friday Saturday Sunday');
    const bareRange = source.match(/\b(\d{1,2})(?::(\d{2}))?\s*(?:-|–|—|to)\s*(\d{1,2})(?::(\d{2}))?\b/);
    if(bareRange) hints.push(bareRange[0]);
    if(/\bSALE\b/i.test(source) || /garage|yard|rummage/i.test(source)) hints.push('Yard sale');

    const unique = [];
    const seen = new Set();
    for(const h of hints){
      const key = h.toLowerCase().replace(/[^a-z0-9]+/g,' ').trim();
      if(key && !seen.has(key)){ seen.add(key); unique.push(h); }
    }
    return unique.length ? (source.trim() + '\n' + unique.join('\n')).trim() : source;
  }
  function saleScoutDayIndex(word){
    const w = String(word||'').toLowerCase().replace(/\./g,'');
    if(/^sun/.test(w)) return 0;
    if(/^mon/.test(w)) return 1;
    if(/^tue/.test(w)) return 2;
    if(/^wed/.test(w)) return 3;
    if(/^thu|^thur|^thurs/.test(w)) return 4;
    if(/^fri/.test(w)) return 5;
    if(/^sat/.test(w)) return 6;
    return null;
  }
  function saleScoutWeekdayISO(dayIndex){
    const d = new Date();
    let diff = (dayIndex - d.getDay() + 7) % 7;
    // Garage-sale posts usually mean this current sale week. If the first day already happened by a few days, use that past date instead of next week.
    if(diff > 3) diff -= 7;
    d.setDate(d.getDate() + diff);
    d.setHours(12,0,0,0);
    d.setMinutes(d.getMinutes()-d.getTimezoneOffset());
    return d.toISOString().slice(0,10);
  }

  const saleScoutOldParsePostDate = parsePostDate;
  parsePostDate = function(text){
    const source = removeFbMetaDateLines ? removeFbMetaDateLines(cleanOcrText(saleScoutAddSignHints(text))) : cleanOcrText(saleScoutAddSignHints(text));
    const t = ' ' + source.toLowerCase() + ' ';
    if(/\btoday\b/.test(t)) return {iso:todayISO(), label:'today'};
    if(/\btomorrow\b/.test(t)){
      const d=new Date(); d.setDate(d.getDate()+1); d.setHours(12,0,0,0); d.setMinutes(d.getMinutes()-d.getTimezoneOffset());
      return {iso:d.toISOString().slice(0,10), label:'tomorrow'};
    }
    const monthNames = {jan:1,january:1,feb:2,february:2,mar:3,march:3,apr:4,april:4,may:5,jun:6,june:6,jul:7,july:7,aug:8,august:8,sep:9,sept:9,september:9,oct:10,october:10,nov:11,november:11,dec:12,december:12};
    let m = source.match(/\b(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t|tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\.?\s+(\d{1,2})(?:st|nd|rd|th)?\s*(?:-|–|—|to|through|thru)\s*(?:(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t|tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\.?\s*)?(\d{1,2})(?:st|nd|rd|th)?/i);
    if(m){ let y = new Date().getFullYear(); return {iso:isoFromParts(y, monthNames[m[1].toLowerCase().replace('.','')], Number(m[2])), label:m[0]}; }
    m = source.match(/\b(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|jun(?:e)?|jul(?:y)?|aug(?:ust)?|sep(?:t|tember)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)\.?\s+(\d{1,2})(?:st|nd|rd|th)?(?:,?\s*(20\d{2}|\d{2}))?\b/i);
    if(m){ let y = m[3] ? Number(m[3]) : new Date().getFullYear(); if(y<100) y+=2000; return {iso:isoFromParts(y, monthNames[m[1].toLowerCase().replace('.','')], Number(m[2])), label:m[0]}; }
    m = source.match(/\b(\d{1,2})[\/\-.](\d{1,2})(?:[\/\-.](20\d{2}|\d{2}))?\b/);
    if(m){ let y = m[3] ? Number(m[3]) : new Date().getFullYear(); if(y<100) y+=2000; return {iso:isoFromParts(y, Number(m[1]), Number(m[2])), label:m[0]}; }
    const dayRe = /\b(sun(?:day)?|mon(?:day)?|tue(?:sday)?|tues|wed(?:nesday)?|thu(?:rsday)?|thur(?:sday)?|thurs|fri(?:day)?|sat(?:urday)?)\.?\b/ig;
    let dm = dayRe.exec(source);
    if(dm){ const idx = saleScoutDayIndex(dm[1]); if(idx !== null) return {iso:saleScoutWeekdayISO(idx), label:dm[1]}; }
    return saleScoutOldParsePostDate ? saleScoutOldParsePostDate(source) : {iso:'', label:''};
  };

  const saleScoutOldParsePostTime = parsePostTime;
  parsePostTime = function(text){
    const source = saleScoutAddSignHints(text);
    let m = source.match(/\b(\d{1,2})(?::(\d{2}))?\s*(a\.?m\.?|p\.?m\.?)?\s*(?:-|–|—|to|until|til|through)\s*(\d{1,2})(?::(\d{2}))?\s*(a\.?m\.?|p\.?m\.?)\b/i);
    if(m) return {time:timeTo24(m[1],m[2],m[3],m[6]), label:m[0]};
    // Signs often just say 9-5. Treat that as 9 AM start when the end is probably PM.
    m = source.match(/\b(\d{1,2})(?::(\d{2}))?\s*(?:-|–|—|to)\s*(\d{1,2})(?::(\d{2}))?\b/);
    if(m) return {time:timeTo24(m[1],m[2],'','pm'), label:m[0]};
    return saleScoutOldParsePostTime ? saleScoutOldParsePostTime(source) : {time:'', label:''};
  };

  const saleScoutOldParsePostAddress = parsePostAddress;
  parsePostAddress = function(text){
    return saleScoutOldParsePostAddress(saleScoutAddSignHints(text));
  };

  const saleScoutOldLineHasUsefulSaleSignal = lineHasUsefulSaleSignal;
  lineHasUsefulSaleSignal = function(line){
    if(saleScoutRepairHandwrittenAddressLine(line)) return true;
    return saleScoutOldLineHasUsefulSaleSignal(line);
  };

  const saleScoutOldExtractUsefulSaleTextFromOcr = extractUsefulSaleTextFromOcr;
  extractUsefulSaleTextFromOcr = function(raw){
    const enhanced = saleScoutAddSignHints(raw);
    const out = saleScoutOldExtractUsefulSaleTextFromOcr(enhanced);
    if(out) return saleScoutAddSignHints(out);
    const repaired = saleScoutRepairHandwrittenAddressLine(enhanced);
    return repaired ? repaired : '';
  };

  function saleScoutDetectWhiteLabelCrops(img){
    const w = img.naturalWidth, h = img.naturalHeight;
    const sampleW = 260;
    const sampleH = Math.max(1, Math.round(h * sampleW / w));
    const canvas = document.createElement('canvas');
    canvas.width = sampleW; canvas.height = sampleH;
    const ctx = canvas.getContext('2d', {willReadFrequently:true});
    ctx.drawImage(img,0,0,sampleW,sampleH);
    const d = ctx.getImageData(0,0,sampleW,sampleH).data;
    const rowFrac = new Array(sampleH).fill(0);
    const white = new Uint8Array(sampleW * sampleH);
    for(let y=0;y<sampleH;y++){
      let count=0;
      for(let x=0;x<sampleW;x++){
        const i=(y*sampleW+x)*4;
        const r=d[i], g=d[i+1], b=d[i+2];
        const mx=Math.max(r,g,b), mn=Math.min(r,g,b);
        const isWhite = mx>168 && mn>135 && (mx-mn)<95;
        if(isWhite){ white[y*sampleW+x]=1; count++; }
      }
      rowFrac[y]=count/sampleW;
    }
    const bands=[];
    let inBand=false, start=0;
    for(let y=0;y<sampleH;y++){
      const hit=rowFrac[y] > 0.28;
      if(hit && !inBand){ start=y; inBand=true; }
      if((!hit || y===sampleH-1) && inBand){
        const end = hit && y===sampleH-1 ? y : y-1;
        inBand=false;
        if(end-start >= 6){
          let colCounts = new Array(sampleW).fill(0);
          for(let yy=start; yy<=end; yy++) for(let x=0;x<sampleW;x++) if(white[yy*sampleW+x]) colCounts[x]++;
          const minCount = Math.max(2, Math.floor((end-start+1)*0.22));
          let xs = colCounts.map((c,i)=>c>=minCount?i:-1).filter(i=>i>=0);
          if(xs.length){
            const x1=Math.min(...xs), x2=Math.max(...xs);
            const orig = {x:Math.max(0, Math.floor((x1-10)*w/sampleW)), y:Math.max(0, Math.floor((start-8)*h/sampleH)), w:Math.min(w, Math.ceil((x2-x1+20)*w/sampleW)), h:Math.min(h, Math.ceil((end-start+16)*h/sampleH))};
            const widthRatio = orig.w / w;
            const heightRatio = orig.h / h;
            if(widthRatio > 0.30 && widthRatio < 0.88 && heightRatio > 0.025 && heightRatio < 0.20 && orig.y > h*0.12 && orig.y < h*0.82){
              bands.push(orig);
            }
          }
        }
      }
    }
    // Merge nearby bands and limit to the most useful label strips.
    bands.sort((a,b)=>a.y-b.y);
    const merged=[];
    for(const b of bands){
      const last=merged[merged.length-1];
      if(last && b.y <= last.y + last.h + h*0.02){
        const x1=Math.min(last.x,b.x), y1=Math.min(last.y,b.y), x2=Math.max(last.x+last.w,b.x+b.w), y2=Math.max(last.y+last.h,b.y+b.h);
        last.x=x1; last.y=y1; last.w=x2-x1; last.h=y2-y1;
      }else merged.push(Object.assign({},b));
    }
    return merged.slice(0,4);
  }

  const saleScoutOldBuildOcrInputs = buildOcrInputs;
  buildOcrInputs = async function(file){
    const img = await loadImageFromFile(file);
    const w = img.naturalWidth, h = img.naturalHeight;
    const inputs = [];
    const seen = new Set();
    async function push(label, crop, psm){
      const key = label + ':' + (crop ? [crop.x,crop.y,crop.w,crop.h].join(',') : 'full');
      if(seen.has(key)) return; seen.add(key);
      inputs.push({label, image: await makeOcrBlob(img, crop), psm: psm || '6'});
    }
    const labels = saleScoutDetectWhiteLabelCrops(img);
    if(labels.length){
      await push('sale sign full photo', null, '6');
      for(let i=0;i<labels.length;i++) await push('sale sign written line '+(i+1), labels[i], '6');
      if(labels.length >= 2){
        const x1=Math.min(...labels.map(c=>c.x)), y1=Math.min(...labels.map(c=>c.y)), x2=Math.max(...labels.map(c=>c.x+c.w)), y2=Math.max(...labels.map(c=>c.y+c.h));
        await push('sale sign address/time strips', {x:Math.max(0,x1-10), y:Math.max(0,y1-10), w:Math.min(w,x2-x1+20), h:Math.min(h,y2-y1+20)}, '6');
      }
    }
    const older = await saleScoutOldBuildOcrInputs(file);
    for(const part of older){
      inputs.push(part);
      if(inputs.length >= 8) break;
    }
    return inputs;
  };

  parsePhotoPost = async function(file){
    if(!file) return;
    $('parseStatus').textContent = 'Reading screenshot/photo. I will try the normal reader plus sale-sign handwriting strips...';
    if(!window.Tesseract){ $('parseStatus').textContent = 'Photo reading could not load. Check internet, or paste the text manually.'; return; }
    try{
      const inputs = await buildOcrInputs(file);
      const usefulPieces = [];
      for(let i=0;i<inputs.length;i++){
        const part = inputs[i];
        $('parseStatus').textContent = 'Reading '+part.label+'... this can take a minute.';
        const result = await Tesseract.recognize(part.image, 'eng', {
          logger: m=>{ if(!m||!m.status) return; const pct=typeof m.progress==='number' ? ' '+Math.round(m.progress*100)+'%' : ''; $('parseStatus').textContent='Reading '+part.label+': '+m.status+pct; },
          tessedit_pageseg_mode: part.psm || '6',
          preserve_interword_spaces:'1'
        });
        const raw = result && result.data && result.data.text ? result.data.text : '';
        const enhanced = saleScoutAddSignHints(raw);
        const useful = extractUsefulSaleTextFromOcr(enhanced);
        if(useful) usefulPieces.push(useful);
      }
      const text = saleScoutAddSignHints(usefulPieces.join('\n\n---SALESCOUT-CROP---\n\n').trim());
      if(!text){ $('postPaste').value=''; $('parseStatus').textContent='I could not find clean sale text in that photo. For handwritten signs, try a close-up straight-on photo of the white writing area.'; return; }
      $('postPaste').value = text;
      showSalePreviewFromText(text, 'photo');
      if(salePreviewItems.length <= 1) $('parseStatus').textContent += ' I filled the form with the best match. For handwritten signs, double-check the address and time.';
    }catch(e){
      $('parseStatus').textContent = 'Could not read that photo. Try a clearer/cropped screenshot, or paste/type the address and time.';
    }finally{ $('postImageInput').value=''; }
  };



  // v18 newspaper/pasted-listing splitter: lets one pasted newspaper block create multiple review tabs.
  function saleScoutNormalizePastedListings(raw){
    let s = String(raw||'')
      .replace(/\r/g,'\n')
      .replace(/[“”]/g,'"').replace(/[‘’]/g,"'")
      // Fix newspaper hyphenation: Sat- urday, sport- ing, Mis- cellaneous.
      .replace(/\b([A-Za-z]{2,})-\s*\n\s*([a-z]{2,})\b/g,'$1$2')
      .replace(/\b([A-Za-z]{2,})-\s+([a-z]{2,})\b/g,'$1$2')
      // Fix common time range spacing without hurting date ranges.
      .replace(/\b(\d{1,2})\s*(a\.?m\.?|p\.?m\.?)\s*[-–—]\s*(\d{1,2})\s*(a\.?m\.?|p\.?m\.?)\b/ig,'$1$2-$3$4')
      .replace(/\b(\d{1,2})\s*(a\.?m\.?|p\.?m\.?)\s*[-–—]\s*(\d{1,2})\b/ig,'$1$2-$3')
      .replace(/\b(\d{1,2})\s*[-–—]\s*(\d{1,2})\s*(a\.?m\.?|p\.?m\.?)\b/ig,'$1-$2$3')
      .replace(/[ \t]+/g,' ')
      .replace(/\n[ \t]+/g,'\n')
      .replace(/[ \t]+\n/g,'\n')
      .replace(/\n{3,}/g,'\n\n')
      .trim();
    return s;
  }
  function saleScoutListingStartPattern(){
    return '(?:Antique|Estate|Garage|Yard|Moving|Rummage|Barn|Tag|Multi[- ]?family|Large|Huge|Thursday|Friday|Saturday|Sunday|Monday|Tuesday|Wednesday|June|July|August|May|April|September|October|November|December|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Sept|Oct|Nov|Dec)';
  }
  function saleScoutParagraphLikelyListing(block){
    const b = saleScoutNormalizePastedListings(block);
    if(!b || b.length < 8) return false;
    const hasAddr = !!parsePostAddress(b).address;
    const hasSaleWord = /\b(?:garage|yard|moving|estate|rummage|barn|tag|multi[- ]?family|sale)\b/i.test(b);
    const hasDate = !!parsePostDate(b).iso;
    const hasTime = !!parsePostTime(b).time;
    return hasAddr || (hasSaleWord && (hasDate || hasTime || /\b\d{1,2}\s*(?:am|pm)\b/i.test(b)));
  }
  function saleScoutSplitByParagraphsForListings(text){
    const normalized = saleScoutNormalizePastedListings(text);
    if(!normalized) return [];
    // Explicit OCR/photo crop separators or pasted newspaper blank lines are strong listing separators.
    let parts = normalized.split(/\n\s*(?:---SALESCOUT-CROP---|-{3,}|={3,}|_{3,}|\*{3,}|•{3,})\s*\n|\n\s*\n+/g)
      .map(p=>p.trim())
      .filter(Boolean);
    let likely = parts.filter(saleScoutParagraphLikelyListing);
    if(likely.length > 1) return likely;

    // Newspaper text is sometimes pasted as one long block. Insert soft breaks before new listings.
    const start = saleScoutListingStartPattern();
    let marked = normalized
      .replace(new RegExp('\\.\\s+(?='+start+'\\b)','gi'),'.\n\n')
      .replace(new RegExp('(\\b(?:MI|Michigan|Gladwin|Beaverton|Clare|Harrison|Midland|West Branch)\\.?)\\s+(?='+start+'\\b)','gi'),'$1\n\n')
      .replace(/(\b\d{1,6}\s+[^\n.]{2,80}\b(?:Road|Rd\.?|Street|St\.?|Avenue|Ave\.?|Drive|Dr\.?|Lane|Ln\.?|Court|Ct\.?|Run|Trail|Trl\.?|Highway|Hwy\.?|M[- ]?\d{1,3})\b[^\n.]{0,50}\.?)\s+(?=(?:June|July|August|May|April|September|October|November|December|Thursday|Friday|Saturday|Sunday|Garage|Yard|Estate|Moving)\b)/gi,'$1\n\n');
    parts = marked.split(/\n\s*\n+/g).map(p=>p.trim()).filter(Boolean);
    likely = parts.filter(saleScoutParagraphLikelyListing);
    if(likely.length > 1) return likely;
    return [];
  }
  const saleScoutPreviousSplitIntoListingChunks = typeof splitIntoListingChunks === 'function' ? splitIntoListingChunks : null;
  splitIntoListingChunks = function(text){
    const paragraphChunks = saleScoutSplitByParagraphsForListings(text);
    if(paragraphChunks.length > 1) return paragraphChunks.map(p=>cleanListingForNotes ? cleanListingForNotes(p) : p).filter(Boolean);
    const normalized = saleScoutNormalizePastedListings(text);
    if(saleScoutPreviousSplitIntoListingChunks) return saleScoutPreviousSplitIntoListingChunks(normalized);
    return normalized ? [normalized] : [];
  };
  const saleScoutPreviousParseSaleFromText = parseSaleFromText;
  parseSaleFromText = function(text){
    return saleScoutPreviousParseSaleFromText(saleScoutNormalizePastedListings(text));
  };
  const saleScoutPreviousParseFacebookPost = parseFacebookPost;
  parseFacebookPost = function(text){
    const cleaned = saleScoutNormalizePastedListings(text);
    if(!cleaned){ alert('Paste the post text first.'); return; }
    showSalePreviewFromText(cleaned, 'text');
    if(salePreviewItems.length <= 1) $('parseStatus').textContent += ' Review it, especially the address, before saving.';
    else $('parseStatus').textContent += ' Newspaper-style pasted text was split into separate Sale tabs when possible.';
  };


  updateScreenMode(); load(); initMap(); renderAll();
  setTimeout(()=>showTutorial(false), 450);
  </script>
</body>

