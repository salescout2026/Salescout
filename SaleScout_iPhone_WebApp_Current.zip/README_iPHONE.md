# SaleScout iPhone Web App

This is the iPhone-friendly SaleScout version. It is a web app/PWA, not an APK.

Open the hosted URL in Safari on iPhone, tap Share, then Add to Home Screen.

Files in this zip:
- index.html: SaleScout app
- manifest.webmanifest: app name/icon info
- service-worker.js: basic app-shell caching
- icons/: green SS icon files
